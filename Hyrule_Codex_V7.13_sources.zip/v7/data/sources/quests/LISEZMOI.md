# Étapes et récompenses des quêtes — sources

Un fichier `<id>.json` par quête (identifiant de `data/quests.json`, ex. `main_1.json`).
Format et contrôles : `scripts/build_quests.py`. Chaque étape et chaque récompense porte sa propre URL source.
Aucun fichier = quête « à vérifier ». Ne jamais compléter de mémoire.

Sources candidates (non encore collectées, réseau indisponible lors de la session du 11/11/2026) :
- Puissance-Zelda, solution française (intitulés déjà sourcés ici) : https://www.puissance-zelda.com/24-Tears-of-the-Kingdom/solution/854-Liste-de-toutes-les-quetes
