/* ===================================================================
   HYRULE CODEX V7 — fiabilité, provenance, parcours de farming.
   Couche ajoutée APRÈS le code V1–V6 et AVANT init().
   Données : window.CODEX_V7 (injecté par scripts/build.py depuis data/v7/).
   =================================================================== */
const V7 = window.CODEX_V7 || {verification:{}, coverage:[], corrections:[], audit:{issues:[]}, sources:{registry:{}}};
const V7_STATUS = {
  verifie_multi:      ['✓✓', 'Recoupé (≥ 2 sources)', 'ok'],
  verifie_source:     ['✓',  'Recoupé (1 source)', 'ok'],
  verifie_partiel:    ['◐',  'Partiellement recoupé', 'part'],
  corrige:            ['✎',  'Corrigé en V7', 'fix'],
  corrige_a_confirmer:['✎?', 'Corrigé en V7, à confirmer', 'fix'],
  conflit:            ['⚠',  'Sources en conflit', 'bad'],
  importe:            ['↧',  'Importé, non recoupé', 'imp'],
  non_source:         ['?',  'Sans source', 'none']
};
const V7_VERSION = V7.version || 'v7';

/* --- Migration de l'état (clé hyrule_codex_v1 conservée) --- */
state.schema = 7;
state.v7Reports = Array.isArray(state.v7Reports) ? state.v7Reports.filter(r => r && typeof r.text === 'string').slice(0, 500) : [];
save();

/* --- Provenance --- */
function v7KeyAtlas(p) {
  const id = String(p.id || '');
  if (id.startsWith('shrine_')) return 'shrines:' + id;
  if (id.startsWith('root_')) return 'lightroots:' + id;
  return 'atlas:' + id;
}
function v7Entry(key) { return V7.verification[key] || {s: 'non_source', n: 'Aucune source par fiche dans les données héritées.'}; }
function v7Badge(key, compact = false) {
  const e = v7Entry(key), st = V7_STATUS[e.s] || V7_STATUS.non_source;
  return `<span class="v7b v7b-${st[2]}" title="${escapeHTML(st[1] + (e.n ? ' — ' + e.n : ''))}">${st[0]}${compact ? '' : ' ' + escapeHTML(st[1])}</span>`;
}
function v7ProvenanceBlock(key, label) {
  const e = v7Entry(key), st = V7_STATUS[e.s] || V7_STATUS.non_source;
  const src = (e.src || []).map(u => `<li><a href="${escapeHTML(u)}" target="_blank" rel="noopener noreferrer">${escapeHTML(u.replace(/^https?:\/\/(www\.)?/, '').slice(0, 70))}</a></li>`).join('');
  return `<div class="v7-prov"><h4>🛡️ Fiabilité de cette fiche</h4><p>${v7Badge(key)}${e.f ? ` <span class="small">Champs recoupés : ${escapeHTML(e.f.join(', '))}</span>` : ''}</p>` +
    (e.n ? `<p class="small">${escapeHTML(e.n)}</p>` : '') +
    (src ? `<p class="small">Sources de recoupement :</p><ul class="v7-src">${src}</ul>` : '') +
    `<button class="btn mini ghost" data-v7-report="${escapeHTML(key)}" data-v7-label="${escapeHTML(label)}">⚑ Signaler une erreur</button></div>`;
}
function v7WireReports(root) {
  (root || document).querySelectorAll('[data-v7-report]').forEach(b => b.onclick = () => {
    const txt = prompt('Décris l’erreur (valeur constatée en jeu, coordonnées, etc.). Le signalement reste sur cet appareil.', '');
    if (txt === null || !txt.trim()) return;
    state.v7Reports.push({id: String(Date.now()), key: b.dataset.v7Report, label: b.dataset.v7Label || '', text: txt.trim().slice(0, 600), at: new Date().toISOString()});
    save(); toast('Signalement enregistré (onglet Fiabilité)');
  });
}

/* --- Badges dans les écrans hérités --- */
const v7OldMonCard = monCard;
monCard = function (m) {
  return v7OldMonCard(m).replace('<div class="tags">', '<div class="tags">' + v7Badge('bestiary:' + m.id, true));
};
const v7OldOpenDetail = openDetail;
openDetail = function (kind, id) {
  v7OldOpenDetail(kind, id);
  const box = document.querySelector('#detail-dimmer .detail'); if (!box) return;
  const key = (kind === 'monster' ? 'bestiary:' : kind === 'weapon' ? 'weapons:' : 'armors:') + id;
  const x = (kind === 'monster' ? DB.monsters : kind === 'weapon' ? DB.weapons : DB.armors).find(q => q.id === id);
  box.insertAdjacentHTML('beforeend', v7ProvenanceBlock(key, x ? x.name : id));
  if (kind === 'monster') box.insertAdjacentHTML('beforeend', `<button class="btn mini" id="v7-farm-from">💎 Où farmer ses butins ?</button>`);
  v7WireReports(box);
  const f = el('v7-farm-from'); if (f) f.onclick = () => { closeDetail(); v7Farm.monster = id; v7Farm.material = ''; goto('farmroute'); };
};
const v7OldOpenAtlas = openAtlas;
openAtlas = function (id) {
  v7OldOpenAtlas(id);
  const p = ATLAS.find(x => x.id === id), box = document.querySelector('#detail-dimmer .detail');
  if (!p || !box) return;
  box.insertAdjacentHTML('beforeend', v7ProvenanceBlock(v7KeyAtlas(p), p.name));
  v7WireReports(box);
};
const v7OldBosses = renderV6Bosses;
renderV6Bosses = function () {
  v7OldBosses();
  el('screen-bosses').querySelectorAll('[data-v6-open]').forEach(b => {
    const p = ATLAS.find(x => x.id === b.dataset.v6Open);
    if (p) b.querySelector('.v6-name')?.insertAdjacentHTML('beforeend', ' ' + v7Badge(v7KeyAtlas(p), true));
  });
  el('screen-bosses').querySelector('.v6-banner')?.insertAdjacentHTML('afterend',
    `<div class="note">ℹ️ Les effectifs par variante (Gigatraciens, Golemax, Griocks, Moldarquors) concordent avec une source externe ; <b>les positions individuelles restent « importées, non recoupées »</b> tant qu’elles n’ont pas été confirmées.</div>`);
};
const v7OldFusion = renderFusion;
renderFusion = function () {
  v7OldFusion();
  const c = {ok: 0, bad: 0, none: 0};
  for (const f of FUSIONS) { const s = v7Entry('fusion:' + f[0]).s; if (s.startsWith('verifie')) c.ok++; else if (s === 'conflit') c.bad++; else c.none++; }
  const list = FUSIONS.map(f => `<li>${v7Badge('fusion:' + f[0], true)} ${escapeHTML(f[0])} : +${f[1]}</li>`).join('');
  el('screen-fusion').insertAdjacentHTML('beforeend', `<details class="v7-details"><summary>🛡️ Fiabilité des bonus : ${c.ok} recoupés · ${c.bad} en conflit · ${c.none} non recoupés</summary><ul class="v7-list">${list}</ul><p class="small">Calcul affiché = puissance de base + bonus, hors multiplicateurs (armes à deux mains, lances, flèches qui doublent certains crocs et griffes, etc.).</p></details>`);
};
const v7OldWeapons = renderWeapons, v7OldArmor = renderArmor;
renderWeapons = function () { v7OldWeapons(); el('screen-weapons').querySelector('.section-head')?.insertAdjacentHTML('afterend', `<div class="note">${v7Badge('weapons:x', true)} Sélection héritée de V6, <b>sans source par fiche</b> : statistiques et lieux à vérifier. Le nombre total d’armes du jeu n’est pas établi ici.</div>`); };
renderArmor = function () { v7OldArmor(); el('screen-armor').querySelector('.section-head')?.insertAdjacentHTML('afterend', `<div class="note">${v7Badge('armors:x', true)} Ensembles hérités de V6, <b>sans source ni coûts d’amélioration</b>. À compléter.</div>`); };

/* --- Sauvegarde versionnée (compatible avec les fichiers V5/V6) --- */
function v7ExportObject() {
  return {app: 'hyrule-codex', version: 7, schema: 7, exported_at: new Date().toISOString(),
    questDone: state.questDone || {}, collectDone: state.collectDone || {}, collectNotes: state.collectNotes || {},
    inventory: state.inventory || {}, photos: state.photos || {}, owned: state.owned || {}, defeated: state.defeated || {},
    goals: state.goals || [], atlasDone: state.atlasDone || {}, checkCounts: state.checkCounts || {}, notes: state.notes || '',
    v7Reports: state.v7Reports || [], v7Armor: state.v7Armor || {}};
}
function v7Download(name, obj) {
  const blob = new Blob([JSON.stringify(obj, null, 2)], {type: 'application/json'});
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
function v7ApplyExtras(t) {
  if (typeof t.notes === 'string') state.notes = t.notes.slice(0, 20000);
  if (t.v7Armor && typeof t.v7Armor === 'object' && !Array.isArray(t.v7Armor)) state.v7Armor = Object.fromEntries(Object.entries(t.v7Armor).slice(0, 300).map(([k, v]) => [String(k).slice(0, 80), {own: !!v?.own, lvl: Math.max(0, Math.min(4, (v?.lvl | 0)))}]));
  if (Array.isArray(t.v7Reports)) state.v7Reports = t.v7Reports.filter(r => r && typeof r.text === 'string' && typeof r.key === 'string')
    .slice(0, 500).map(r => ({id: String(r.id || Date.now()), key: r.key.slice(0, 120), label: String(r.label || '').slice(0, 120), text: r.text.slice(0, 600), at: String(r.at || '')}));
  save();
}
const v7OldGoals = renderGoals;
renderGoals = function () {
  v7OldGoals();
  const ex = el('export-progress'), file = el('progress-file');
  if (ex) ex.onclick = () => v7Download('hyrule-codex-v7-sauvegarde.json', v7ExportObject());
  if (file) { const legacy = file.onchange; file.onchange = async e => {
    const f = e.target.files && e.target.files[0]; let t = null;
    try { t = JSON.parse(await f.text()); } catch (x) {}
    await legacy(e); if (t && typeof t === 'object') { v7ApplyExtras(t); } }; }
};

/* --- Parcours « Où farmer ? » : matériau → monstres → variantes → positions → circuit --- */
let v7Farm = {material: '', monster: '', layer: 'Toutes', start: '', onlyTodo: false, hideConflict: false, limit: 25};
const V7_FAMILY = {Lynels: 'Lynel', Hinox: 'Hinox', Lithoroks: 'Lithorok', Golemax: 'Golemax', 'Gigatraciens': 'Gigatracien', Griocks: 'Griock'};
function v7AtlasForMonster(m) {
  const fam = m.id === 'moldarquor' ? 'Moldarquor' : V7_FAMILY[m.type];
  if (!fam) return {fam: null, pts: [], exact: false};
  const all = ATLAS.filter(p => p.type === fam);
  const exact = all.filter(p => p.variant && norm(p.variant) === norm(m.name));
  if (exact.length) return {fam, pts: exact, exact: true};
  return {fam, pts: fam === 'Lynel' ? all : [], exact: false};
}
function v7MaterialIndex() {
  const map = new Map();
  const add = (name, mid, how) => { const k = norm(name); if (!k) return; if (!map.has(k)) map.set(k, {name, mons: new Map()}); map.get(k).mons.set(mid, how); };
  for (const mat of DB.materials) for (const id of mat.sources) add(mat.name, id, 'Sac/Farming V6');
  for (const m of DB.monsters) for (const l of m.loot) add(l, m.id, 'Fiche du monstre');
  return [...map.values()].sort((a, b) => a.name.localeCompare(b.name, 'fr'));
}
function v7ParseXYZ(s) { const n = String(s).match(/-?\d+/g); return n && n.length >= 2 ? n.slice(0, 3).map(Number) : null; }
function v7Route(points, start) {
  const left = points.slice(), out = []; let cur = start ? {x: start[0], y: start[1]} : left[0], total = 0;
  while (left.length) {
    let bi = 0, bd = Infinity;
    for (let i = 0; i < left.length; i++) { const d = Math.hypot(left[i].x - cur.x, left[i].y - cur.y); if (d < bd) { bd = d; bi = i; } }
    const p = left.splice(bi, 1)[0]; total += (out.length || start) ? bd : 0; out.push({p, leg: (out.length || start) ? bd : 0, total}); cur = p;
  }
  return out;
}
function renderFarmRoute() {
  const idx = v7MaterialIndex(), q = norm(v7Farm.material);
  const mats = q ? idx.filter(x => norm(x.name).includes(q)).slice(0, 12) : [];
  let mons = [];
  if (v7Farm.monster) { const m = findMonster(v7Farm.monster); if (m) mons = [m]; }
  else if (q) { const hit = idx.filter(x => norm(x.name).includes(q)); const ids = new Set(hit.flatMap(x => [...x.mons.keys()])); mons = DB.monsters.filter(m => ids.has(m.id)); }
  if (q && typeof V7_DROPS !== 'undefined') { const sc = m => { const t = v7DropTable(m.id); return t ? Math.max(0, ...t.rows.filter(r => norm((v7Fr(r.item) || '') + ' ' + r.item).includes(q)).map(r => r.chance)) : -1; }; mons.sort((a, b) => sc(b) - sc(a)); }
  let pts = [], rows = '';
  for (const m of mons) {
    const r = v7AtlasForMonster(m);
    const keep = r.pts.filter(p => (v7Farm.layer === 'Toutes' || p.layer === v7Farm.layer) && (!v7Farm.onlyTodo || !state.atlasDone?.[p.id]) && (!v7Farm.hideConflict || v7Entry(v7KeyAtlas(p)).s !== 'conflit'));
    pts.push(...keep);
    rows += `<div class="v7-mon"><button class="v7-link" data-v7-mon="${m.id}">${m.icon} <b>${escapeHTML(m.name)}</b></button> ${v7Badge('bestiary:' + m.id, true)}${typeof v7DropHint === 'function' ? v7DropHint(m.id) : ''}
      <span class="small">${m.hp == null ? 'PV inconnus' : m.hp.toLocaleString('fr-FR') + ' PV'} · ${r.fam ? (r.exact ? keep.length + ' position(s) de cette variante' : (r.fam === 'Lynel' ? keep.length + ' Lynel(s) — variante non renseignée dans l’atlas' : 'variante absente de l’atlas')) : 'aucune position dans l’atlas'}</span></div>`;
  }
  pts = [...new Map(pts.map(p => [p.id, p])).values()];
  const start = v7ParseXYZ(v7Farm.start);
  const layers = new Set(pts.map(p => p.layer));
  const route = layers.size <= 1 ? v7Route(pts, start) : [];
  const shown = route.slice(0, v7Farm.limit);
  const list = layers.size > 1 ? `<div class="note">Les positions sont sur plusieurs couches (${[...layers].join(', ')}). Choisis une couche pour calculer un circuit.</div>` :
    shown.map((r, i) => `<div class="v7-step ${state.atlasDone?.[r.p.id] ? 'v6-cleared' : ''}"><span class="v7-n">${i + 1}</span><button class="v7-link" data-v7-open="${escapeHTML(r.p.id)}"><b>${escapeHTML(r.p.variant || r.p.name)}</b><small>${escapeHTML(r.p.layer)} · ${formattedCoord(r.p)}${r.leg ? ' · +' + Math.round(r.leg) + ' u' : ''}</small></button>${v7Badge(v7KeyAtlas(r.p), true)}<button class="icon-btn ${state.atlasDone?.[r.p.id] ? 'is-on' : ''}" data-v7-done="${escapeHTML(r.p.id)}" aria-label="Cocher">✓</button></div>`).join('');
  el('screen-farmroute').innerHTML = section('Où farmer ?', 'Matériau → monstres → variante → positions → circuit le plus court (distance à vol d’oiseau).') +
    `<div class="v7-farmbox"><label class="search">⌕ <input id="v7-mat" value="${escapeHTML(v7Farm.material)}" placeholder="Matériau : corne, croc, diamant, sonium…" aria-label="Matériau recherché"></label>
     ${mats.length && !v7Farm.monster ? `<div class="v7-chips">${mats.map(x => `<button class="v5-pill" data-v7-mat="${escapeHTML(x.name)}">${escapeHTML(x.name)}</button>`).join('')}</div>` : ''}
     ${v7Farm.monster ? `<div class="statuspill">Monstre choisi : <b>${escapeHTML(findMonster(v7Farm.monster)?.name || '')}</b> <button class="btn mini ghost" id="v7-clear-mon">✕</button></div>` : ''}
     <div class="v7-row"><select id="v7-layer" aria-label="Couche">${['Toutes', 'Surface', 'Ciel', 'Profondeurs'].map(l => `<option ${v7Farm.layer === l ? 'selected' : ''}>${l}</option>`).join('')}</select>
     <input id="v7-start" inputmode="numeric" value="${escapeHTML(v7Farm.start)}" placeholder="Départ X Y Z (facultatif)" aria-label="Coordonnées de départ"></div>
     <div class="v7-row"><label class="v5-check"><input type="checkbox" id="v7-todo" ${v7Farm.onlyTodo ? 'checked' : ''}> Non cochés</label><label class="v5-check"><input type="checkbox" id="v7-noconf" ${v7Farm.hideConflict ? 'checked' : ''}> Masquer les positions en conflit</label></div></div>` +
    (mons.length ? `<h3 class="subhead">👹 Monstres qui donnent ce butin (${mons.length})</h3><div class="v7-mons">${rows}</div>` : (q || v7Farm.monster ? '<div class="emptybox">Aucun monstre ne liste ce butin dans les fiches actuelles. Les butins V6 ne sont pas exhaustifs.</div>' : '<div class="emptybox">Saisis un matériau pour commencer.</div>')) +
    (pts.length ? `<h3 class="subhead">🧭 Circuit (${pts.length} position(s)${route.length ? ' · ' + Math.round(route[route.length - 1].total) + ' u au total' : ''})</h3><div class="v7-route">${list}</div>${route.length > v7Farm.limit ? '<button class="btn ghost" id="v7-more">Afficher plus</button>' : ''}` : '') +
    `<div class="sourcebox">Les butins listés sont <b>possibles</b>, sans probabilité importée (sauf mention dans une fiche). Distances calculées en X/Y, sans tenir compte du relief, des gouffres ni des téléportations. Après une Lune de sang, les monstres réapparaissent.</div>`;
  const s = el('screen-farmroute');
  el('v7-mat').oninput = e => { v7Farm.material = e.target.value; v7Farm.monster = ''; v7Farm.limit = 25; renderFarmRoute(); const i = el('v7-mat'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); };
  el('v7-layer').onchange = e => { v7Farm.layer = e.target.value; renderFarmRoute(); };
  el('v7-start').onchange = e => { v7Farm.start = e.target.value; renderFarmRoute(); };
  el('v7-todo').onchange = e => { v7Farm.onlyTodo = e.target.checked; renderFarmRoute(); };
  el('v7-noconf').onchange = e => { v7Farm.hideConflict = e.target.checked; renderFarmRoute(); };
  if (el('v7-clear-mon')) el('v7-clear-mon').onclick = () => { v7Farm.monster = ''; renderFarmRoute(); };
  if (el('v7-more')) el('v7-more').onclick = () => { v7Farm.limit += 25; renderFarmRoute(); };
  s.querySelectorAll('[data-v7-mat]').forEach(b => b.onclick = () => { v7Farm.material = b.dataset.v7Mat; renderFarmRoute(); });
  s.querySelectorAll('[data-v7-mon]').forEach(b => b.onclick = () => openDetail('monster', b.dataset.v7Mon));
  s.querySelectorAll('[data-v7-open]').forEach(b => b.onclick = () => openAtlas(b.dataset.v7Open));
  s.querySelectorAll('[data-v7-done]').forEach(b => b.onclick = () => { state.atlasDone = state.atlasDone || {}; const id = b.dataset.v7Done; state.atlasDone[id] = !state.atlasDone[id]; save(); renderFarmRoute(); });
}

/* --- Écran « Fiabilité » --- */
let v7AuditFilter = 'erreur';
function renderReliability() {
  const counts = {}; for (const v of Object.values(V7.verification)) counts[v.s] = (counts[v.s] || 0) + 1;
  const total = Object.values(counts).reduce((a, b) => a + b, 0);
  const legend = Object.entries(V7_STATUS).map(([k, v]) => `<div class="v7-leg"><span class="v7b v7b-${v[2]}">${v[0]}</span> ${v[1]} <b>${counts[k] || 0}</b></div>`).join('');
  const cov = V7.coverage.map(c => `<tr><td>${escapeHTML(c.cat)}</td><td>${c.present}</td><td>${c.expected == null ? '<i>non établi</i>' : c.expected + (c.expected_status === 'conflit' ? ' ⚠' : c.expected_status === 'non_verifie' ? ' ?' : '')}</td><td>${c.verified}<small> ${escapeHTML(c.verified_what)}</small></td><td class="small">${escapeHTML(c.note || '')}${(c.expected_src || []).map(u => ` <a href="${escapeHTML(u)}" target="_blank" rel="noopener noreferrer">↗</a>`).join('')}</td></tr>`).join('');
  const corr = V7.corrections.map(c => `<li><b>${escapeHTML(c.key)}</b> · ${escapeHTML(c.field)} : <s>${escapeHTML(c.old == null ? '—' : c.old)}</s> → <b>${escapeHTML(c.new)}</b> <span class="v7b v7b-fix">${escapeHTML((V7_STATUS[c.status] || V7_STATUS.corrige)[1])}</span><br><span class="small">${escapeHTML(c.why)}</span></li>`).join('');
  const issues = (V7.audit.issues || []).filter(i => v7AuditFilter === 'tout' || i.severity === v7AuditFilter);
  const reports = state.v7Reports.map(r => `<li><b>${escapeHTML(r.label || r.key)}</b> <span class="small">${escapeHTML(r.at.slice(0, 10))}</span><br>${escapeHTML(r.text)} <button class="btn mini ghost" data-v7-del="${escapeHTML(r.id)}">Supprimer</button></li>`).join('');
  const reg = Object.values(V7.sources.registry || {}).map(u => `<li><a href="${escapeHTML(u)}" target="_blank" rel="noopener noreferrer">${escapeHTML(u.replace(/^https?:\/\/(www\.)?/, ''))}</a></li>`).join('');
  el('screen-reliability').innerHTML = section('Fiabilité des données', 'Ce qui est recoupé, importé, corrigé ou en conflit. Aucune donnée n’a été testée en jeu par l’auteur de V7.') +
    `<div class="v7-legend">${legend}<div class="small">${total} enregistrements suivis · version ${escapeHTML(V7_VERSION)} · recherches du ${escapeHTML(V7.sources.collected_at || '?')}</div></div>
    <h3 class="subhead">📊 Couverture (présent / attendu / recoupé)</h3><div class="v7-tablewrap"><table class="v7-table"><thead><tr><th>Catégorie</th><th>Présent</th><th>Attendu</th><th>Recoupé</th><th>Notes</th></tr></thead><tbody>${cov}</tbody></table></div>
    <p class="small">« Attendu » n’est affiché que si une source donne le total. « Non établi » : impossible de calculer un taux de complétude honnête.</p>
    <h3 class="subhead">✎ Corrections appliquées en V7 (${V7.corrections.length})</h3><ul class="v7-list">${corr}</ul>
    <h3 class="subhead">🔍 Audit automatique</h3><div class="v5-pills">${['erreur', 'avertissement', 'info', 'tout'].map(s => `<button class="v5-pill ${v7AuditFilter === s ? 'active' : ''}" data-v7-af="${s}">${s} ${s === 'tout' ? (V7.audit.issues || []).length : (V7.audit.summary || {})[s] || 0}</button>`).join('')}</div>
    <ul class="v7-list">${issues.slice(0, 150).map(i => `<li><b>${escapeHTML(i.category)}</b> · ${escapeHTML(i.id)}<br><span class="small">${escapeHTML(i.message)}</span></li>`).join('') || '<li>Aucun élément.</li>'}</ul>
    <h3 class="subhead">⚑ Mes signalements (${state.v7Reports.length})</h3><ul class="v7-list">${reports || '<li class="small">Aucun. Utilise « Signaler une erreur » dans une fiche.</li>'}</ul>
    <div class="toolbar"><button class="btn mini" id="v7-exp-reports">⬇ Exporter les signalements</button><button class="btn mini ghost" id="v7-exp-all">⬇ Sauvegarde complète V7</button></div>
    <h3 class="subhead">📚 Sources de recoupement</h3><ul class="v7-list v7-src">${reg}</ul>
    <div class="sourcebox">Statuts « recoupé » = la valeur concorde avec une source externe <b>distincte</b> de la source d’import (GamerTW). Ce n’est pas une preuve en jeu. Les noms des sources n’impliquent aucune affiliation.</div>`;
  const s = el('screen-reliability');
  s.querySelectorAll('[data-v7-af]').forEach(b => b.onclick = () => { v7AuditFilter = b.dataset.v7Af; renderReliability(); });
  s.querySelectorAll('[data-v7-del]').forEach(b => b.onclick = () => { state.v7Reports = state.v7Reports.filter(r => r.id !== b.dataset.v7Del); save(); renderReliability(); });
  el('v7-exp-reports').onclick = () => v7Download('hyrule-codex-signalements.json', {app: 'hyrule-codex', version: 7, exported_at: new Date().toISOString(), reports: state.v7Reports});
  el('v7-exp-all').onclick = () => v7Download('hyrule-codex-v7-sauvegarde.json', v7ExportObject());
}

/* --- Navigation et accueil --- */
navs.splice(3, 0, ['farmroute', '🧭', 'Où farmer ?']);
navs.push(['reliability', '🛡️', 'Fiabilité']);
const V7_SCREENS = {farmroute: renderFarmRoute, reliability: renderReliability};
const v7OldRender = render;
render = function () { if (V7_SCREENS[state.tab]) { showScreen(); renderStats(); V7_SCREENS[state.tab](); return; } v7OldRender(); };
const v7OldHome = renderHome;
renderHome = function () {
  v7OldHome();
  const ok = Object.values(V7.verification).filter(v => v.s.startsWith('verifie')).length, n = Object.keys(V7.verification).length;
  el('screen-home').insertAdjacentHTML('afterbegin', `<div class="v7-home"><button data-v7home="farmroute"><span>🧭</span><b>Où farmer ?</b><small>Matériau → monstres → positions → circuit.</small></button><button data-v7home="reliability"><span>🛡️</span><b>Fiabilité</b><small>${ok} / ${n} enregistrements recoupés, conflits et corrections visibles.</small></button></div>`);
  el('screen-home').querySelectorAll('[data-v7home]').forEach(b => b.onclick = () => goto(b.dataset.v7home));
};

/* ===================================================================
   V7.1 — Encyclopédie sourcée : arsenal (174), armures + améliorations (135),
   recettes (228), ennemis communs (69). Données : CODEX_V7.encyclo.
   =================================================================== */
const ENC = V7.encyclo || {armor: {pieces: [], recipes: {}, sets: [], fx: {}}, weapons: {items: [], kinds: {}, fx: {}}, enemies: {items: []}, recipes: {items: [], thresholds: [], rules: []}};
state.v7Armor = state.v7Armor && typeof state.v7Armor === 'object' ? state.v7Armor : {};
const v7SrcNote = b => `<div class="sourcebox">📚 Source : <a href="${escapeHTML(b.source_url)}" target="_blank" rel="noopener noreferrer">${escapeHTML(b.source_title)}</a> · relevé le ${escapeHTML(b.collected_at)}. ${escapeHTML(b.note)} <span class="v7b v7b-imp">↧ Source unique, non recoupée</span></div>`;
const v7Fx = e => { const fr = ENC.armor.fx[e]; return fr && fr !== '—' ? `${escapeHTML(fr)} <small class="muted">(${escapeHTML(e)})</small>` : (e === 'None' ? '—' : escapeHTML(e)); };
const v7Coord = a => a.map(v => (v < 0 ? '-' : '') + String(Math.abs(v)).padStart(4, '0')).join(' / ');

/* --- Arsenal complet --- */
let v7W = {q: '', kind: 'all', sort: 'no', fuse: -1};

/* V7.12 — noms français (Zelda Wiki) : FR d'abord, nom anglais officiel en second. */
const V7_FRN = V7.fr_names || {totk: {}, weapons_botw: {}};
function v7Fr(en) { return (V7_FRN.totk || {})[en] || ''; }
function v7FrW(en) { return v7Fr(en) || (V7_FRN.weapons_botw || {})[en] || ''; }
function v7FrLabel(en) { const f = v7Fr(en); return f ? `${escapeHTML(f)} <span class="v7-en">(${escapeHTML(en)})</span>` : escapeHTML(en); }
function renderArsenal() {
  const W = ENC.weapons, q = norm(v7W.q);
  let items = W.items.filter(i => (v7W.kind === 'all' || i.kind === v7W.kind) && norm(i.name + ' ' + v7FrW(i.name) + ' ' + (i.effect || '')).includes(q));
  const pw = i => parseInt(i.power) || 0;
  items.sort((a, b) => v7W.sort === 'power' ? pw(b) - pw(a) : v7W.sort === 'dur' ? (b.durability || 0) - (a.durability || 0) : a.no - b.no);
  const fz = FUSIONS[v7W.fuse];
  el('screen-arsenal').innerHTML = section('Arsenal complet', `${W.items.length} armes, arcs et boucliers (Compendium n° ${W.compendium_range.join('–')}) : puissance ou défense de base et durabilité.`) +
    `<div class="v7-farmbox"><label class="search">⌕ <input id="v7w-q" value="${escapeHTML(v7W.q)}" placeholder="Nom français ou anglais, effet (ex. royale, zora, Gloom)…" aria-label="Recherche arsenal"></label>
     <div class="v7-row"><select id="v7w-kind" aria-label="Type"><option value="all">Tous les types</option>${Object.entries(W.kinds).map(([k, v]) => `<option value="${k}" ${v7W.kind === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
     <select id="v7w-sort" aria-label="Tri"><option value="no" ${v7W.sort === 'no' ? 'selected' : ''}>N° du Compendium</option><option value="power" ${v7W.sort === 'power' ? 'selected' : ''}>Puissance</option><option value="dur" ${v7W.sort === 'dur' ? 'selected' : ''}>Durabilité</option></select></div>
     <div class="v7-row"><select id="v7w-fuse" aria-label="Amalgame"><option value="-1">Sans amalgame</option>${FUSIONS.map((f, i) => `<option value="${i}" ${v7W.fuse === i ? 'selected' : ''}>+${f[1]} ${escapeHTML(f[0])}</option>`).join('')}</select></div></div>
     <div class="statuspill">${items.length} résultat(s)${fz ? ` · colonne « + amalgame » = base + ${fz[1]} (hors multiplicateurs : deux mains, lances, flèches)` : ''}</div>
     <div class="v7-tablewrap"><table class="v7-table"><thead><tr><th>N°</th><th>Nom</th><th>Type</th><th>Base</th>${fz ? '<th>+ amalgame</th>' : ''}<th>Durab.</th><th>Effet</th></tr></thead><tbody>${items.map(i => `<tr><td>${i.no}</td><td>${v7Badge('arsenal:' + i.name, true)} <b>${escapeHTML(v7FrW(i.name) || i.name)}</b>${v7FrW(i.name) ? `<br><span class="v7-en">${escapeHTML(i.name)}${v7Fr(i.name) || (V7_FRN.weapons_confirmed || []).includes(i.name) ? '' : (V7_FRN.weapons_manual || []).includes(i.name) ? ' · nom FR apparié manuellement' : ' · nom FR de BotW, à confirmer'}</span>` : ''}${i.flag ? `<br><span class="v7b v7b-bad" title="${escapeHTML(i.flag)}">⚠ ${escapeHTML(i.flag)}</span>` : ''}</td><td class="small">${escapeHTML(W.kinds[i.kind])}</td><td>${escapeHTML(i.power)}</td>${fz ? `<td>${i.kind === 'SH' || /x/.test(i.power) ? '—' : pw(i) + fz[1]}</td>` : ''}<td>${i.durability ?? '—'}</td><td class="small">${i.effect ? escapeHTML(i.effect) + (W.fx[i.effect] ? `<br><span class="muted">${escapeHTML(W.fx[i.effect])}</span>` : '') : '—'}</td></tr>`).join('')}</tbody></table></div>
     <p class="small">Les armes trouvées « dégradées » et les bonus aléatoires (étincelle dorée) ne sont pas listés. Les arcs « 15 x3 » tirent trois flèches. Explications d’effet : traductions descriptives, non officielles.</p>` + v7SrcNote(W);
  el('v7w-q').oninput = e => { v7W.q = e.target.value; renderArsenal(); const i = el('v7w-q'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); };
  el('v7w-kind').onchange = e => { v7W.kind = e.target.value; renderArsenal(); };
  el('v7w-sort').onchange = e => { v7W.sort = e.target.value; renderArsenal(); };
  el('v7w-fuse').onchange = e => { v7W.fuse = +e.target.value; renderArsenal(); };
}

/* --- Armures & améliorations --- */
let v7A = {q: '', set: 'all', only: 'all', target: 4};
const v7AGet = n => { const v = state.v7Armor[n] || {}; return {own: !!v.own, lvl: Math.max(0, Math.min(4, v.lvl | 0))}; };
function v7ANeeds(pieces, target) {
  const need = new Map(); let rupees = 0;
  for (const p of pieces) {
    if (!p.recipe) continue; const st = v7AGet(p.name), tiers = ENC.armor.recipes[p.recipe];
    const fees = p.name === "Ancient Hero's Aspect" ? ENC.armor.fees_aspect : ENC.armor.fees;
    for (let t = st.lvl; t < target; t++) { rupees += fees[t]; for (const m of tiers[t].mats) need.set(m.n, (need.get(m.n) || 0) + m.q); }
  }
  return {need: [...need.entries()].sort((a, b) => b[1] - a[1]), rupees};
}
function renderArmorPro() {
  const A = ENC.armor, q = norm(v7A.q), sets = [...new Set(A.pieces.map(p => p.set))].sort();
  const list = A.pieces.filter(p => (v7A.set === 'all' || p.set === v7A.set) && norm(p.name + ' ' + (p.fr || '') + ' ' + p.set + ' ' + p.effect + ' ' + (A.fx[p.effect] || '') + ' ' + p.how).includes(q) &&
    (v7A.only === 'all' || (v7A.only === 'own' ? v7AGet(p.name).own : v7A.only === 'missing' ? !v7AGet(p.name).own : p.recipe))).sort((x, y) => (x.fr || x.name).localeCompare(y.fr || y.name, 'fr'));
  const owned = A.pieces.filter(p => v7AGet(p.name).own);
  const plan = v7ANeeds(owned, v7A.target);
  el('screen-armorpro').innerHTML = section('Armures & améliorations', `${A.pieces.length} pièces, ${A.pieces.filter(p => p.recipe).length} améliorables aux Grandes Fées (4 paliers), ${A.sets.length} ensembles.`) +
    `<div class="v6-banner"><span>🛡️</span><div><small>PIÈCES POSSÉDÉES</small><strong>${owned.length} / ${A.pieces.length}</strong><small>Coût restant jusqu’à ★${v7A.target} : ${plan.rupees.toLocaleString('fr-FR')} rubis · ${plan.need.length} matériaux différents</small></div></div>
     <div class="v7-farmbox"><label class="search">⌕ <input id="v7a-q" value="${escapeHTML(v7A.q)}" placeholder="Pièce, ensemble, effet, lieu…" aria-label="Recherche armures"></label>
     <div class="v7-row"><select id="v7a-set" aria-label="Ensemble"><option value="all">Tous les ensembles</option>${sets.map(s => `<option ${v7A.set === s ? 'selected' : ''}>${escapeHTML(s)}</option>`).join('')}</select>
     <select id="v7a-only" aria-label="Filtre"><option value="all">Toutes</option><option value="own" ${v7A.only === 'own' ? 'selected' : ''}>Possédées</option><option value="missing" ${v7A.only === 'missing' ? 'selected' : ''}>À obtenir</option><option value="up" ${v7A.only === 'up' ? 'selected' : ''}>Améliorables</option></select></div></div>
     <div class="v7-armorlist">${list.map(p => { const st = v7AGet(p.name); return `<div class="v7-arow ${st.own ? 'v7-own' : ''}"><button class="v7-link" data-v7a-open="${escapeHTML(p.name)}"><b>${escapeHTML(p.fr || p.name)}</b><small>${p.fr ? escapeHTML(p.name) + ' · ' : ''}${escapeHTML(p.set)} · ${v7Fx(p.effect)} · DEF ${p.base} → ${p.max}</small></button>
       <label class="v5-check"><input type="checkbox" data-v7a-own="${escapeHTML(p.name)}" ${st.own ? 'checked' : ''}> Possédée</label>
       ${p.recipe ? `<select data-v7a-lvl="${escapeHTML(p.name)}" aria-label="Niveau actuel">${[0, 1, 2, 3, 4].map(l => `<option value="${l}" ${st.lvl === l ? 'selected' : ''}>${l ? '★'.repeat(l) : '☆ base'}</option>`).join('')}</select>` : '<span class="small">non améliorable</span>'}</div>`; }).join('') || '<div class="emptybox">Aucune pièce.</div>'}</div>
     <h3 class="subhead">🧾 Liste de courses (pièces possédées → ★${v7A.target})</h3>
     <div class="v7-row"><select id="v7a-target" aria-label="Palier visé">${[1, 2, 3, 4].map(t => `<option value="${t}" ${v7A.target === t ? 'selected' : ''}>Viser ★${t}${t === 2 ? ' (active la plupart des bonus d’ensemble)' : ''}</option>`).join('')}</select>
     <button class="btn mini" id="v7a-bag" ${plan.need.length ? '' : 'disabled'}>➕ Ajouter au Sac à butin</button></div>
     ${plan.need.length ? `<ul class="v7-list">${plan.need.map(([n, k]) => `<li><b>${k}×</b> ${v7FrLabel(n)} <button class="btn mini ghost" data-v7a-farm="${escapeHTML(n)}">Où farmer ?</button></li>`).join('')}</ul>` : '<p class="small">Coche les pièces possédées et leur niveau pour calculer les matériaux restants.</p>'}
     <h3 class="subhead">🎽 Bonus d’ensemble (pièces à ★★ minimum, sauf ensembles fixes)</h3>
     <div class="v7-tablewrap"><table class="v7-table"><thead><tr><th>Ensemble</th><th>Effet des pièces</th><th>Bonus complet</th></tr></thead><tbody>${A.sets.map(s => `<tr><td>${escapeHTML(s.set)}</td><td class="small">${v7Fx(s.effect)}</td><td class="small">${v7Fx(s.bonus)}</td></tr>`).join('')}</tbody></table></div>
     <p class="small">Frais par palier : ${A.fees.join(' / ')} rubis (×3 pour l’Aspect du héros antique). Effets en français : traductions descriptives.</p>` + v7SrcNote(A);
  const s = el('screen-armorpro');
  el('v7a-q').oninput = e => { v7A.q = e.target.value; renderArmorPro(); const i = el('v7a-q'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); };
  el('v7a-set').onchange = e => { v7A.set = e.target.value; renderArmorPro(); };
  el('v7a-only').onchange = e => { v7A.only = e.target.value; renderArmorPro(); };
  el('v7a-target').onchange = e => { v7A.target = +e.target.value; renderArmorPro(); };
  s.querySelectorAll('[data-v7a-own]').forEach(b => b.onchange = () => { const n = b.dataset.v7aOwn, v = v7AGet(n); v.own = b.checked; state.v7Armor[n] = v; save(); renderArmorPro(); });
  s.querySelectorAll('[data-v7a-lvl]').forEach(b => b.onchange = () => { const n = b.dataset.v7aLvl, v = v7AGet(n); v.lvl = +b.value; v.own = true; state.v7Armor[n] = v; save(); renderArmorPro(); });
  s.querySelectorAll('[data-v7a-open]').forEach(b => b.onclick = () => v7ArmorDetail(b.dataset.v7aOpen));
  s.querySelectorAll('[data-v7a-farm]').forEach(b => b.onclick = () => { v7Farm.material = b.dataset.v7aFarm; v7Farm.monster = ''; goto('farmroute'); });
  el('v7a-bag').onclick = () => { for (const [n, k] of plan.need) { const cur = bagGet(n); state.inventory[n] = {have: cur.have, want: Math.max(cur.want, k)}; } save(); toast(plan.need.length + ' matériaux ajoutés au Sac à butin'); };
}
function v7ArmorDetail(name) {
  const p = ENC.armor.pieces.find(x => x.name === name); if (!p) return;
  const tiers = p.recipe ? ENC.armor.recipes[p.recipe] : [], fees = p.name === "Ancient Hero's Aspect" ? ENC.armor.fees_aspect : ENC.armor.fees;
  const html = `<div class="detail"><button class="close" id="close-detail">✕ Fermer</button><div class="eyebrow">🛡️ ARMURE · ${escapeHTML(p.set)}</div><h2>${escapeHTML(p.fr || p.name)}</h2>${p.fr ? `<p class="small">Nom anglais officiel : ${escapeHTML(p.name)}</p>` : ''}
    <div class="tags"><span class="tag gold">DEF ${p.base} → ${p.max}</span><span class="tag">${v7Fx(p.effect)}</span></div>
    <h4>📍 Obtention</h4><p>${escapeHTML(p.how)}</p><p><b>XYZ</b> ${v7Coord(p.xyz)} <button class="btn mini ghost" id="v7a-copy">Copier</button></p>
    ${tiers.length ? `<h4>✨ Améliorations (Grande Fée)</h4><div class="v7-tablewrap"><table class="v7-table"><thead><tr><th>Palier</th><th>DEF</th><th>Rubis</th><th>Matériaux</th></tr></thead><tbody>${tiers.map((t, i) => `<tr><td>${'★'.repeat(i + 1)}</td><td>${t.def}</td><td>${fees[i]}</td><td class="small">${t.mats.map(m => `${m.q}× ${escapeHTML(v7Fr(m.n) || m.n)}`).join('<br>')}</td></tr>`).join('')}</tbody></table></div>` : '<p class="small">Pièce non améliorable (défense fixe).</p>'}
    <div class="note">Nom français : Puissance-Zelda. Matériaux : nom français Zelda Wiki. Coordonnées = point de collecte ou entrée proche.</div>
    ${v7ProvenanceBlock('armor:' + p.name, p.fr || p.name)}</div>`;
  el('modalroot').innerHTML = `<div class="detail-dimmer" id="detail-dimmer" role="dialog" aria-modal="true">${html}</div>`;
  el('close-detail').onclick = closeDetail; el('detail-dimmer').onclick = e => { if (e.target === el('detail-dimmer')) closeDetail(); };
  el('v7a-copy').onclick = async () => { const c = v7Coord(p.xyz); try { await navigator.clipboard.writeText(c); toast('Coordonnées copiées : ' + c); } catch (e) { toast(c); } };
  v7WireReports(el('modalroot')); document.body.style.overflow = 'hidden';
}

/* --- Livre de recettes (228) : coches partagées avec Collection 100 % (ids recipe_0001…) --- */
let v7R = {q: '', cat: 'all', todo: false, limit: 60};
const v7RId = no => 'recipe_' + String(no).padStart(4, '0');
function renderRecipeBook() {
  const R = ENC.recipes, q = norm(v7R.q);
  const items = R.items.filter(r => (v7R.cat === 'all' || r.cat === v7R.cat) && (!v7R.todo || !state.collectDone[v7RId(r.no)]) && norm(r.no + ' ' + r.name + ' ' + (r.fr || '') + ' ' + (r.fr_zw || '') + ' ' + (r.ing_fr || '') + ' ' + r.formula + ' ' + (r.effect || '')).includes(q));
  const done = R.items.filter(r => state.collectDone[v7RId(r.no)]).length;
  el('screen-recipes').innerHTML = section('Livre de recettes', `Les ${R.items.length} entrées numérotées du livre de recettes, avec une formule valide pour chacune.`) +
    `<div class="v5-feature"><div><div class="eyebrow">LIVRE DE RECETTES</div><strong class="v5-number">${done}<small> / ${R.items.length}</small></strong><div class="small">${Object.entries(R.split).map(([k, v]) => `${k} : ${v}`).join(' · ')}</div></div><div class="v5-ring" style="--p:${Math.round(done / R.items.length * 100)}%"><span>${Math.round(done / R.items.length * 100)} %</span></div></div>
     <div class="v7-farmbox"><label class="search">⌕ <input id="v7r-q" value="${escapeHTML(v7R.q)}" placeholder="N°, plat ou ingrédient (ex. 126, curry, fromage)…" aria-label="Recherche recettes"></label>
     <div class="v7-row"><select id="v7r-cat" aria-label="Catégorie"><option value="all">Toutes catégories</option>${Object.keys(R.split).map(c => `<option ${v7R.cat === c ? 'selected' : ''}>${c}</option>`).join('')}</select><label class="v5-check"><input type="checkbox" id="v7r-todo" ${v7R.todo ? 'checked' : ''}> À obtenir</label></div></div>
     <div class="v5-list">${items.slice(0, v7R.limit).map(r => `<label class="v5-row ${state.collectDone[v7RId(r.no)] ? 'v5-done' : ''}"><input type="checkbox" data-v7r="${r.no}" ${state.collectDone[v7RId(r.no)] ? 'checked' : ''}><span class="v7-n">${r.no}</span><span><b>${escapeHTML(r.fr_zw || r.fr || r.name)}</b><small class="muted"> · ${r.fr ? escapeHTML(r.name) + ' · ' : ''}${escapeHTML(r.cat)}${r.effect ? ' · ' + escapeHTML(r.effect) : ''}</small><br><span class="small">${escapeHTML(r.ing_fr || r.formula)}</span></span></label>`).join('') || '<div class="emptybox">Aucune recette.</div>'}</div>
     ${items.length > v7R.limit ? `<button class="btn ghost" id="v7r-more">Afficher plus (${items.length - v7R.limit})</button>` : ''}
     <details class="v7-details"><summary>⚗️ Seuils d’effets et règles de cuisine</summary><div class="v7-tablewrap"><table class="v7-table"><thead><tr><th>Effet</th><th>Niv. 2</th><th>Niv. 3</th><th>Points par ingrédient</th></tr></thead><tbody>${R.thresholds.map(t => `<tr><td>${escapeHTML(t[0])}</td><td>${escapeHTML(t[1])}</td><td>${escapeHTML(t[2])}</td><td class="small">${escapeHTML(t[3])}</td></tr>`).join('')}</tbody></table></div><ul class="v7-list">${R.rules.map(x => `<li>${escapeHTML(x)}</li>`).join('')}</ul></details>
     <p class="small">Les coches sont partagées avec Collection 100 % → « Recettes du jeu ». Une variante d’effet (ex. brochette « Attaque + ») remplit la même entrée.</p>` + v7SrcNote(R);
  el('v7r-q').oninput = e => { v7R.q = e.target.value; v7R.limit = 60; renderRecipeBook(); const i = el('v7r-q'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); };
  el('v7r-cat').onchange = e => { v7R.cat = e.target.value; v7R.limit = 60; renderRecipeBook(); };
  el('v7r-todo').onchange = e => { v7R.todo = e.target.checked; v7R.limit = 60; renderRecipeBook(); };
  if (el('v7r-more')) el('v7r-more').onclick = () => { v7R.limit += 60; renderRecipeBook(); };
  el('screen-recipes').querySelectorAll('[data-v7r]').forEach(b => b.onchange = () => { markCollect(v7RId(+b.dataset.v7r), b.checked); renderRecipeBook(); });
}

/* --- Ennemis communs sourcés : dans les fiches du bestiaire + liste des absents --- */
const V7_RB = new Map(ENC.enemies.items.filter(e => e.v6_id).map(e => [e.v6_id, e]));
const v7OldOpenDetail2 = openDetail;
openDetail = function (kind, id) {
  v7OldOpenDetail2(kind, id);
  const e = kind === 'monster' && V7_RB.get(id), box = document.querySelector('#detail-dimmer .v7-prov');
  if (!e || !box) return;
  box.insertAdjacentHTML('beforebegin', `<div class="v7-prov"><h4>📊 Fiche sourcée (${v7FrLabel(e.name)})</h4><p><b>PV</b> ${e.hp}${e.melee != null ? ` · <b>Attaque mêlée</b> ${e.melee}` : ''}${e.ranged != null ? ` · <b>Distance</b> ${e.ranged}` : ''}</p><p><b>Butins possibles</b> : ${e.drops.map(v7FrLabel).join(', ')}</p>${e.regions.length ? `<p class="small">Exemples de régions : ${escapeHTML(e.regions.join(', '))}</p>` : ''}<p class="small">Sans taux de butin. Source : <a href="${escapeHTML(ENC.enemies.source_url)}" target="_blank" rel="noopener noreferrer">RankedBoost</a> (source unique).</p></div>`);
};
const v7OldBestiary = renderBestiary;
renderBestiary = function () {
  v7OldBestiary();
  const extra = ENC.enemies.items.filter(e => !e.v6_id);
  el('screen-bestiary').insertAdjacentHTML('beforeend', `<details class="v7-details"><summary>➕ ${extra.length} autres ennemis (fiches sourcées)</summary><div class="v7-tablewrap"><table class="v7-table"><thead><tr><th>Ennemi</th><th>PV</th><th>Butins possibles</th><th>Régions</th></tr></thead><tbody>${extra.map(e => `<tr><td>${v7FrLabel(e.name)}</td><td>${e.hp}</td><td class="small">${e.drops.map(d => escapeHTML(v7Fr(d) || d)).join(', ')}</td><td class="small">${escapeHTML(e.regions.join(', '))}</td></tr>`).join('')}</tbody></table></div>${v7SrcNote(ENC.enemies)}</details>`);
};
/* Les butins sourcés (EN) alimentent aussi « Où farmer ? » */
const v7OldMatIndex = v7MaterialIndex;
v7MaterialIndex = function () {
  const base = v7OldMatIndex(), map = new Map(base.map(x => [norm(x.name), x]));
  for (const e of ENC.enemies.items) if (e.v6_id) for (const d of e.drops) {
    if (d.startsWith('(')) continue; const k = norm(d.replace(/×\d+/, '').trim());
    if (!map.has(k)) map.set(k, {name: d.replace(/×\d+/, '').trim(), mons: new Map()});
    map.get(k).mons.set(e.v6_id, 'Fiche sourcée');
  }
  return [...map.values()].sort((a, b) => a.name.localeCompare(b.name, 'fr'));
};

/* --- Navigation V7.1 --- */
navs.splice(navs.findIndex(n => n[0] === 'weapons') + 1, 0, ['arsenal', '🗡️', 'Arsenal complet'], ['armorpro', '🧥', 'Armures & amélio.']);
navs.splice(navs.findIndex(n => n[0] === 'quests') + 1, 0, ['recipes', '🍲', 'Recettes (228)']);
Object.assign(V7_SCREENS, {arsenal: renderArsenal, armorpro: renderArmorPro, recipes: renderRecipeBook});
const v7OldHome2 = renderHome;
renderHome = function () {
  v7OldHome2();
  el('screen-home').querySelector('.v7-home')?.insertAdjacentHTML('beforeend', `<button data-v7home="arsenal"><span>🗡️</span><b>Arsenal complet</b><small>${ENC.weapons.items.length} armes, arcs et boucliers avec puissance et durabilité.</small></button><button data-v7home="armorpro"><span>🧥</span><b>Armures & améliorations</b><small>${ENC.armor.pieces.length} pièces, lieux XYZ, coûts des 4 paliers et liste de courses.</small></button><button data-v7home="recipes"><span>🍲</span><b>Livre de recettes</b><small>${ENC.recipes.items.length} entrées numérotées et seuils d’effets.</small></button>`);
  el('screen-home').querySelectorAll('[data-v7home]').forEach(b => b.onclick = () => goto(b.dataset.v7home));
};

/* ===================================================================
   V7.2 — 147 grottes (entrées + Grenouille Bubbul) et variantes des 34 Lynels.
   =================================================================== */
const ENC_CAVES = ENC.caves || {items: [], koltin: []}, ENC_LYN = (ENC.lynels || {}).by_id || {};
/* Lynels : variante et lieu ajoutés aux positions existantes de l'atlas */
for (const p of ATLAS) { const t = ENC_LYN[p.id]; if (!t) continue;
  p.coliseum = t.coliseum; p.variant = t.coliseum ? 'Colisée flottant (5 vagues)' : t.variant_fr;
  p.name = (t.coliseum ? 'Lynels du Colisée flottant' : t.variant_fr) + ' · ' + (p.layer || ''); p.place = t.where; }
const v7OldAtlasForMonster = v7AtlasForMonster;
v7AtlasForMonster = function (m) {
  const r = v7OldAtlasForMonster(m);
  if (r.fam !== 'Lynel') return r;
  const exact = ATLAS.filter(p => p.type === 'Lynel' && (p.coliseum || (p.variant && norm(p.variant) === norm(m.name))));
  return {fam: 'Lynel', pts: exact, exact: true};
};
/* Collection 100 % : la catégorie « Grottes » devient nominative (ids cave_0001… conservés) */
const v7CaveId = i => 'cave_' + String(i + 1).padStart(4, '0');
const v7OldCollectRecords = collectRecords;
collectRecords = function (group) {
  if (group !== 'cave' || !ENC_CAVES.items.length) return v7OldCollectRecords(group);
  return ENC_CAVES.items.map((c, i) => ({id: v7CaveId(i), type: 'Grotte', layer: c.layer, name: c.name, xyz: c.entrances[0], no: i + 1}));
};
let v7C = {q: '', layer: 'Toutes', todo: false, start: '', limit: 50};
function renderCaves() {
  const q = norm(v7C.q), start = v7ParseXYZ(v7C.start);
  let items = ENC_CAVES.items.map((c, i) => ({...c, cid: v7CaveId(i)})).filter(c => (v7C.layer === 'Toutes' || c.layer === v7C.layer) && (!v7C.todo || !state.collectDone[c.cid]) &&
    norm(c.name + ' ' + c.entrances.map(v7Coord).join(' ')).includes(q));
  if (start) items.sort((a, b) => Math.min(...a.entrances.map(e => Math.hypot(e[0] - start[0], e[1] - start[1]))) - Math.min(...b.entrances.map(e => Math.hypot(e[0] - start[0], e[1] - start[1]))));
  const done = ENC_CAVES.items.filter((c, i) => state.collectDone[v7CaveId(i)]).length, ent = ENC_CAVES.items.reduce((s, c) => s + c.entrances.length, 0);
  el('screen-caves').innerHTML = section('Grottes & Grenouilles Bubbul', `${ENC_CAVES.items.length} grottes, ${ent} entrées, une Grenouille Bubbul (et une gemme) par grotte.`) +
    `<div class="v5-feature"><div><div class="eyebrow">GEMMES BUBBUL</div><strong class="v5-number">${done}<small> / ${ENC_CAVES.items.length}</small></strong><div class="small">Coches partagées avec Collection 100 % → Grottes.</div></div><div class="v5-ring" style="--p:${Math.round(done / ENC_CAVES.items.length * 100)}%"><span>${Math.round(done / ENC_CAVES.items.length * 100)} %</span></div></div>
     <div class="v7-farmbox"><label class="search">⌕ <input id="v7c-q" value="${escapeHTML(v7C.q)}" placeholder="Nom (EN) ou coordonnée…" aria-label="Recherche grottes"></label>
     <div class="v7-row"><select id="v7c-layer" aria-label="Couche">${['Toutes', 'Surface', 'Ciel'].map(l => `<option ${v7C.layer === l ? 'selected' : ''}>${l}</option>`).join('')}</select><input id="v7c-start" inputmode="numeric" value="${escapeHTML(v7C.start)}" placeholder="Ma position X Y Z → les plus proches" aria-label="Position"></div>
     <label class="v5-check"><input type="checkbox" id="v7c-todo" ${v7C.todo ? 'checked' : ''}> Gemme non récupérée</label></div>
     <div class="v5-list">${items.slice(0, v7C.limit).map(c => `<div class="v5-row ${state.collectDone[c.cid] ? 'v5-done' : ''}"><label class="v5-tick"><input type="checkbox" data-v7c="${c.cid}" ${state.collectDone[c.cid] ? 'checked' : ''}><span>${state.collectDone[c.cid] ? '✓' : '◯'}</span></label>
       <div class="v5-row-text"><strong>${escapeHTML(c.name)}</strong> <span class="small muted">${c.layer}${c.entrances.length > 1 ? ' · ' + c.entrances.length + ' entrées' : ''}</span>
       <div class="small">🚪 ${c.entrances.map(v7Coord).join(' ; ')}</div><div class="small">🐸 Grenouille : ${v7Coord(c.frog)}</div></div>
       <button class="btn mini ghost" data-v7c-copy="${escapeHTML(v7Coord(c.entrances[0]))}">Copier</button></div>`).join('') || '<div class="emptybox">Aucune grotte.</div>'}</div>
     ${items.length > v7C.limit ? `<button class="btn ghost" id="v7c-more">Afficher plus (${items.length - v7C.limit})</button>` : ''}
     <details class="v7-details"><summary>💎 Récompenses de Koltin (gemmes cumulées)</summary><ul class="v7-list">${ENC_CAVES.koltin.map(k => `<li><b>${k[0]}</b> → ${escapeHTML(k[1])}</li>`).join('')}</ul></details>
     <div class="note">Une coche confirme la gemme, pas toutes les entrées : pour la carte à 100 %, visite chaque entrée listée. ${ENC_CAVES.crosscheck ? ENC_CAVES.crosscheck.points ? Object.keys(ENC_CAVES.crosscheck.points).length + ' grottes recoupées ponctuellement avec une 2e source ; ' : '' : ''}conflit signalé : ${escapeHTML((ENC_CAVES.crosscheck?.conflicts || []).map(x => x.note).join(' '))}</div>` + v7SrcNote(ENC_CAVES);
  const s = el('screen-caves');
  el('v7c-q').oninput = e => { v7C.q = e.target.value; v7C.limit = 50; renderCaves(); const i = el('v7c-q'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); };
  el('v7c-layer').onchange = e => { v7C.layer = e.target.value; renderCaves(); };
  el('v7c-start').onchange = e => { v7C.start = e.target.value; renderCaves(); };
  el('v7c-todo').onchange = e => { v7C.todo = e.target.checked; renderCaves(); };
  if (el('v7c-more')) el('v7c-more').onclick = () => { v7C.limit += 50; renderCaves(); };
  s.querySelectorAll('[data-v7c]').forEach(b => b.onchange = () => { markCollect(b.dataset.v7c, b.checked); renderCaves(); });
  s.querySelectorAll('[data-v7c-copy]').forEach(b => b.onclick = async () => { try { await navigator.clipboard.writeText(b.dataset.v7cCopy); toast('Copié : ' + b.dataset.v7cCopy); } catch (e) { toast(b.dataset.v7cCopy); } });
}
navs.splice(navs.findIndex(n => n[0] === 'collections') + 1, 0, ['caves', '🕳️', 'Grottes (147)']);
V7_SCREENS.caves = renderCaves;
const v7OldHome3 = renderHome;
renderHome = function () { v7OldHome3(); el('screen-home').querySelector('.v7-home')?.insertAdjacentHTML('beforeend', `<button data-v7home="caves"><span>🕳️</span><b>Grottes (147)</b><small>Toutes les entrées et la Grenouille Bubbul de chaque grotte.</small></button>`); el('screen-home').querySelectorAll('[data-v7home]').forEach(b => b.onclick = () => goto(b.dataset.v7home)); };

/* ===================================================================
   V7.3 — 20 vœux des Sages et 81 panneaux de Boulieh (Addison), nominatifs dans Collection 100 %.
   =================================================================== */
const ENC_SAGES = (ENC.sages || {}).items || [], ENC_ADD = (ENC.addison || {}).items || [];
const v7XRec = {
  sage: () => ENC_SAGES.map(w => ({id: 'sage_' + String(w.no).padStart(4, '0'), type: 'Vœu des Sages', layer: 'Ciel', name: `Vœu n° ${w.no} · ${w.region} — ${w.req}`, xyz: w.xyz, no: w.no, src: ENC.sages, checks: w.checks})),
  addison: () => ENC_ADD.map(a => ({id: 'addison_' + String(a.no).padStart(4, '0'), type: 'Panneau de Boulieh', layer: 'Surface', name: `Panneau n° ${a.no} · ${a.band}`, xyz: a.xyz, no: a.no, src: ENC.addison})),
};
const v7OldCollectRecords2 = collectRecords;
collectRecords = function (group) { return v7XRec[group] && (group === 'sage' ? ENC_SAGES : ENC_ADD).length ? v7XRec[group]() : v7OldCollectRecords2(group); };
/* Fiche de position pour les collectables hors atlas (grottes, vœux, panneaux) */
const v7OldOpenAtlas2 = openAtlas;
openAtlas = function (id) {
  if (ATLAS.some(x => x.id === id)) return v7OldOpenAtlas2(id);
  const g = /^(cave|sage|addison)_/.exec(id || ''); if (!g) return;
  const x = collectRecords(g[1]).find(r => r.id === id); if (!x) return;
  const src = g[1] === 'cave' ? ENC.caves : x.src, cave = g[1] === 'cave' ? ENC_CAVES.items[x.no - 1] : null;
  const html = `<div class="detail"><button class="close" id="close-detail">✕ Fermer</button><div class="eyebrow">📍 ${escapeHTML(x.type)} · ${escapeHTML(x.layer)}</div><h2>${escapeHTML(x.name)}</h2>
    <p><b>XYZ</b> ${v7Coord(x.xyz)} <button class="btn mini ghost" id="v7x-copy">Copier</button></p>
    ${cave ? `<p class="small">Entrées : ${cave.entrances.map(v7Coord).join(' ; ')}<br>Grenouille Bubbul : ${v7Coord(cave.frog)}</p>` : ''}
    ${x.checks && x.checks.length ? `<p>${'<span class="v7b v7b-ok">✓ Recoupé</span>'} <span class="small">avec ${x.checks.map(c => `<a href="${escapeHTML(c.src)}" target="_blank" rel="noopener noreferrer">${escapeHTML(c.src.replace(/^https?:\/\/(www\.)?/, '').split('/')[0])}</a> (écart ${c.dist} u)`).join(', ')}</span></p>` : '<p><span class="v7b v7b-imp">↧ Source unique, non recoupée</span></p>'}
    <p class="small">Source : <a href="${escapeHTML(src.source_url)}" target="_blank" rel="noopener noreferrer">${escapeHTML(src.source_title)}</a></p>
    <label class="v5-check"><input type="checkbox" id="v7x-done" ${isCollectDone(x) ? 'checked' : ''}> Fait</label>
    <button class="btn mini ghost" data-v7-report="collect:${escapeHTML(id)}" data-v7-label="${escapeHTML(x.name)}">⚑ Signaler une erreur</button></div>`;
  el('modalroot').innerHTML = `<div class="detail-dimmer" id="detail-dimmer" role="dialog" aria-modal="true">${html}</div>`;
  el('close-detail').onclick = closeDetail; el('detail-dimmer').onclick = e => { if (e.target === el('detail-dimmer')) closeDetail(); };
  el('v7x-copy').onclick = async () => { const c = v7Coord(x.xyz); try { await navigator.clipboard.writeText(c); toast('Coordonnées copiées : ' + c); } catch (e) { toast(c); } };
  el('v7x-done').onchange = e => { markCollect(id, e.target.checked); if (state.tab === 'collections') renderCollections(); if (state.tab === 'caves') renderCaves(); };
  v7WireReports(el('modalroot')); document.body.style.overflow = 'hidden';
};
const v7OldRenderCollections = renderCollections;
renderCollections = function () {
  v7OldRenderCollections();
  if (['cave', 'sage', 'addison'].includes(v5CollectGroup)) el('screen-collections').querySelectorAll('.v5-row-text small').forEach(s => { s.innerHTML = s.innerHTML.replace('À localiser / identifier', 'Positionné (source citée)'); });
};

/* ===================================================================
   V7.4 — Korogus : 900 emplacements répartis par région (totaux sourcés),
   positions détaillées importées région par région.
   =================================================================== */
const ENC_K = ENC.koroks || {regions: [], items: [], types: {}, hestu: []};
const V7_K = new Map(ENC_K.items.map(k => [k.cid, k]));
const v7OldCollectRecords3 = collectRecords;
collectRecords = function (group) {
  if (group !== 'korok' || !ENC_K.regions.length) return v7OldCollectRecords3(group);
  const out = [];
  for (const r of ENC_K.regions) for (let i = 0; i < r.encounters; i++) {
    const cid = 'korok_' + String(r.offset + i + 1).padStart(4, '0'), k = V7_K.get(cid);
    out.push(k ? {id: cid, type: 'Korogu', layer: k.layer, name: `${k.id} · ${(ENC_K.types[k.type] || [k.type])[0]}${k.seeds > 1 ? ' (2 graines)' : ''} · ${r.name}`, xyz: k.xyz, no: r.offset + i + 1}
      : {id: cid, type: 'Korogu', layer: '', name: `Korogu · ${r.name} · n° ${i + 1}/${r.encounters} (position pas encore importée)`, no: r.offset + i + 1, unnamed: true});
  }
  return out;
};
const v7OldOpenAtlas3 = openAtlas;
openAtlas = function (id) {
  const k = V7_K.get(id);
  if (!k) return v7OldOpenAtlas3(id);
  const t = ENC_K.types[k.type] || [k.type, ''], reg = ENC_K.regions.find(r => r.name === k.region);
  const html = `<div class="detail"><button class="close" id="close-detail">✕ Fermer</button><div class="eyebrow">🌿 KOROGU · ${escapeHTML(k.region)} · ${escapeHTML(k.layer)}</div><h2>${escapeHTML(k.id)} — ${escapeHTML(t[0])}</h2>
    <div class="tags"><span class="tag gold">${k.seeds} graine${k.seeds > 1 ? 's' : ''}</span><span class="tag">${escapeHTML(k.type)}</span></div>
    <p><b>${k.goal ? 'Départ' : 'XYZ'}</b> ${v7Coord(k.xyz)}${k.goal ? `<br><b>Arrivée</b> ${v7Coord(k.goal)}` : ''} <button class="btn mini ghost" id="v7k-copy">Copier</button></p>
    <p><b>Téléporteur le plus proche</b> : ${escapeHTML(k.warp)}</p><h4>💡 Solution</h4><p>${escapeHTML(t[1])}</p>
    <p class="small">Solution résumée par Hyrule Codex à partir du type d’énigme. Source : <a href="${escapeHTML(reg ? reg.url : ENC_K.source_url)}" target="_blank" rel="noopener noreferrer">ConsolePulse</a></p>${v7ProvenanceBlock('korok:' + k.cid, k.id)}
    <label class="v5-check"><input type="checkbox" id="v7k-done" ${state.collectDone[id] ? 'checked' : ''}> Trouvé</label>
    </div>`;
  el('modalroot').innerHTML = `<div class="detail-dimmer" id="detail-dimmer" role="dialog" aria-modal="true">${html}</div>`;
  el('close-detail').onclick = closeDetail; el('detail-dimmer').onclick = e => { if (e.target === el('detail-dimmer')) closeDetail(); };
  el('v7k-copy').onclick = async () => { const c = v7Coord(k.xyz); try { await navigator.clipboard.writeText(c); toast('Coordonnées copiées : ' + c); } catch (e) { toast(c); } };
  el('v7k-done').onchange = e => { markCollect(id, e.target.checked); if (state.tab === 'collections') renderCollections(); };
  v7WireReports(el('modalroot')); document.body.style.overflow = 'hidden';
};
const v7OldRenderCollections2 = renderCollections;
renderCollections = function () {
  v7OldRenderCollections2();
  if (v5CollectGroup !== 'korok' || !ENC_K.regions.length) return;
  const done = id => !!state.collectDone[id];
  const rows = ENC_K.regions.map(r => { let d = 0; for (let i = 0; i < r.encounters; i++) if (done('korok_' + String(r.offset + i + 1).padStart(4, '0'))) d++;
    return `<tr><td>${escapeHTML(r.name)}</td><td>${d} / ${r.encounters}</td><td>${r.seeds}</td><td>${r.imported ? '<span class="v7b v7b-imp">positions importées</span>' : '<span class="v7b v7b-none">à importer</span>'} <a href="${escapeHTML(r.url)}" target="_blank" rel="noopener noreferrer">↗</a></td></tr>`; }).join('');
  el('screen-collections').querySelector('.v5-group-grid')?.insertAdjacentHTML('afterend', `<details class="v7-details" open><summary>🌿 Korogus par région (900 rencontres · 1 000 graines)</summary><div class="v7-tablewrap"><table class="v7-table"><thead><tr><th>Région (tour)</th><th>Trouvés</th><th>Graines</th><th>Positions</th></tr></thead><tbody>${rows}</tbody></table></div>
    <p class="small">Hestu : ${ENC_K.hestu.map(h => escapeHTML(h.join(' — '))).join(' · ')}.</p><p class="small">Les cases « n° » des V5–V7.3 étaient des repères personnels : depuis V7.4 elles sont rangées par région. Si tu avais coché des repères au hasard, vérifie-les.</p></details>`);
  el('screen-collections').querySelectorAll('.v5-row-text small').forEach(s => { s.innerHTML = s.innerHTML.replace('À localiser / identifier', ''); });
};

/* ===================================================================
   V7.9 — Quêtes : étapes et récompenses, une source par ligne.
   Une quête sans données sourcées affiche « à vérifier » (rien n'est déduit).
   =================================================================== */
const V7_QD = (V7.quest_details && V7.quest_details.items) || {};
const V7_QX = (V7.quest_details && V7.quest_details.extra) || {};
function v7QuestDetailHTML(id) {
  const d = V7_QD[id];
  if (!d) return `<details class="v7-qd"><summary>Étapes et récompenses <span class="v7b v7b-none">? À vérifier</span></summary><p class="small">Aucune source importée pour cette quête : étapes et récompenses à vérifier. Rien n’est affiché plutôt que des valeurs non sourcées.</p></details>`;
  const src = u => ` <a class="small" href="${escapeHTML(u)}" target="_blank" rel="noopener noreferrer" title="${escapeHTML(u)}">[source]</a>`;
  const list = (a, tag) => a.length ? `<${tag}>${a.map(e => `<li>${escapeHTML(e.text)}${src(e.src)}</li>`).join('')}</${tag}>` : '<p class="small">Non renseigné (à vérifier).</p>';
  return `<details class="v7-qd"><summary>Étapes et récompenses ${v7Badge('quests:' + id)}</summary><h4>Étapes</h4>${list(d.steps, 'ol')}<h4>Récompenses</h4>${list(d.rewards, 'ul')}` +
    (V7_QX[id] && V7_QX[id].zc ? `<p class="small"><b>Selon ZeldaCentral (EN)</b> : ${escapeHTML(V7_QX[id].zc.reward_en)} <a href="${escapeHTML(V7_QX[id].zc.url)}" target="_blank" rel="noopener noreferrer">[source]</a></p>` : '') +
    (V7_QX[id] && V7_QX[id].th ? `<p class="small"><b>Selon Thonky (EN)</b> : ${escapeHTML(V7_QX[id].th.reward_en)} <a href="${escapeHTML(V7_QX[id].th.url)}" target="_blank" rel="noopener noreferrer">[source]</a></p>` : '') +
    `<p class="small">${V7_QX[id] && V7_QX[id].en ? 'Titre anglais officiel : ' + escapeHTML(V7_QX[id].en) + ' · ' : ''}Collecté le ${escapeHTML(d.collected_at)}${d.note ? ' · ' + escapeHTML(d.note) : ''}.</p></details>`;
}
const v7OldRenderQuests = renderQuests;
renderQuests = function () {
  v7OldRenderQuests();
  const list = el('v5-quest-list');
  if (!list) return;
  list.querySelectorAll('label.v5-row').forEach(row => {
    const cb = row.querySelector('[data-v5-quest]');
    if (cb) row.insertAdjacentHTML('afterend', v7QuestDetailHTML(cb.dataset.v5Quest));
  });
  const n = Object.keys(V7_QD).length;
  el('screen-quests').querySelector('.sourcebox')?.insertAdjacentHTML('beforeend', ` Étapes et récompenses sourcées : ${n} / ${V5_QUESTS.length} quêtes ; les autres sont marquées « à vérifier ».`);
};

/* ===================================================================
   V7.11 — Design : en-tête d'accueil seulement sur l'accueil,
   compteurs de progression réels, version visible.
   =================================================================== */
const v7OldRenderD = render;
render = function () { document.body.dataset.tab = state.tab; v7OldRenderD(); };
renderStats = function () {
  const cd = state.collectDone || {}, qd = state.questDone || {};
  const kor = Object.keys(cd).filter(k => k.startsWith('korok_') && cd[k]).length;
  const rec = Object.keys(cd).filter(k => k.startsWith('recipe_') && cd[k]).length;
  const qst = Object.values(qd).filter(Boolean).length;
  const vals = Object.values(V7.verification || {});
  const ok = vals.filter(v => /^verifie|^corrige$/.test(v.s)).length;
  const cards = [['🌿', kor, 900, 'Korogus trouvés'], ['📜', qst, 253, 'Quêtes terminées'], ['🍲', rec, 228, 'Recettes cuisinées'], ['🛡️', ok, vals.length, 'Données recoupées']];
  el('stats').innerHTML = cards.map(([ic, n, t, k]) => `<div class="stat"><div class="value">${ic} ${n.toLocaleString('fr-FR')}<small> / ${t.toLocaleString('fr-FR')}</small></div><div class="key">${k}</div><div class="v7-bar"><i style="width:${t ? Math.round(n / t * 100) : 0}%"></i></div></div>`).join('');
};
(function () {
  const b = document.querySelector('.topbadge'); if (b) b.textContent = '✦ ' + (V7.version || 'V7').toUpperCase().replace(/\.0$/, '');
})();


/* ===================================================================
   V7.12 — Tables de butin (ZeldaCentral) : probabilités par tirage,
   affichées dans la fiche du monstre et dans « Où farmer ? ».
   =================================================================== */
const V7_DROPS = ENC.drops || {map: {}, tables: {}};
function v7DropTable(mid) { const n = V7_DROPS.map[mid]; return n ? {name: n, rows: V7_DROPS.tables[n] || []} : null; }
function v7DropRows(rows) {
  return rows.filter(r => r.chance > 0).map(r => `<tr><td>${v7FrLabel(r.item)}</td><td>${r.min === r.max ? '×' + r.min : '×' + r.min + '–' + r.max}</td><td>${r.chance >= 100 ? '<b>garanti</b>' : r.chance.toLocaleString('fr-FR') + ' %'}</td></tr>`).join('');
}
const v7OldOpenDetail3 = openDetail;
openDetail = function (kind, id) {
  v7OldOpenDetail3(kind, id);
  if (kind !== 'monster') return;
  const t = v7DropTable(id), box = document.querySelector('#detail-dimmer .v7-prov');
  if (!t || !box) return;
  box.insertAdjacentHTML('beforebegin', `<div class="v7-drops"><h4>🎲 Table de butin (${v7FrLabel(t.name)})</h4><div class="v7-tablewrap"><table class="v7-table"><thead><tr><th>Objet</th><th>Qté</th><th>Chance</th></tr></thead><tbody>${v7DropRows(t.rows)}</tbody></table></div><p class="small">Probabilité par tirage, données du jeu publiées par <a href="${escapeHTML(V7_DROPS.source_url)}" target="_blank" rel="noopener noreferrer">ZeldaCentral</a> (${escapeHTML(V7_DROPS.collected_at)}). Les objets tenus en main et les armes ne sont pas inclus. Source unique, non recoupée.</p></div>`);
};
const v7OldMatIndex2 = v7MaterialIndex;
v7MaterialIndex = function () {
  const base = v7OldMatIndex2(), map = new Map(base.map(x => [norm(x.name), x]));
  for (const [mid, n] of Object.entries(V7_DROPS.map)) for (const r of (V7_DROPS.tables[n] || [])) {
    if (!(r.chance > 0) || /^Arrow/.test(r.item)) continue;
    const fr = v7Fr(r.item), label = fr ? `${fr} (${r.item})` : r.item, k = norm(label);
    if (!map.has(k)) map.set(k, {name: label, mons: new Map()});
    map.get(k).mons.set(mid, `ZeldaCentral ${r.chance} %`);
  }
  return [...map.values()].sort((a, b) => a.name.localeCompare(b.name, 'fr'));
};
function v7DropHint(mid) {
  const t = v7DropTable(mid), q = norm(v7Farm.material || '');
  if (!t || !q) return '';
  const hits = t.rows.filter(r => r.chance > 0 && norm((v7Fr(r.item) || '') + ' ' + r.item).includes(q));
  if (!hits.length) return '';
  const best = hits.reduce((a, b) => (b.chance > a.chance ? b : a));
  return ` <span class="v7b v7b-ok" title="Probabilité par tirage (ZeldaCentral)">🎲 ${escapeHTML(v7Fr(best.item) || best.item)} : ${best.chance >= 100 ? 'garanti' : best.chance.toLocaleString('fr-FR') + ' %'} · ×${best.min}${best.max !== best.min ? '–' + best.max : ''}</span>`;
}
