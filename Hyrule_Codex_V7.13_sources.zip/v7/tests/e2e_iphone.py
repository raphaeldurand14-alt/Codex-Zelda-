#!/usr/bin/env python3
"""Tests fonctionnels de site/index.html dans Chromium, viewport iPhone (390×844, tactile).

Ce n'est PAS un test sur un vrai iPhone/Safari. Lancer : python3 tests/e2e_iphone.py
"""
from pathlib import Path
import json, threading, http.server, functools, socketserver, sys, tempfile
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
SITE = ROOT / 'site'
results, errors = [], []


def ok(name, cond, detail=''):
    results.append((name, bool(cond), detail))
    print(('PASS ' if cond else 'FAIL ') + name + (f' — {detail}' if detail else ''))


def serve():
    h = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(SITE))
    h.log_message = lambda *a: None
    srv = socketserver.TCPServer(('127.0.0.1', 0), h)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


def main():
    srv = serve(); url = f'http://127.0.0.1:{srv.server_address[1]}/index.html'
    with sync_playwright() as p:
        b = p.chromium.launch()
        ctx = b.new_context(viewport={'width': 390, 'height': 844}, device_scale_factor=3, is_mobile=True, has_touch=True,
                            user_agent='Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
                            accept_downloads=True)
        # bloquer l'API externe : l'app doit rester utilisable hors ligne
        ctx.route('**/api.hyrule-compendium.com/**', lambda r: r.abort())
        pg = ctx.new_page()
        pg.on('pageerror', lambda e: errors.append(str(e)))
        pg.goto(url); pg.wait_for_timeout(400)

        ok('chargement sans erreur JS', not errors, '; '.join(errors))
        c = pg.evaluate('({atlas:ATLAS.length,bosses:V6_BOSS_PLACES.length,mons:DB.monsters.length,v7:Object.keys(CODEX_V7.verification).length,old:ATLAS.filter(x=>/^a\\d+$/.test(x.id)).length})')
        ok('atlas = 640 positions', c['atlas'] == 640, str(c))
        ok('283 positions de boss', c['bosses'] == 283)
        ok('anciens repères V3 retirés', c['old'] == 0)
        ok('bestiaire 96 fiches (ajout Lithorok fortifié)', c['mons'] == 96)
        ok('PV renseignés pour 89 fiches sur 96', pg.evaluate('DB.monsters.filter(m=>m.hp!=null).length') == 89)
        ok('registre V7 embarqué', c['v7'] > 700, str(c['v7']))
        ok('correction shrine_95 appliquée', pg.evaluate("ATLAS.find(x=>x.id==='shrine_95').x") == 3094)
        ok('ids atlas uniques', pg.evaluate('new Set(ATLAS.map(x=>x.id)).size===ATLAS.length'))

        tabs = pg.evaluate('navs.map(n=>n[0])')
        for t in tabs:
            n0 = len(errors)
            pg.evaluate(f"goto('{t}')"); pg.wait_for_timeout(120)
            visible = pg.evaluate(f"!document.getElementById('screen-{t}').classList.contains('hidden') && document.getElementById('screen-{t}').innerHTML.length>200")
            ok(f'écran « {t} » affiché sans erreur', visible and len(errors) == n0, '; '.join(errors[n0:]))
        # pas de débordement horizontal
        for t in ['home', 'farmroute', 'reliability', 'bosses', 'bestiary']:
            pg.evaluate(f"goto('{t}')"); pg.wait_for_timeout(100)
            w = pg.evaluate('document.documentElement.scrollWidth')
            ok(f'pas de défilement horizontal sur « {t} »', w <= 392, f'scrollWidth={w}')

        # badges et provenance dans le bestiaire
        pg.evaluate("goto('bestiary')"); pg.wait_for_timeout(100)
        ok('badges de fiabilité sur les cartes', pg.locator('#screen-bestiary .v7b').count() >= 90)
        pg.evaluate("openDetail('monster','lynel_argent')"); pg.wait_for_timeout(100)
        prov = pg.locator('#detail-dimmer .v7-prov').inner_text()
        ok('fiche Lynel d’argent : statut recoupé et sources', 'Recoupé' in prov and 'zeldadungeon' in prov, prov[:120])
        pg.evaluate('closeDetail()')
        pg.evaluate("openAtlas('boss_hinox_037')"); pg.wait_for_timeout(100)
        ok('position en conflit signalée', 'conflit' in pg.locator('#detail-dimmer .v7-prov').inner_text())
        pg.evaluate('closeDetail()')

        # parcours Où farmer
        pg.evaluate("goto('farmroute')"); pg.fill('#v7-mat', 'Diamant'); pg.wait_for_timeout(150)
        ok('Diamant → au moins un monstre', pg.locator('#screen-farmroute .v7-mon').count() >= 1)
        pg.evaluate("v7Farm={material:'',monster:'gigatracien_blanc',layer:'Toutes',start:'',onlyTodo:false,hideConflict:false,limit:25};renderFarmRoute()")
        steps = pg.locator('#screen-farmroute .v7-step').count()
        ok('Gigatracien opalin → 13 positions en circuit', steps == 13, f'{steps} étapes')
        pg.evaluate("v7Farm={material:'',monster:'hinox_noir',layer:'Toutes',start:'',onlyTodo:false,hideConflict:false,limit:25};renderFarmRoute()")
        ok('plusieurs couches → demande de choisir une couche', 'plusieurs couches' in pg.locator('#screen-farmroute').inner_text())
        pg.select_option('#v7-layer', 'Surface'); pg.wait_for_timeout(100)
        ok('Hinox noir en surface → circuit calculé', pg.locator('#screen-farmroute .v7-step').count() >= 1)
        d = pg.evaluate("(()=>{const r=v7Route([{x:0,y:0},{x:100,y:0},{x:10,y:0}],[0,0,0]);return r.map(s=>s.p.x).join(',')+'|'+Math.round(r[2].total)})()")
        ok('algorithme du plus proche voisin', d == '0,10,100|100', d)

        # sauvegarde : persistance + export/import V7 (y compris coches de boss, bug V6)
        pg.evaluate("state.atlasDone={'boss_hinox_001':true,'well_3':true,'shrine_1':true};state.v7Reports=[{id:'1',key:'atlas:boss_hinox_001',label:'test',text:'Z faux',at:'2026-11-11'}];save()")
        pg.reload(); pg.wait_for_timeout(300)
        ok('persistance localStorage après rechargement', pg.evaluate("state.atlasDone.boss_hinox_001===true && state.v7Reports.length===1 && state.schema===7"))
        pg.evaluate("goto('goals')"); pg.wait_for_timeout(100)
        with pg.expect_download() as dl:
            pg.click('#export-progress')
        path = dl.value.path(); data = json.loads(Path(path).read_text(encoding='utf-8'))
        ok('export V7 complet', data.get('version') == 7 and data['atlasDone'].get('boss_hinox_001') and len(data['v7Reports']) == 1)
        pg.evaluate("state.atlasDone={};state.v7Reports=[];save()")
        pg.set_input_files('#progress-file', path); pg.wait_for_timeout(400)
        ok('import restaure coches de boss et puits (bug V6 corrigé)', pg.evaluate("state.atlasDone.boss_hinox_001===true && state.atlasDone.well_3===true"))
        ok('import restaure les signalements', pg.evaluate("state.v7Reports.length===1"))
        # compatibilité avec une sauvegarde V5/V6
        old = {'version': 5, 'owned': {'weapon_master': True}, 'defeated': {'lynel': True}, 'goals': [{'id': 'g1', 'text': 'Farmer', 'done': False}],
               'questDone': {'main_1': True}, 'atlasDone': {'shrine_2': True}}
        tmp = Path(tempfile.gettempdir()) / 'save_v5.json'; tmp.write_text(json.dumps(old), encoding='utf-8')
        pg.evaluate("goto('goals')"); pg.set_input_files('#progress-file', str(tmp)); pg.wait_for_timeout(400)
        ok('import d’une sauvegarde V5', pg.evaluate("state.defeated.lynel===true && state.questDone.main_1===true && state.atlasDone.shrine_2===true"))
        # V7.1 — encyclopédie sourcée
        pg.evaluate("goto('arsenal')"); pg.wait_for_timeout(100)
        ok('arsenal : 174 lignes', pg.locator('#screen-arsenal tbody tr').count() == 174)
        pg.select_option('#v7w-fuse', '0'); pg.wait_for_timeout(80)
        ok('arsenal : colonne amalgame', 'amalgame' in pg.locator('#screen-arsenal thead').inner_text())
        pg.evaluate("goto('armorpro')"); pg.wait_for_timeout(100)
        ok('armures : 135 pièces listées', pg.locator('#screen-armorpro .v7-arow').count() == 135)
        pg.evaluate("state.v7Armor={'Hylian Hood':{own:true,lvl:0}};save();renderArmorPro()")
        txt = pg.locator('#screen-armorpro').inner_text()
        ok('armures : liste de courses Hylian Hood ★4 (Bokoblin Horn 5, Amber 50, 760 R)', '760 rubis' in txt and '50× Amber' in txt.replace('\n',' ') or ('50×' in txt and 'Amber' in txt and '760' in txt), txt[:0])
        pg.click('#v7a-bag'); pg.wait_for_timeout(80)
        ok('armures : ajout au Sac à butin', pg.evaluate("bagGet('Amber').want===50 && bagGet('Bokoblin Horn').want===5"))
        pg.evaluate("v7ArmorDetail('Zora Armor')"); pg.wait_for_timeout(80)
        ok('armures : détail avec 4 paliers', pg.locator('#detail-dimmer tbody tr').count() == 4)
        pg.evaluate('closeDetail()')
        pg.evaluate("goto('recipes')"); pg.wait_for_timeout(100)
        pg.fill('#v7r-q', '126'); pg.wait_for_timeout(80)
        ok('recettes : recherche par numéro', 'Fruitcake' in pg.locator('#screen-recipes').inner_text())
        pg.locator('[data-v7r="126"]').check(); pg.wait_for_timeout(80)
        ok('recettes : coche partagée avec Collection', pg.evaluate("state.collectDone['recipe_0126']===true"))
        pg.evaluate("openDetail('monster','moblin_argent')"); pg.wait_for_timeout(80)
        ok('bestiaire : fiche sourcée (PV 1080)', 'fiche sourcée' in pg.locator('#detail-dimmer').inner_text().lower() and '1080' in pg.locator('#detail-dimmer').inner_text())
        pg.evaluate('closeDetail()')
        pg.evaluate("v7Farm={material:'Lizalfos Talon',monster:'',layer:'Toutes',start:'',onlyTodo:false,hideConflict:false,limit:25};goto('farmroute')"); pg.wait_for_timeout(100)
        ok('Où farmer : butin sourcé EN → monstres', pg.locator('#screen-farmroute .v7-mon').count() >= 5)
        pg.evaluate("goto('caves')"); pg.wait_for_timeout(100)
        ok('grottes : liste affichée', pg.locator('#screen-caves .v5-row').count() == 50)
        pg.fill('#v7c-start', '-254 129 20'); pg.locator('#v7c-start').dispatch_event('change'); pg.wait_for_timeout(100)
        ok('grottes : tri par proximité (Royal Hidden Passage en tête)', 'Royal Hidden Passage' in pg.locator('#screen-caves .v5-row').first.inner_text())
        pg.locator('[data-v7c="cave_0001"]').check(); pg.wait_for_timeout(80)
        ok('grottes : coche partagée avec Collection', pg.evaluate("state.collectDone['cave_0001']===true && collectRecords('cave')[0].name==='Bottomless Cave'"))
        ok('Lynels : variantes appliquées', pg.evaluate("ATLAS.filter(p=>p.type==='Lynel'&&p.variant==='Lynel d’argent').length")==1)
        pg.evaluate("v7Farm={material:'',monster:'lynel_argent',layer:'Profondeurs',start:'',onlyTodo:false,hideConflict:false,limit:25};goto('farmroute')"); pg.wait_for_timeout(100)
        ok('Où farmer : Lynel d’argent → 6 positions (1 + 5 Colisée)', pg.locator('#screen-farmroute .v7-step').count() == 6)
        ok('Collection : 20 vœux nominatifs', pg.evaluate("collectRecords('sage').length===20 && collectRecords('sage')[0].name.includes('West Hebra')"))
        ok('Collection : 81 panneaux positionnés', pg.evaluate("collectRecords('addison').length===81 && collectRecords('addison').every(x=>x.xyz)"))
        pg.evaluate("openAtlas('sage_0001')"); pg.wait_for_timeout(80)
        ok('fiche de position d’un vœu (recoupé)', 'Recoupé' in pg.locator('#detail-dimmer').inner_text())
        pg.locator('#v7x-done').check(); pg.wait_for_timeout(60)
        ok('vœu coché depuis la fiche', pg.evaluate("state.collectDone['sage_0001']===true"))
        pg.evaluate('closeDetail()')
        pg.evaluate("v5CollectGroup='addison';goto('collections')"); pg.wait_for_timeout(100)
        ok('Collection Addison sans « À localiser »', 'À localiser' not in pg.locator('#screen-collections').inner_text())
        pg.evaluate("goto('quests')")
        nqd = pg.locator('#v5-quest-list details.v7-qd').count(); nrow = pg.locator('#v5-quest-list label.v5-row').count()
        ok('quêtes : un bloc étapes/récompenses par ligne', nqd == nrow and nrow > 0, f'{nqd}/{nrow}')
        unsourced = pg.evaluate("[...document.querySelectorAll('#v5-quest-list [data-v5-quest]')].filter(c=>!V7_QD[c.dataset.v5Quest]).length")
        ok('quêtes non sourcées marquées « à vérifier »', pg.locator('#v5-quest-list details.v7-qd .v7b-none').count() == unsourced, f'{unsourced} sans source')
        before = pg.locator('#v5-quest-list [data-v5-quest]').first.is_checked()
        pg.locator('#v5-quest-list details.v7-qd summary').first.click()
        ok('quête : détail dépliable sans changer la coche', pg.locator('#v5-quest-list details.v7-qd').first.evaluate('d=>d.open') and pg.locator('#v5-quest-list [data-v5-quest]').first.is_checked() == before)
        pg.evaluate("openAtlas('korok_0001')"); pg.wait_for_timeout(80)
        ok('fiche Korogu : statut de recoupement affiché', 'fiabilité de cette fiche' in pg.locator('#detail-dimmer').inner_text().lower())
        pg.evaluate('closeDetail()')
        pg.evaluate("openDetail('monster','lynel_argent')"); pg.wait_for_timeout(80)
        ok('fiche monstre : table de butin ZeldaCentral', pg.locator('#detail-dimmer .v7-drops tbody tr').count() >= 5)
        pg.evaluate('closeDetail()')
        pg.evaluate("v7Farm.material='Corne';v7Farm.monster='';goto('farmroute')"); pg.wait_for_timeout(120)
        ok('Où farmer : probabilité affichée', '🎲' in pg.locator('#screen-farmroute').inner_text())
        pg.evaluate("v7Farm.material=''")
        ok('Korogus : 900 emplacements, 900 positionnés', pg.evaluate("collectRecords('korok').length===900 && collectRecords('korok').filter(x=>x.xyz).length===900"))
        pg.evaluate("openAtlas('korok_0005')"); pg.wait_for_timeout(80)
        ok('fiche Korogu (ami, 2 graines, arrivée)', 'Arrivée' in pg.locator('#detail-dimmer').inner_text() and '2 graines' in pg.locator('#detail-dimmer').inner_text())
        pg.evaluate('closeDetail()')
        pg.evaluate("v5CollectGroup='korok';goto('collections')"); pg.wait_for_timeout(120)
        ok('tableau des Korogus par région', pg.locator('#screen-collections .v7-details tbody tr').count() == 16)
        ok('aucune erreur JS sur tout le parcours', not errors, '; '.join(errors))
        pg.evaluate("goto('reliability');el('screen-reliability').scrollIntoView()"); pg.wait_for_timeout(150)
        pg.screenshot(path=str(ROOT / 'preview' / 'V7_fiabilite_iPhone.png'), full_page=False)
        pg.evaluate("v7Farm={material:'',monster:'gigatracien_blanc',layer:'Toutes',start:'',onlyTodo:false,hideConflict:false,limit:25};goto('farmroute');el('screen-farmroute').scrollIntoView()"); pg.wait_for_timeout(2500)
        pg.screenshot(path=str(ROOT / 'preview' / 'V7_ou_farmer_iPhone.png'), full_page=False)
        b.close()
    srv.shutdown()
    failed = [r for r in results if not r[1]]
    print(f'\n{len(results) - len(failed)}/{len(results)} tests réussis')
    (ROOT / 'docs' / 'RESULTATS_TESTS_V7.txt').write_text(
        'Tests Playwright/Chromium, viewport iPhone 390×844 (PAS un iPhone réel)\n' +
        '\n'.join(('PASS ' if r[1] else 'FAIL ') + r[0] + (f' — {r[2]}' if r[2] else '') for r in results) +
        f'\n\n{len(results) - len(failed)}/{len(results)} tests réussis\n', encoding='utf-8')
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
