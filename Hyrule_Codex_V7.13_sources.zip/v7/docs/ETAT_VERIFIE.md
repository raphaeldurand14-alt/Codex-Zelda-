# État vérifié — V7.13 (11 novembre 2026)

« Recoupé » signifie : la valeur concorde avec au moins une source externe **distincte** de la source d’import (GamerTW). Ce n’est jamais une confirmation en jeu : aucune donnée n’a été testée sur Switch par l’auteur de V7. Détail par enregistrement : `data/v7/verification.json`, onglet **Fiabilité** de l’app.

## Ajouts V7.1 (importés d’une source unique, citée, non recoupée)

| Bloc | Contenu | Source |
|---|---|---|
| Armures | 135 pièces (103 améliorables), lieu + XYZ, DEF base/max, matériaux et rubis des 4 paliers, 36 ensembles et bonus | ConsolePulse (mise à jour 13/09/2026) |
| Arsenal | 174 armes, arcs et boucliers (Compendium 329–503 sauf 440) : puissance/défense, durabilité, effet | Samurai Gamers (02/06/2023) |
| Recettes | 228 entrées du livre (146 marmite, 51 grillées, 1 bouillie, 16 congelées, 13 élixirs, 1 tonique), seuils d’effets | ConsolePulse (26/09/2026) |
| Grottes | 147 grottes (4 célestes), 197 entrées, position de la Grenouille Bubbul, récompenses de Koltin ; 7 grottes recoupées avec EarlyGame (écart ≤ 19 u), 1 conflit de nom | ConsolePulse (13/09/2026) |
| Lynels | Variante et lieu des 34 Lynels ; 29 positions concordent à ≤ 48 u, les 5 du Colisée flottant sont regroupées | Thonky (04/02/2025) |
| Vœux des Sages | 20 coffres célestes, coordonnées et condition d’accès ; 8 recoupés avec un autre site (≤ 30 u) | ConsolePulse (26/09/2026) |
| Panneaux de Boulieh | 81 panneaux d’Addison, coordonnées par bande géographique ; non recoupés | ConsolePulse (16/09/2026) |
| Korogus | Totaux des 16 régions (900 rencontres, 100 amis, 1 000 graines) et coûts de Hestu ; positions, téléporteur, type d’énigme pour **10 régions sur 16** (Lookout Landing 62, Hyrule Field 77, Lindor's Brow 66, Rospro Pass 65, Pikida Stonegrove 33, Thyphlo Ruins 23, Upland Zorana 76, Mount Lanayru 50, Sahasra Slope 79, Great Sky Island 17 = 548 positions ; nombre de lignes et de graines égal au total régional pour chacune) | ConsolePulse (26/10/2026) |
| Ennemis communs | 69 fiches : PV, attaques, butins possibles (sans taux), régions d’exemple ; 58 reliées au bestiaire | RankedBoost |

Effet sur le bestiaire : PV renseignés pour 83 fiches sur 96 (contre 37 en V6) ; 12 valeurs V6 confirmées par RankedBoost ; 1 valeur V6 corrigée (Lézalfos bleu 110 → 120, à confirmer). Les noms d’objets de ces blocs restent en **anglais officiel** : aucun nom français n’a été inventé. Les traductions d’effets sont descriptives et signalées.

## Statuts (V7.8 : 774 enregistrements suivis ; V7.9 ajoute 253 entrées `quests:`, voir l’onglet Fiabilité)

| Statut | Nombre |
|---|---:|
| Recoupé ≥ 2 sources | 24 |
| Recoupé 1 source | 149 |
| Partiellement recoupé | 151 |
| Corrigé, à confirmer | 1 (+ 6 corrections journalisées sur des fiches recoupées) |
| Sources en conflit | 4 |
| Importé, non recoupé | 421 |
| Sans source | 24 |

## Par catégorie

| Catégorie | Présent | Total attendu (sourcé) | Recoupé | Commentaire |
|---|---:|---:|---:|---|
| Racines | 120 | 120 | 116 | XYZ comparés à Samurai Gamers ; 2 conflits (root_41, root_115), 2 absents de la source |
| Sanctuaires | 152 | 152 | 110 | X/Y via la racine appariée ; Z non recoupé ; 32 célestes non recoupés |
| Positions de boss | 249 (+ 34 Lynels recoupés avec variante) | effectifs concordants | 0 individuellement | répartition par variante identique à la source (Gigatraciens, Golemax, Griocks) ; Hinox 68 ou 69 selon la source ; total Lithorok peu solide |
| Puits / tours / larmes | 58 / 15 / 12 | 15 tours sourcées | 0 | positions importées |
| Bestiaire | 96 | non établi | 37 | PV des boss/sous-boss recoupés ; 46 PV importés de RankedBoost ; butins sans taux |
| Amalgame | 38 | non établi | 27 | 0 conflit ; 7 matériaux sourcés absents (noms FR non vérifiés) |
| Armes / armures V6 | 30 / 22 | non établi | 0 | fiches V6 sans source ; voir les blocs V7.1 complets |
| Quêtes | 253 intitulés ; 252 avec étapes/récompenses | 253 | 0 | source unique (Puissance-Zelda) par ligne ; 1 quête « à vérifier » ; 7 quêtes principales partielles |
| Recettes | 228 | 228 (sourcé) | 0 | importées, non recoupées |

## V7.13 (11 novembre 2026) — bilan de complétude

**Contenu : toutes les collections listées sont présentes en totalité** (900 Korogus, 253 quêtes avec étapes et récompenses, 152 sanctuaires, 120 racines, 147 grottes, 58 puits, 15 tours, 12 larmes, 20 vœux, 81 panneaux, 283 positions de boss, 174 armes, 135 armures, 228 recettes, 96 fiches de bestiaire, tables de butin pour 85 fiches).

**Fiabilité : 2 692 enregistrements suivis**, dont **2 610 recoupés avec au moins une source indépendante (97 %)** — 1 703 avec plusieurs sources, 639 avec une, 267 partiellement (quêtes : récompense recoupée, étapes en source unique ; Lynels et boss en zone de déplacement), 1 corrigé. Restent **52 importés** (source unique), **25 conflits** documentés et **5 sans source** (4 dragons et les mains de miasmes, sans PV publiés).

| Catégorie | Recoupés | Sources de recoupement |
|---|---:|---|
| Korogus | 900 / 900 | Puissance-Zelda, carte ZeldaCentral |
| Positions de boss | 282 / 283 | Thonky, Game8, carte ZeldaCentral |
| Sanctuaires / racines / grottes | 151 / 152 · 117 / 120 · 146 / 147 | Samurai Gamers, Puissance-Zelda, Thonky, carte ZeldaCentral |
| Puits / tours / larmes / panneaux | 58 / 58 · 15 / 15 · 12 / 12 · 81 / 81 | Puissance-Zelda, Thonky, Game8, carte ZeldaCentral |
| Vœux des Sages | 19 / 20 | GGRecon, Puissance-Zelda |
| Armures | 135 / 135 (DEF base + 4 paliers) | Puissance-Zelda, ZeldaCentral |
| Armes | 160 / 174 (14 conflits de 1 à 3 points) | ZeldaCentral |
| Amalgame | 38 / 38 | ZeldaCentral |
| Recettes | 212 / 228 | Puissance-Zelda × Zelda Wiki |
| Quêtes | 253 / 253 renseignées ; titres 250, récompenses 221 | Zelda Wiki, Thonky, ZeldaCentral |
| Bestiaire (PV) | 81 / 96 ; PV de 6 boss d’histoire ajoutés (source unique) | ZeldaCentral |

**Ce que « 100 % » ne couvre pas et ne peut pas couvrir ici** : aucune donnée n’a été vérifiée en jeu ; les probabilités de butin et les étapes de quêtes reposent chacune sur une seule source publiée ; 40 armes propres à TotK n’ont pas de nom français trouvé (affichées en anglais officiel) et 97 noms d’armes viennent de Breath of the Wild (signalés).

## V7.12 (11 novembre 2026) — troisième et quatrième sources

Nouvelles sources (réseau autorisé par l’utilisateur) : **Zelda Wiki** (traductions officielles, `zeldawiki_translations_…`), **ZeldaCentral** (tables de butin et statistiques, `zeldacentral_…`), **Thonky** (coordonnées et quêtes, `thonky_…`).

| Catégorie | Recoupés | Détail |
|---|---:|---|
| Quêtes | 253 / 253 renseignées ; 249 titres et 88 récompenses recoupés | « En plein dans le puits » (« Fell into a Well! ») ajoutée depuis Thonky ; titre anglais officiel pour 249 quêtes |
| Positions de boss | 183 / 249 (+ 34 Lynels) | Thonky, ≤ 30 u (ou ≤ 100 u « partiel », zone de déplacement) |
| Grottes | 140 / 147 | au moins une entrée à ≤ 30 u (Thonky) |
| Puits | 58 / 58 (56 en triple source) | Thonky confirme la position V6 du puits du col de Pigar |
| Tours / panneaux de Boulieh | 9 / 15 · 21 / 81 | Thonky ne publie qu’une partie des coordonnées |
| Armes | 160 / 174 (114 puissance + durabilité exactes) | 14 conflits, surtout armes à deux mains (écarts de 1 à 3 points) |
| Bestiaire (PV) | 81 / 96 | 2 conflits (Stal-Bokoblin, Stal-Lézalfos : 2 contre 1 PV) |
| Recettes | 212 / 228 (nom FR identique dans 2 sources) | 3 conflits de nom, 4 coquilles de Puissance-Zelda corrigées |
| Tables de butin | 85 / 96 fiches reliées | probabilités par tirage (ZeldaCentral), source unique |
| Noms français | 950 objets/ennemis (TotK) ; 128 armes (nom BotW, signalé « à confirmer ») | 46 armes restent en anglais |

Registre : 2 692 enregistrements — 2 005 recoupés (204 multi-sources), 277 partiels, 361 importés, 24 sans source, 24 conflits, 1 corrigé.

## V7.10–V7.11 (11 novembre 2026) — recoupement Puissance-Zelda et refonte visuelle

Seconde source indépendante : Puissance-Zelda (solution française, collecte du 11/11/2026). Seules les coordonnées, noms et valeurs sont repris (`data/sources/puissance_zelda_*.json`), jamais le texte rédactionnel.

| Catégorie | Recoupés (≤ 30 u en 3D) | Écarts documentés |
|---|---:|---|
| Korogus | 862 + 26 partiels (≤ 100 u) sur 900 | 12 sans relevé proche (Puissance-Zelda liste 895 positions) |
| Sanctuaires | 148 / 152 (dont 102 X/Y racine + XYZ) | 4 non recoupés |
| Puits | 57 / 58 | 1 : doublon de coordonnées dans la source de recoupement |
| Larmes du dragon | 10 / 12 | 2 : erreurs probables de la source de recoupement (copie d’un sanctuaire ; signe de X) |
| Vœux des Sages | 19 / 20 | — |
| Armures (pièces) | 107 / 135 (DEF des 4 paliers et/ou XYZ) | 1 conflit de DEF ; 135 noms français, dont 58 appariés par ensemble et emplacement |
| Recettes | numérotation identique dans les deux sources | 228 noms et ingrédients français |

Quêtes principales : la suite des quêtes régionales (temples du Vent, du Feu, de l’Eau, de la Foudre), « La porte close », « Le cinquième Sage » et « La voix venue du passé » est désormais renseignée depuis les pages de donjon, avec récompenses (réceptacles, serments des Sages).

Refonte V7.11 : en-tête et compteurs uniquement sur l’accueil, compteurs de progression réels (Korogus, quêtes, recettes, part des données recoupées), barre supérieure fixe, navigation mobile avec indicateur, cartes et listes retravaillées, armures triées par nom français.

Registre de fiabilité : 2 062 enregistrements — 1 346 recoupés (123 avec ≥ 2 sources), 78 partiels, 607 importés, 25 sans source, 5 conflits, 1 corrigé.

## V7.9 (11 novembre 2026)

- **Quêtes : 252 sur 253 avec étapes et récompenses** (758 étapes, 392 récompenses), chacune liée à l’URL de la section Puissance-Zelda d’où elle est tirée (collecte du 11/11/2026). Texte reformulé en français, pas de copie. Statut `importe` (source unique, non recoupée). 26 quêtes portent une note (section partielle, numérotation déduite de l’ordre de la source, incohérence interne de la source) ; 22 n’ont aucune récompense lue dans la source (affichées « Non renseigné (à vérifier) »). Les 5 quêtes régionales (Babil, Riju, Sidon, Yunobo, « Retour en Hyrule ») ne couvrent que le trajet décrit par la page liée. `missions_35` « En plein dans le puits » : aucune section dédiée dans la source, reste « à vérifier ». Schéma `data/sources/quests/<id>.json`, contrôlé par `scripts/build_quests.py`.
- **Korogus : 16 régions sur 16, 900 positions.** Ajout de Popla Foothills (91), Rabella Wetlands (45), Eldin Canyon (62), Ulri Mountain (45), Gerudo Canyon (53), Gerudo Highlands (56) = 352 positions, pages régionales ConsolePulse collectées le 11/11/2026. Lignes et graines égales au total régional pour chaque région. L’extracteur a reproduit à l’identique 3 régions déjà importées avant d’être utilisé. Source unique, non recoupée.

## Ce qui reste non prouvé

Exactitude en jeu (aucune vérification sur console). Probabilités de butin : une seule source. Noms français TotK de 46 armes (introuvables) et confirmation TotK des 128 noms repris de BotW. Étapes de quêtes : une seule source chacune. 66 positions de boss, 60 panneaux de Boulieh et 6 tours sans seconde source. Les blocs V7.1 reposent chacun sur une seule source.
