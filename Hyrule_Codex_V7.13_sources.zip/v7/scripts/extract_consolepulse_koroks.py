#!/usr/bin/env python3
"""Extrait une page régionale ConsolePulse (HTML enregistré) au format data/sources/koroks/<slug>.txt.
Usage : python3 scripts/extract_consolepulse_koroks.py page.html > data/sources/koroks/<slug>.txt
Validé le 11/11/2026 : reproduit à l’identique sahasra-slope, thyphlo-ruins et lookout-landing."""
import re, sys
from html.parser import HTMLParser
class P(HTMLParser):
    def __init__(s):
        super().__init__(); s.cells=[]; s.stack=[]; s.cur=None
    def handle_starttag(s,tag,a):
        a=dict(a); st=a.get('style') or ''
        m=re.search(r'grid-column-start:(\d+);grid-row:(\d+)',st)
        if tag=='div' and m and s.cur is None:
            s.cur=[int(m.group(2)),int(m.group(1)),[]]; s.depth=0
        if s.cur is not None and tag=='div': s.depth+=1
        if s.cur is not None and tag in('p','li','br'): s.cur[2].append(' ')
    def handle_endtag(s,tag):
        if s.cur is not None and tag=='div':
            s.depth-=1
            if s.depth==0:
                s.cells.append((s.cur[0],s.cur[1],re.sub(r'\s+',' ',''.join(s.cur[2])).strip())); s.cur=None
    def handle_data(s,d):
        if s.cur is not None: s.cur[2].append(d)
def parse(path):
    p=P(); p.feed(open(path,encoding='utf-8').read())
    tables=[]; rows={}; prev=None
    # cells sequential; new table when row index decreases
    for r,c,t in p.cells:
        if prev is not None and r<prev: tables.append(rows); rows={}
        rows.setdefault(r,{})[c]=t; prev=r
    tables.append(rows)
    return tables

def conv(path):
    t = parse(path)[0]; out = []
    for r in sorted(t):
        c = t[r]
        lay = {'Surface':'F','Sky':'S'}[c[2]]
        pts = []
        for p in c[5].split('→'):
            v = [int(x) for x in p.split(',')]; assert len(v)==3, c; pts.append(','.join(map(str,v)))
        assert c[4] in ('1','2'), c
        out.append('|'.join([c[3], c[4], ';'.join(pts), c[6], c[7], lay]))
    return out
if __name__=='__main__':
    print('\n'.join(conv(sys.argv[1])))
