#!/usr/bin/env python3
"""Assemble data/v7/encyclo.json (armes, armures + améliorations, ennemis, recettes) depuis data/sources/.
Chaque bloc garde sa source, sa date de collecte et ses limites. Aucune valeur n'est complétée par supposition."""
from pathlib import Path
import json
D = Path(__file__).resolve().parents[1] / 'data'
rd = lambda n: json.loads((D / 'sources' / n).read_text(encoding='utf-8'))
meta = lambda s: {k: s[k] for k in ('source_url', 'source_title', 'collected_at', 'note')}
# Traductions DESCRIPTIVES (non officielles) des effets, signalées comme telles dans l'interface.
FX = {'Attack Up': 'Attaque +', 'Heat Resistance': 'Résistance à la chaleur', 'Cold Resistance': 'Résistance au froid',
 'Shock Resistance': 'Résistance électrique', 'Flame Guard': 'Protection contre les flammes', 'Stealth Up': 'Discrétion +',
 'Climb Speed Up': 'Escalade plus rapide', 'Swim Speed Up': 'Nage plus rapide', 'Slip Resistance': 'Adhérence (anti-glisse)',
 'Gloom Resistance': 'Résistance au miasme', 'Glow': 'Luminosité', 'Energy Up': 'Batterie soneau +', 'Skydive Mobility Up': 'Chute libre plus maniable',
 'Sand Speed Up': 'Vitesse sur le sable', 'Snow Speed Up': 'Vitesse sur la neige', 'Hot Weather Attack': 'Attaque + par forte chaleur',
 'Cold Weather Attack': 'Attaque + par grand froid', 'Stormy Weather Attack': 'Attaque + par orage', 'Rupee Padding': 'Rubis en cas de dégâts',
 'Unfreezable': 'Insensible au gel', 'Lightning Proof': 'Insensible à la foudre', 'Fireproof': 'Insensible au feu', 'Impact Proof': 'Pas de dégâts de chute',
 'Night Speed Up': 'Vitesse + la nuit', 'Charge Attack Stamina Up': 'Attaque chargée moins coûteuse', 'Shock Damage Resist': 'Dégâts électriques réduits',
 'Slip Proof': 'Ne glisse plus', 'Gloom Attack Resist': 'Attaques de miasme réduites', 'Swim Dash Stamina Up': 'Sprint aquatique moins coûteux',
 'Climbing Jump Stamina Up': 'Saut en escalade moins coûteux', 'Hot Weather Charge': 'Attaque chargée + par chaleur', 'Stormy Weather Charge': 'Attaque chargée + par orage',
 'Cold Weather Charge': 'Attaque chargée + par froid', 'Energy Recharge Up': 'Recharge de batterie +', 'Shining Steps': 'Traînée lumineuse',
 'Master Sword Beam Up': 'Rayon de l’Épée de légende +', 'Ancient Hero transformation': 'Apparence du héros antique', 'None': '—'}
WFX = {'Water Warrior': 'Dégâts doublés quand Link est mouillé', 'Desperate Strength': 'Dégâts doublés quand il reste peu de cœurs',
 'Gloom Toll': 'Inflige du miasme au porteur', 'Strong Fusion': 'Bonus d’amalgame renforcé', 'Improved Sneakstrike': 'Attaque furtive renforcée',
 'Improved Flurry Rush': 'Déluge (contre-attaque) renforcé', 'Extra Durable': 'Durabilité accrue', 'Zonaite-Powered': 'Renforcé par les engins soneaus'}
KIND = {'1H': 'Arme à une main', '2H': 'Arme à deux mains', 'SP': 'Lance', 'BOW': 'Arc', 'SH': 'Bouclier'}
KO = rd('consolepulse_koroks.json')
SG, AD = rd('consolepulse_sages_2026-09-26.json'), rd('consolepulse_addison_2026-09-16.json')
# V7.10 : recoupement des vœux des Sages avec Puissance-Zelda (≤ 30 u, distance 3D)
import math
PZ = rd('puissance_zelda_coords_2026-11-11.json')
for w in SG['wills']:
    b = min(PZ['sages'], key=lambda q: math.dist(w['xyz'], q['xyz'])); d = math.dist(w['xyz'], b['xyz'])
    w['checks'] = [c for c in w['checks'] if 'puissance-zelda' not in c['src']]
    if d <= 30:
        w['checks'].append({'src': b['page'], 'dist': round(d)})
C, L = rd('consolepulse_caves_2026-09-13.json'), rd('thonky_lynels_2025-02-04.json')
A, W, E, R = rd('consolepulse_armor_2026-09-13.json'), rd('samurai_weapons_2023-06-02.json'), rd('rankedboost_enemies_2026-11-11.json'), rd('consolepulse_recipes_2026-09-26.json')
nums = sorted(i['no'] for i in W['items'])
missing = [n for n in range(329, 504) if n not in nums]
# V7.10 : noms français des armures (Puissance-Zelda), appariement documenté dans la source
PZA = {x['en']: x for x in rd('puissance_zelda_armor_2026-11-11.json')['pieces']}
for p in A['pieces']:
    m = PZA.get(p['name'])
    if m: p['fr'], p['fr_method'] = m['fr'], m['method']
# V7.10 : noms et ingrédients français des recettes (Puissance-Zelda), par numéro du livre
PZR = {x['no']: x for x in rd('puissance_zelda_recipes_2026-11-11.json')['items']}
for r in R['recipes']:
    m = PZR.get(r['no'])
    if m: r['fr'], r['ing_fr'] = m['fr'], m['ing']
ZWT = rd('zeldawiki_translations_2026-11-11.json')['totk']
for r in R['recipes']:
    z = ZWT.get(r['name'])
    if z: r['fr_zw'] = z
ZC = rd('zeldacentral_drop_tables_2026-11-11.json')
out = {
 'armor': {**meta(A), 'fees': A['fees'], 'fees_aspect': A['fees_aspect'], 'recipes': A['recipes'], 'pieces': A['pieces'], 'sets': A['sets'], 'fx': FX},
 'weapons': {**meta(W), 'kinds': KIND, 'fx': WFX, 'items': W['items'], 'compendium_range': [329, 503], 'missing_numbers': missing},
 'enemies': {**meta(E), 'items': E['enemies']},
 'caves': {**meta(C), 'items': C['caves'], 'koltin': C['koltin'], 'crosscheck': C['crosscheck_earlygame']},
 'lynels': {**meta(L), 'by_id': {k: {**L['lynels'][v['thonky']], 'dist': v['dist'], 'coliseum': abs(L['lynels'][v['thonky']]['xyz'][0] + 1120) < 20 and abs(L['lynels'][v['thonky']]['xyz'][1] + 1170) < 20} for k, v in L['match'].items()}},
 'koroks': {**meta(KO), 'regions': KO['regions'], 'hestu': KO['hestu'], 'types': KO['types'], 'items': KO['koroks']},
 'sages': {**meta(SG), 'items': SG['wills']},
 'addison': {**meta(AD), 'items': AD['signs']},
 'drops': {'source_url': ZC['source_url'], 'source_title': ZC['source_title'], 'collected_at': ZC['collected_at'], 'note': ZC['note'], 'map': ZC['map'], 'tables': ZC['tables']},
 'recipes': {**meta(R), 'split': R['split'], 'rules': R['rules'], 'thresholds': R['thresholds'], 'items': R['recipes']},
}
(D / 'v7' / 'encyclo.json').write_text(json.dumps(out, ensure_ascii=False, separators=(',', ':')) + '\n', encoding='utf-8')
print('grottes', len(C['caves']), '· Lynels appariés', len(L['match']), '·', 'armures', len(A['pieces']), '· armes', len(W['items']), '(numéros manquants', missing, ') · ennemis', len(E['enemies']), '· recettes', len(R['recipes']))
