#!/usr/bin/env python3
"""Assemble data/v7/quest_details.json (étapes et récompenses des 253 quêtes) depuis data/sources/quests/.

Un fichier par quête sourcée : data/sources/quests/<id>.json, <id> = identifiant de data/quests.json.
  {"id": "main_1", "collected_at": "AAAA-MM-JJ",
   "steps":   [{"text": "…", "src": "https://…"}],
   "rewards": [{"text": "…", "src": "https://…"}]}
Chaque étape et chaque récompense porte SA source (une source par donnée). Aucune valeur n'est déduite :
une quête sans fichier reste « à vérifier » (statut non_source) et n'affiche aucune étape ni récompense.
Le script échoue sur toute entrée sans source https, tout identifiant inconnu ou tout champ inattendu."""
from pathlib import Path
import json, re, sys
D = Path(__file__).resolve().parents[1] / 'data'
Q = json.loads((D / 'quests.json').read_text(encoding='utf-8'))
ids = {q['id'] for q in Q}
DATE = re.compile(r'^\d{4}-\d{2}-\d{2}$')
err = []
items = {}
for f in sorted((D / 'sources' / 'quests').glob('*.json')):
    try:
        x = json.loads(f.read_text(encoding='utf-8'))
    except ValueError as e:
        err.append(f'{f.name} : JSON invalide ({e})'); continue
    qid = x.get('id')
    if qid != f.stem: err.append(f'{f.name} : id « {qid} » différent du nom de fichier')
    if qid not in ids: err.append(f'{f.name} : quête inconnue'); continue
    if set(x) - {'id', 'collected_at', 'steps', 'rewards', 'note'}: err.append(f'{f.name} : champs inattendus {sorted(set(x) - {"id", "collected_at", "steps", "rewards", "note"})}')
    if not DATE.match(str(x.get('collected_at', ''))): err.append(f'{f.name} : collected_at absent ou mal formé')
    for k in ('steps', 'rewards'):
        for i, e in enumerate(x.get(k, [])):
            if set(e) != {'text', 'src'} or not str(e.get('text', '')).strip() or not str(e.get('src', '')).startswith('https://'):
                err.append(f'{f.name} : {k}[{i}] doit contenir exactement text non vide + src https')
    if not x.get('steps') and not x.get('rewards'): err.append(f'{f.name} : ni étape ni récompense')
    items[qid] = {k: x[k] for k in ('collected_at', 'steps', 'rewards', 'note') if k in x}
if err:
    raise SystemExit('Quêtes — erreurs d’import :\n  ' + '\n  '.join(err))
TH = json.loads((D / 'sources' / 'thonky_quests_2026-11-11.json').read_text(encoding='utf-8'))
extra = {}
for qid in ids:
    e = {}
    if qid in TH['en_names']: e['en'] = TH['en_names'][qid]
    if qid in TH['rewards']: e['th'] = {'url': TH['rewards'][qid]['url'], 'reward_en': TH['rewards'][qid]['reward_en']}
    if qid in TH.get('zeldacentral', {}): e['zc'] = TH['zeldacentral'][qid]
    if e: extra[qid] = e
out = {'note': 'Étapes et récompenses importées quête par quête ; chaque ligne cite sa source. '
               'Une quête absente de « items » n’a aucune donnée sourcée : étapes et récompenses à vérifier.',
       'procedure': 'Voir CLAUDE.md, section « Importer les étapes et récompenses d’une quête ».',
       'total': len(Q), 'sourced': len(items), 'items': items, 'extra': extra}
(D / 'v7' / 'quest_details.json').write_text(json.dumps(out, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
print(f'Quêtes : {len(items)} / {len(Q)} avec étapes ou récompenses sourcées ; {len(Q) - len(items)} à vérifier.')
