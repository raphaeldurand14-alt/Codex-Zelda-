#!/usr/bin/env python3
"""Construit le registre de provenance/vérification V7 à partir de data/ et data/sources/.

Sorties (embarquées dans l'app via window.CODEX_V7) :
  data/v7/verification.json  statut par enregistrement   « jeu:id » -> {s, f, src, n}
  data/v7/coverage.json      couverture par catégorie (présent / attendu / vérifié)
  data/v7/sources.json       registre des sources citées
Règle : un statut « vérifié » exige une source EXTERNE concordante distincte de la source d'import.
"""
from pathlib import Path
import json, math, collections

ROOT = Path(__file__).resolve().parents[1]
D = ROOT / 'data'
rd = lambda n: json.loads((D / n).read_text(encoding='utf-8'))
WEB = rd('sources/web_checks_2026-11-11.json')
SAM = rd('sources/samurai_gamers_lightroots_2023-06-09.json')
S = WEB['sources']
V = {}


def put(key, status, fields=None, src=None, note=None):
    e = {'s': status}
    if fields: e['f'] = fields
    if src: e['src'] = src
    if note: e['n'] = note
    V[key] = e


# --- Bestiaire -------------------------------------------------------------
db = rd('db_export.json')
mons = {m['id']: m for m in db['monsters']}
hp_checks = {x['id']: x for x in WEB['monster_hp']}
RBE = json.loads((D / 'sources' / 'rankedboost_enemies_2026-11-11.json').read_text(encoding='utf-8'))
rb_by_id = {e['v6_id']: e for e in RBE['enemies'] if e['v6_id']}
name_checks = {x['id']: x for x in WEB['monster_names_fr']}
CORR = rd('v7/corrections.json')
for mid, m in mons.items():
    h, n = hp_checks.get(mid), name_checks.get(mid)
    notes, src, fields = [], [], []
    status = 'non_source'
    if h:
        src += [S[s] for s in h['src']]
        if m.get('hp') == h['hp']:
            fields.append('PV')
            status = 'verifie_multi' if len(h['src']) > 1 else 'verifie_source'
        else:
            status = 'conflit'
            notes.append(f"PV V6 = {m.get('hp')} ; source = {h['hp']}")
        if h.get('note'): notes.append(h['note'])
    rb = rb_by_id.get(mid)
    if rb and not h:
        src.append(RBE['source_url'])
        filled = any(c['key'] == f'bestiary:{mid}' and c['field'] == 'hp' for c in CORR)
        if filled:
            if status == 'non_source': status = 'importe'
            notes.append(f"PV importés en V7 depuis la fiche {rb['name']} (source unique, non recoupée).")
        elif m.get('hp') == rb['hp']:
            fields.append('PV'); status = 'verifie_source'
            notes.append(f"PV V6 concordants avec la fiche {rb['name']}.")
    if n and n['src']:
        fields.append('nom FR'); src += [S[s] for s in n['src']]
        if status == 'non_source': status = 'verifie_source'
    elif n:
        notes.append('Nom FR aligné sur l’atlas V6, non confirmé par une seconde source.')
    if fields:
        notes.append('Recoupé : ' + ', '.join(fields) + '. Butins, faiblesses et zones non recoupés.')
    elif status == 'non_source':
        _zb = [c for c in CORR if c['key'] == f'bestiary:{mid}' and c['field'] in ('hp', 'tip') and 'zeldacentral' in ' '.join(c['sources'])]
        if _zb:
            status = 'importe'; src += _zb[0]['sources']
            notes.append(f"PV ajoutés en V7 depuis ZeldaCentral ({_zb[0]['new']}), source unique.")
        else:
            notes.append('Aucune source par fiche en V6 : PV, butins et zones à vérifier.')
    put(f'bestiary:{mid}', status, fields, sorted(set(src)), ' '.join(notes))

# --- Amalgame --------------------------------------------------------------
fus = rd('fusion_bonuses.json')
fchk = {x['name']: x for x in WEB['fuse_power']}
for f in fus:
    c = fchk.get(f[0])
    if not c:
        put(f'fusion:{f[0]}', 'non_source', note='Valeur V6 non recoupée.')
    elif c['power'] == f[1]:
        put(f'fusion:{f[0]}', 'verifie_multi' if len(c['src']) > 1 else 'verifie_source', ['bonus'],
            [S[s] for s in c['src']], c.get('note'))
    else:
        put(f'fusion:{f[0]}', 'conflit', ['bonus'], [S[s] for s in c['src']], f"V6 = {f[1]} ; source = {c['power']}")

# --- Racines : recoupement avec Samurai Gamers + litiges -----------------
roots = rd('lightroots.json')
pts = SAM['points']
disp = {x['root']: x for x in WEB['lightroot_disputes']}
root_ok = {}
for r in roots:
    x, y, z = r['xyz']
    if r['id'] in disp:
        d = disp[r['id']]
        put(f"lightroots:{r['id']}", d['status'], ['XYZ'], [S['samurai_roots']] + [S[k] for k in d['others'] if k != 'gamertw_en_roots'], d['verdict'])
        root_ok[r['id']] = d['status'] != 'conflit'
        continue
    best = min(pts, key=lambda p: math.dist((x, y), (p[1], p[2])))
    dxy = math.dist((x, y), (best[1], best[2]))
    dz = None if best[3] is None else abs(best[3] - z)
    if dxy <= 6 and (dz is None or dz <= 6):
        put(f"lightroots:{r['id']}", 'verifie_source', ['XYZ'] if dz is not None else ['XY'], [S['samurai_roots']],
            f"Concorde avec « {best[0]} » ({best[1]}, {best[2]}, {best[3]})." + ('' if dz is not None else ' Z illisible dans la source.'))
        root_ok[r['id']] = True
    elif dxy <= 30:
        put(f"lightroots:{r['id']}", 'verifie_partiel', ['XY approx.'], [S['samurai_roots']],
            f"Écart de {dxy:.0f} u en X/Y (et {dz if dz is not None else '?'} u en Z) avec « {best[0]} » : relevés différents d’un même point probable.")
        root_ok[r['id']] = True
    elif dxy <= 300:
        put(f"lightroots:{r['id']}", 'conflit', ['XYZ'], [S['samurai_roots']],
            f"Écart de {dxy:.0f} u avec « {best[0]} » ({best[1]}, {best[2]}, {best[3]}) : l’une des deux sources se trompe, à confirmer en jeu.")
        root_ok[r['id']] = False
    else:
        put(f"lightroots:{r['id']}", 'importe', note='Absent ou très différent dans la source de recoupement (Samurai Gamers ne liste que 119 racines).')
        root_ok[r['id']] = False
corr = {c['key']: c for c in rd('v7/corrections.json')}
if 'lightroots:root_119' in corr:
    V['lightroots:root_119']['n'] = (V['lightroots:root_119'].get('n', '') + ' Nom corrigé en V7 (à confirmer).').strip()

# --- Sanctuaires : X/Y recoupés via la racine appariée -------------------
import unicodedata
def nn(s): return ''.join(c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn').lower().strip()
shrines = rd('shrines.json')
by_rev = {nn(r['name'].replace('Racine ', ''))[::-1]: r for r in roots}
for s in shrines:
    k = f"shrines:{s['id']}"
    r = by_rev.get(nn(s['name'].replace('Sanctuaire ', '')))
    if k.replace('shrines:', '') == 'shrine_119':
        r = next(x for x in roots if x['id'] == 'root_119')
    if f'shrines:{s["id"]}' in corr:
        put(k, 'corrige_a_confirmer', ['X'], corr[k]['sources'], corr[k]['why'])
    elif s['layer'] == 'Ciel':
        put(k, 'importe', note='Sanctuaire céleste : pas de racine pour recouper. Source d’import : GamerTW.')
    elif r and root_ok.get(r['id']) and math.dist(s['xyz'][:2], r['xyz'][:2]) <= 6:
        note = f"X/Y recoupés via la racine appariée {r['name']}. Z non recoupé."
        if s['xyz'][2] < -100: note += f" Z={s['xyz'][2]} inhabituel en surface : à confirmer."
        put(k, 'verifie_partiel', ['XY'], [S['samurai_roots']], note)
    else:
        put(k, 'importe', note='Non recoupé en V7.')

# --- Atlas : boss, Lynels, puits, tours, larmes ---------------------------
for b in rd('boss_locations_v6.json'):
    note = 'Position importée de GamerTW (répertoire par espèce). Effectif de la variante recoupé au niveau global.'
    st = 'importe'
    if b['layer'] == 'Surface' and b['z'] < -100:
        st, note = 'conflit', f"Couche « Surface » mais Z={b['z']} : vérifier s’il s’agit des Profondeurs."
    put(f"atlas:{b['id']}", st, note=note)
ENC0 = rd('v7/encyclo.json')
for lid, t in ENC0['lynels']['by_id'].items():
    if t['coliseum']:
        put(f'atlas:{lid}', 'verifie_partiel', ['XY approx.'], [ENC0['lynels']['source_url']], 'Colisée flottant : position concordante à ±160 u, 5 combats successifs (Lynel → Lynel d’argent cuirassé).')
    elif t['dist'] <= 15:
        put(f'atlas:{lid}', 'verifie_source', ['XYZ', 'variante'], [ENC0['lynels']['source_url']], f"Position concordante (écart {t['dist']} u) ; variante listée : {t['variant_fr']} (peut évoluer avec la progression).")
    else:
        put(f'atlas:{lid}', 'verifie_partiel', ['XYZ approx.', 'variante'], [ENC0['lynels']['source_url']], f"Écart de {t['dist']} u (zone de patrouille) ; variante listée : {t['variant_fr']} (peut évoluer avec la progression).")
for f, label in [('wells.json', 'Puits'), ('towers.json', 'Tour'), ('dragon_tears.json', 'Larme')]:
    for r in rd(f):
        put(f"atlas:{r['id']}", 'importe', note=f'{label} : position importée de GamerTW, non recoupée en V7.')

# --- V7.10 : recoupement des coordonnées avec Puissance-Zelda ---------------
PZ = rd('sources/puissance_zelda_coords_2026-11-11.json')
TOL = 30  # unités de jeu, distance 3D
PZ_NOTES = {
    'atlas:well_1': "Puissance-Zelda donne pour « Puits du col de Pigar » (-1036, 416, 35), soit la position du puits du pont de Caroc : doublon probable dans cette source. Position V6 conservée, non recoupée.",
    'atlas:tear_1': "Puissance-Zelda donne pour la larme 1 (408, 2133, 144), coordonnées identiques au sanctuaire Musano Qila de la même source : erreur de copie probable. La position V6 est voisine du sanctuaire Sinaqa Uaqa (nouveau relais de Delass), lieu indiqué par la source.",
    'atlas:tear_9': "Puissance-Zelda donne (-4467, -307, 75) : même valeur au signe de X près ; le lieu décrit (alpages Talus, montagne de Lanelle, est d’Hyrule) concorde avec X positif. Signe probablement omis dans la source, à confirmer en jeu.",
}
def pz_near(xyz, cat):
    best = min(PZ[cat], key=lambda q: math.dist(xyz, q['xyz']))
    return best, math.dist(xyz, best['xyz'])
for f, cat in [('wells.json', 'wells'), ('dragon_tears.json', 'tears')]:
    for r in rd(f):
        k = f"atlas:{r['id']}"; b, d = pz_near(r['xyz'], cat)
        if d <= TOL:
            put(k, 'verifie_source', ['XYZ'], [b['page']], f"Concorde avec « {b['label']} » {tuple(b['xyz'])} (écart {d:.0f} u).")
        else:
            put(k, 'importe', note=PZ_NOTES.get(k, f"Relevé Puissance-Zelda le plus proche à {d:.0f} u : non recoupé."))
for s in rd('shrines.json'):
    k = f"shrines:{s['id']}"; b, d = pz_near(s['xyz'], 'shrines'); e = V[k]
    if d > TOL:
        continue
    note = f"XYZ concordants avec Puissance-Zelda « {b['label']} » {tuple(b['xyz'])} (écart {d:.0f} u)."
    if e['s'] == 'verifie_partiel':
        put(k, 'verifie_multi', ['XY', 'XYZ'], sorted(set(e.get('src', []) + [b['page']])), e.get('n', '') + ' ' + note)
    elif e['s'] == 'corrige_a_confirmer':
        put(k, 'corrige', e.get('f'), sorted(set(e.get('src', []) + [b['page']])), e.get('n', '') + ' Correction confirmée : ' + note)
    elif e['s'] in ('importe', 'non_source'):
        put(k, 'verifie_source', ['XYZ'], [b['page']], note)
KO = rd('sources/consolepulse_koroks.json')
for k in KO['koroks']:
    pts = [k['xyz']] + ([k['goal']] if k['goal'] else [])
    b, d = min(((q, math.dist(a, q['xyz'])) for a in pts for q in PZ['koroks']), key=lambda t: t[1])
    key = f"korok:{k['cid']}"
    if d <= TOL:
        put(key, 'verifie_source', ['XYZ'], [b['page']], f"Position ConsolePulse concordante avec Puissance-Zelda (« {b['label']} », écart {d:.0f} u).")
    elif d <= 100:
        put(key, 'verifie_partiel', ['XY approx.'], [b['page']], f"Relevé Puissance-Zelda le plus proche à {d:.0f} u (« {b['label']} ») : même énigme probable, position à préciser.")
    else:
        put(key, 'importe', note=f"Position ConsolePulse ; aucun relevé Puissance-Zelda à moins de 100 u.")

# --- V7.10 : armures recoupées avec Puissance-Zelda --------------------------
PZA = rd('sources/puissance_zelda_armor_2026-11-11.json')
for m in PZA['pieces']:
    f = (['DEF ★1–★4'] if m['tiers_ok'] else []) + (['XYZ'] if m['xyz_dist'] is not None and m['xyz_dist'] <= 30 else [])
    nm = f"Nom français « {m['fr']} » ({'apparié par position' if m['method'] == 'position' else 'apparié par ensemble et emplacement'})."
    if m['tiers_ok'] is False:
        put(f"armor:{m['en']}", 'conflit', ['DEF ★1–★4'], [PZA['source_url']], nm + f" Défenses par palier différentes dans la source : {m['pz_tiers']}.")
    elif f:
        put(f"armor:{m['en']}", 'verifie_source', f, [PZA['source_url']], nm + ' Recoupé : ' + ', '.join(f) + '.')
    else:
        put(f"armor:{m['en']}", 'importe', None, None, nm + ' Statistiques ConsolePulse non recoupées.')

# --- V7.12 : recettes, nom français recoupé (Puissance-Zelda × Zelda Wiki) ----
import difflib
PZR_URL = 'https://www.puissance-zelda.com/24-Tears-of-the-Kingdom/astuces/222-La-liste-des-recettes'
ZW_URL = rd('sources/zeldawiki_translations_2026-11-11.json')['source_url']
def _n(x): return x.lower().replace('œ', 'oe').strip()
for r in rd('v7/encyclo.json')['recipes']['items']:
    k = f"recipes:{r['no']}"
    a, b = r.get('fr'), r.get('fr_zw')
    if a and b and _n(a) == _n(b):
        put(k, 'verifie_source', ['n° du livre', 'nom FR'], [PZR_URL, ZW_URL], f"Nom « {b} » identique dans les deux sources : le rattachement au n° {r['no']} est confirmé.")
    elif a and b and difflib.SequenceMatcher(None, _n(a), _n(b)).ratio() >= .9:
        put(k, 'verifie_source', ['n° du livre', 'nom FR'], [PZR_URL, ZW_URL], f"Puissance-Zelda écrit « {a} », Zelda Wiki « {b} » (orthographe retenue) : même plat.")
    elif a and b:
        put(k, 'conflit', ['nom FR'], [PZR_URL, ZW_URL], f"Puissance-Zelda : « {a} » ; Zelda Wiki : « {b} ». À confirmer en jeu.")
    else:
        put(k, 'importe', note='Nom français d’une seule source (Puissance-Zelda).')

# --- V7.12 : recoupement avec Thonky (boss, puits, tours, grottes, panneaux) -
TH = rd('sources/thonky_coords_2026-11-11.json')
FAM = {'Hinox': 'Hinox', 'Black Hinox': 'Hinox', 'Blue Hinox': 'Hinox', 'Stalnox': 'Hinox', 'Stone Talus': 'Lithorok', 'Stone Talus (Rare)': 'Lithorok',
       'Stone Talus (Luminous)': 'Lithorok', 'Battle Talus': 'Lithorok', 'Frost Talus': 'Lithorok', 'Igneo Talus': 'Lithorok', 'Frox': 'Gigatracien',
       'Obsidian Frox': 'Gigatracien', 'Blue-White Frox': 'Gigatracien', 'Flux Construct I': 'Golemax', 'Flux Construct II': 'Golemax',
       'Flux Construct III': 'Golemax', 'Flame Gleeok': 'Griock', 'Frost Gleeok': 'Griock', 'Thunder Gleeok': 'Griock', 'King Gleeok': 'Griock', 'Molduga': 'Moldarquor'}
for b in rd('boss_locations_v6.json'):
    k = f"atlas:{b['id']}"
    if V[k]['s'] == 'conflit':
        continue
    pts = [m for m in TH['monsters'] if FAM.get(m['name'].split(':')[0]) == b['type']]
    if not pts:
        continue
    m = min(pts, key=lambda q: math.dist((b['x'], b['y'], b['z']), q['xyz'])); d = math.dist((b['x'], b['y'], b['z']), m['xyz'])
    if d <= 30:
        put(k, 'verifie_source', ['XYZ'], [TH['pages']['monsters']], f"Concorde avec Thonky « {m['name']} » {tuple(m['xyz'])} (écart {d:.0f} u). Variante à confirmer en jeu.")
    elif d <= 100:
        put(k, 'verifie_partiel', ['XYZ approx.'], [TH['pages']['monsters']], f"Thonky « {m['name']} » à {d:.0f} u : même rencontre probable (zone de déplacement).")
for f, cat in [('wells.json', 'wells'), ('towers.json', 'towers')]:
    for r in rd(f):
        k = f"atlas:{r['id']}"; m = min(TH[cat], key=lambda q: math.dist(r['xyz'], q['xyz'])); d = math.dist(r['xyz'], m['xyz'])
        if d > 30:
            continue
        e = V[k]
        if e['s'] == 'verifie_source':
            put(k, 'verifie_multi', ['XYZ'], sorted(set(e['src'] + [TH['pages'][cat]])), e.get('n', '') + f" Thonky : {tuple(m['xyz'])} (écart {d:.0f} u).")
        else:
            put(k, 'verifie_source', ['XYZ'], [TH['pages'][cat]], f"Concorde avec Thonky {tuple(m['xyz'])} (écart {d:.0f} u).")
ENCV = rd('v7/encyclo.json')
for c in ENCV['caves']['items']:
    ds = [(math.dist(e, q['xyz']), q) for e in c['entrances'] for q in TH['caves']]
    d, q = min(ds, key=lambda t: t[0])
    if d <= 30:
        put(f"caves:{c['id']}", 'verifie_source', ['entrée XYZ'], [TH['pages']['caves']], f"Une entrée concorde avec Thonky ({q['name']}, écart {d:.0f} u).")
    else:
        put(f"caves:{c['id']}", 'importe', note='Entrées ConsolePulse non recoupées.')
for a in ENCV['addison']['items']:
    q = min(TH['addison'], key=lambda t: math.dist(a['xyz'], t['xyz'])); d = math.dist(a['xyz'], q['xyz'])
    if d <= 30:
        put(f"addison:{a['no']}", 'verifie_source', ['XYZ'], [TH['pages']['addison']], f"Concorde avec Thonky {tuple(q['xyz'])} (écart {d:.0f} u).")
    else:
        put(f"addison:{a['no']}", 'importe', note='Position ConsolePulse non recoupée (Thonky ne publie qu’une partie des panneaux).')

# --- V7.12 : statistiques recoupées avec ZeldaCentral (armes, PV) ----------
ZS = rd('sources/zeldacentral_stats_2026-11-11.json')
for w in rd('v7/encyclo.json')['weapons']['items']:
    n = w['name']; base = n.rstrip('+'); plus = n.endswith('+')
    z = next((ZS['weapons'][c] for c in ([f'{base} (pristine)'] if plus else [f'{base} (decayed)', base]) if c in ZS['weapons']), None)
    k = f'arsenal:{n}'
    if not z:
        put(k, 'importe', note='Statistiques Samurai Gamers, absentes de la table ZeldaCentral.'); continue
    pw = str(w.get('power')).split()[0]; du = str(w.get('durability'))
    ok_p, ok_d = pw == z['value'], du == z['durability']
    lab = 'puissance' if z['kind'] == 'attack' else 'défense'
    if ok_p and ok_d:
        put(k, 'verifie_source', [lab, 'durabilité'], [ZS['source_url_weapons']], f"{lab.capitalize()} {pw} et durabilité {du} identiques dans ZeldaCentral.")
    elif ok_p or ok_d:
        put(k, 'verifie_partiel', [lab if ok_p else 'durabilité'], [ZS['source_url_weapons']], f"ZeldaCentral : {lab} {z['value']}, durabilité {z['durability']} (ici {pw} / {du}).")
    else:
        put(k, 'conflit', [lab, 'durabilité'], [ZS['source_url_weapons']], f"ZeldaCentral : {lab} {z['value']}, durabilité {z['durability']} ; Samurai Gamers : {pw} / {du}. À confirmer en jeu.")
_DRM = rd('sources/zeldacentral_drop_tables_2026-11-11.json')['map']
for mid, n in _DRM.items():
    z = ZS['enemies'].get(n); m = mons.get(mid); k = f'bestiary:{mid}'
    if not z or not m or m.get('hp') is None or k not in V:
        continue
    e = V[k]; zhp = z['hp'].replace(',', '')
    if str(m['hp']) == zhp:
        src = sorted(set(e.get('src', []) + [ZS['source_url_enemies']])); f = sorted(set((e.get('f') or []) + ['PV']))
        st = 'verifie_multi' if e['s'] in ('verifie_source', 'verifie_multi') else ('verifie_source' if e['s'] in ('importe', 'non_source', 'verifie_partiel') else e['s'])
        put(k, st, f, src, (e.get('n', '') + f" PV {zhp} confirmés par ZeldaCentral ({n}).").strip())
    else:
        put(k, 'conflit', ['PV'], sorted(set(e.get('src', []) + [ZS['source_url_enemies']])), (e.get('n', '') + f" ZeldaCentral donne {zhp} PV ({n}) contre {m['hp']}.").strip())

# --- V7.13 : quatrième source de positions (Game8) ---------------------------
G8 = rd('sources/game8_coords_2026-11-11.json')
def _upgrade(k, url, d, xyz):
    e = V.get(k, {'s': 'importe'})
    note = f"Game8 {tuple(xyz)} (écart {d:.0f} u)."
    if e['s'] in ('verifie_source', 'verifie_multi'):
        put(k, 'verifie_multi', sorted(set((e.get('f') or []) + ['XYZ'])), sorted(set(e.get('src', []) + [url])), (e.get('n', '') + ' ' + note).strip())
    elif e['s'] in ('importe', 'non_source', 'verifie_partiel'):
        put(k, 'verifie_source', ['XYZ'], sorted(set(e.get('src', []) + [url])), (e.get('n', '') + ' Concorde avec ' + note).strip())
def _near(xyz, pts):
    q = min(pts, key=lambda t: math.dist(xyz, t)); return q, math.dist(xyz, q)
for r in rd('towers.json'):
    q, d = _near(r['xyz'], G8['towers']['points'])
    if d <= 30: _upgrade(f"atlas:{r['id']}", G8['towers']['url'], d, q)
for a in rd('v7/encyclo.json')['addison']['items']:
    q, d = _near(a['xyz'], G8['addison']['points'])
    if d <= 30: _upgrade(f"addison:{a['no']}", G8['addison']['url'], d, q)
for b in rd('boss_locations_v6.json'):
    pts = [x for x in G8['bosses'] if x['family'] == b['type']]
    if not pts: continue
    x = min(pts, key=lambda t: math.dist((b['x'], b['y'], b['z']), t['xyz'])); d = math.dist((b['x'], b['y'], b['z']), x['xyz'])
    if d <= 30: _upgrade(f"atlas:{b['id']}", x['url'], d, x['xyz'])

# --- V7.13 : armures et amalgame recoupés avec ZeldaCentral -----------------
import re as _re, unicodedata as _ud
def _nz(x): return _re.sub(r'[^a-z0-9]', '', _ud.normalize('NFD', x.lower()).encode('ascii', 'ignore').decode())
_ZW = rd('sources/zeldawiki_translations_2026-11-11.json')
ZA = rd('sources/zeldacentral_armor_materials_2026-11-11.json')
_A = rd('v7/encyclo.json')['armor']
for pc in _A['pieces']:
    z = ZA['armor'].get(pc['name']); k = f"armor:{pc['name']}"
    if not z: continue
    vals = [int(x) for x in _re.findall(r'\d+', z['def'])]
    ours = [pc['base']] + ([t['def'] for t in _A['recipes'][pc['recipe']]] if pc['recipe'] else [])
    e = V.get(k, {'s': 'importe'})
    if vals == ours:
        st = 'verifie_multi' if e['s'] in ('verifie_source', 'verifie_multi') else 'verifie_source'
        put(k, st, sorted(set((e.get('f') or []) + ['DEF base', 'DEF ★1–★4'] if pc['recipe'] else (e.get('f') or []) + ['DEF'])),
            sorted(set(e.get('src', []) + [ZA['source_url_armor']])), (e.get('n', '') + f" Défenses {'/'.join(map(str, ours))} identiques dans ZeldaCentral.").strip())
    else:
        put(k, 'conflit', ['DEF'], sorted(set(e.get('src', []) + [ZA['source_url_armor']])), (e.get('n', '') + f" ZeldaCentral : {z['def']} ; ConsolePulse : {'/'.join(map(str, ours))}.").strip())
_FUSE_EN = {'Os de Gibdo': 'Gibdo Bone', 'Corne de Bokoblin chef d’argent': 'Silver Boss Bokoblin Horn', 'Croc de Gigatracien bleu-blanc': 'Blue-White Frox Fang',
            'Corne de Golem capitaine IV': 'Captain Construct IV Horn', 'Corne d’Horriblin d’argent': 'Silver Horriblin Horn', 'Corne de Bokoblin chef noir': 'Black Boss Bokoblin Horn',
            'Corne de Dinraal': "Dinraal's Horn", 'Diamant': 'Diamond', 'Corne de Golem capitaine III': 'Captain Construct III Horn', 'Croc de Gigatracien d’obsidienne': 'Obsidian Frox Fang',
            'Corne de Golem soldat IV': 'Soldier Construct IV Horn', 'Corne de dragon blanc': "Light Dragon's Horn", 'Éclat de croc de Dinraal': "Shard of Dinraal's Fang"}
_rev = {_nz(v): k for k, v in _ZW['totk'].items()}
for f in fus:
    en = _rev.get(_nz(f[0])) or _FUSE_EN.get(f[0]); z = ZA['materials'].get(en) if en else None
    k = f'fusion:{f[0]}'
    if not z: continue
    nums = _re.findall(r'\d+', z['fuse'])
    if not nums: continue
    off = _ZW['totk'].get(en, '')
    nm = '' if not off or _nz(off) == _nz(f[0]) else f" Nom officiel (Zelda Wiki) : « {off} »."
    e = V.get(k, {'s': 'non_source'})
    if int(nums[0]) == f[1]:
        st = 'verifie_multi' if e['s'] in ('verifie_source', 'verifie_multi') else 'verifie_source'
        put(k, st, sorted(set((e.get('f') or []) + ['bonus'])), sorted(set(e.get('src', []) + [ZA['source_url_materials']])), (e.get('n', '') + f" Bonus {f[1]} confirmé par ZeldaCentral ({en})." + nm).strip())
    else:
        put(k, 'conflit', ['bonus'], sorted(set(e.get('src', []) + [ZA['source_url_materials']])), (e.get('n', '') + f" ZeldaCentral ({en}) : {nums[0]} contre {f[1]}." + nm).strip())

# --- V7.13 : carte ZeldaCentral (markers.json), recoupement transversal ------
ZM = rd('sources/zeldacentral_markers_2026-11-11.json'); _ZMU = ZM['source_url']
def _zm(k, xyz, cat, label=''):
    pts = ZM['cats'].get(cat, [])
    if not pts: return
    q = min(pts, key=lambda t: math.dist(xyz, t['xyz'])); d = math.dist(xyz, q['xyz'])
    e = V.get(k, {'s': 'importe'})
    if d <= 30:
        note = f"Carte ZeldaCentral « {q['n']} » {tuple(q['xyz'])} (écart {d:.0f} u)."
        if e['s'] in ('verifie_source', 'verifie_multi'):
            put(k, 'verifie_multi', sorted(set((e.get('f') or []) + ['XYZ'])), sorted(set(e.get('src', []) + [_ZMU])), (e.get('n', '') + ' ' + note).strip())
        elif e['s'] in ('importe', 'non_source', 'verifie_partiel'):
            put(k, 'verifie_source', ['XYZ'], sorted(set(e.get('src', []) + [_ZMU])), (e.get('n', '') + ' Concorde avec la ' + note[0].lower() + note[1:]).strip())
        elif e['s'] == 'conflit':
            put(k, 'conflit', e.get('f'), sorted(set(e.get('src', []) + [_ZMU])), (e.get('n', '') + ' Arbitrage : ' + note).strip())
for b in rd('boss_locations_v6.json'):
    _zm(f"atlas:{b['id']}", [b['x'], b['y'], b['z']], b['type'])
for f, cat in [('wells.json', 'wells'), ('towers.json', 'towers'), ('dragon_tears.json', 'tears'), ('lynels.json', 'Lynel')]:
    for r in rd(f): _zm(f"atlas:{r['id']}", r['xyz'], cat)
for r in rd('shrines.json'): _zm(f"shrines:{r['id']}", r['xyz'], 'shrines')
for r in rd('lightroots.json'): _zm(f"lightroots:{r['id']}", r['xyz'], 'lightroots')
_E = rd('v7/encyclo.json')
for c in _E['caves']['items']:
    best = min(c['entrances'], key=lambda e: min(math.dist(e, q['xyz']) for q in ZM['cats']['caves']))
    _zm(f"caves:{c['id']}", best, 'caves')
for a in _E['addison']['items']: _zm(f"addison:{a['no']}", a['xyz'], 'addison')
for k in rd('sources/consolepulse_koroks.json')['koroks']:
    pts = [k['xyz']] + ([k['goal']] if k['goal'] else [])
    best = min(pts, key=lambda a: min(math.dist(a, q['xyz']) for q in ZM['cats']['koroks']))
    _zm(f"korok:{k['cid']}", best, 'koroks')

# --- Couverture --------------------------------------------------------------
bosses = rd('boss_locations_v6.json')
vt = collections.Counter(b['variant'] for b in bosses)
cnt = {c['type']: c for c in WEB['boss_counts']}
present = collections.Counter(b['type'] for b in bosses)
present['Lynel'] = len(rd('lynels.json'))


def verified(prefix):
    return sum(1 for k, v in V.items() if k.startswith(prefix) and v['s'] in ('verifie_multi', 'verifie_source', 'verifie_partiel'))


# --- Quêtes : étapes et récompenses ---------------------------------------
QDX = rd('v7/quest_details.json'); QD = QDX['items']
import re as _re, unicodedata as _ud
_ZW = rd('sources/zeldawiki_translations_2026-11-11.json'); _FRN = rd('v7/fr_names.json') if (D / 'v7' / 'fr_names.json').exists() else {'weapons_botw': {}}
_ARMFR = [(pc['name'], pc['fr']) for pc in rd('v7/encyclo.json')['armor']['pieces'] if pc.get('fr')]
_ITEMS = sorted(list(_ZW['totk'].items()) + list(_ZW['botw_weapons'].items()) + _ARMFR, key=lambda kv: -len(kv[0]))
_RUP = {'rubis violet': '50', 'rubis argenté': '100', 'rubis doré': '300', 'rubis rouge': '20', 'rubis bleu': '5'}
def _nz(x): return _re.sub(r'[^a-z0-9]', '', _ud.normalize('NFD', x.lower()).encode('ascii', 'ignore').decode())
def reward_match(ours, en):
    if not ours or not en: return False
    low = ours.lower(); nums_o = {n.replace('\u202f', '').replace(' ', '') for n in _re.findall(r'\d[\d\u202f ]*\d|\d', ours)}
    nums_o |= {v for k, v in _RUP.items() if k in low}
    nums_e = {n.replace(',', '') for n in _re.findall(r'\d[\d,]*', en)}
    if nums_e and not nums_e <= nums_o: return False
    hits = [fr for e, fr in _ITEMS if len(e) > 3 and _re.search(r'\b' + _re.escape(e) + r's?\b', en, _re.I) and _nz(fr)[:10] in _nz(ours)]
    return bool(hits) or bool(nums_e)
for q in rd('quests.json'):
    d = QD.get(q['id'])
    if d:
        src = sorted({e['src'] for k in ('steps', 'rewards') for e in d[k]})
        ex = QDX.get('extra', {}).get(q['id'], {}); th = ex.get('th'); zc = ex.get('zc')
        ours = ' '.join(e['text'] for e in d['rewards'])
        okr = [x for x in (th, zc) if x and reward_match(ours, x['reward_en'])]
        _rv = rd('sources/quests_review_2026-11-11.json')
        if not okr and q['id'] in _rv['concordant']:
            okr = [x for x in (th, zc) if x]
        if q['id'] in _rv['divergent']:
            put(f"quests:{q['id']}", 'conflit', ['récompense'], sorted(set(src + [x['url'] for x in (th, zc) if x])), _rv['divergent'][q['id']])
            continue
        if okr:
            put(f"quests:{q['id']}", 'verifie_partiel', ['récompense'], sorted(set(src + [x['url'] for x in okr])),
                'Récompense concordante avec ' + ' et '.join(('Thonky' if x is th else 'ZeldaCentral') + f" (« {x['reward_en'][:80]} »)" for x in okr) + '. Étapes : source unique.')
        else:
            put(f"quests:{q['id']}", 'importe', None, src,
                f"{len(d['steps'])} étape(s), {len(d['rewards'])} récompense(s) importées ({len(src)} source(s)), non recoupées." + (f" Thonky indique : « {th['reward_en'][:120]} »" if th else '') + (f" ZeldaCentral indique : « {zc['reward_en'][:120]} »" if zc else ''))
    else:
        put(f"quests:{q['id']}", 'non_source', note='Étapes et récompenses à vérifier : aucune source importée.')

cov = []
def add(cat, pres, exp, exp_status, exp_src, ver, ver_what, note=''):
    cov.append({'cat': cat, 'present': pres, 'expected': exp, 'expected_status': exp_status,
                'expected_src': exp_src, 'verified': ver, 'verified_what': ver_what, 'note': note})

add('Racines (Profondeurs)', len(roots), 120, 'source', [S['samurai_roots']], verified('lightroots:'), 'XYZ recoupés')
add('Sanctuaires', len(shrines), 152, 'source', [S['consolepulse_roots']], verified('shrines:'), 'X/Y via racine et/ou XYZ Puissance-Zelda', 'XYZ comparés aux fiches de sanctuaire Puissance-Zelda (≤ 30 u).')
for t in ['Lynel', 'Hinox', 'Lithorok', 'Gigatracien', 'Golemax', 'Griock', 'Moldarquor']:
    c = cnt[t]
    split_ok = all(vt.get(k) == v for k, v in c.get('split', {}).items()) if c.get('split') else None
    add(f'Positions : {t}', present[t], c['total'], 'conflit' if c.get('conflict') else 'source',
        [S[s] for s in c['src']], verified('atlas:lynel_') if t == 'Lynel' else sum(1 for b in bosses if b['type'] == t and V[f"atlas:{b['id']}"]['s'].startswith('verifie')), 'positions + variantes (Thonky)' if t == 'Lynel' else 'positions recoupées avec Thonky (≤ 30 u, ou ≤ 100 u partiel)',
        (c.get('conflict', '') + (' Répartition par variante identique à la source.' if split_ok else '')).strip())
add('Puits', len(rd('wells.json')), 58, 'source', [PZ['base_url'] + '880-Liste-de-tous-les-puits-dHyrule'], verified('atlas:well_'), 'XYZ recoupés (Puissance-Zelda, ≤ 30 u)', '58 puits listés par Puissance-Zelda ; 1 écart dû à un doublon de cette source.')
add('Tours', len(rd('towers.json')), 15, 'source', ['https://consolepulse.com/nintendo/zelda/guides/zelda-totk-complete-map-surface-sky-depths-guide', TH['pages']['towers']], verified('atlas:tower_'), 'XYZ recoupés (Thonky, Game8, ≤ 30 u)', 'Coordonnées Game8 pour les 15 tours.')
add('Larmes du dragon', len(rd('dragon_tears.json')), 12, 'source', [PZ['base_url'] + '830-Les-souvenirs-et-les-larmes-du-dragon'], verified('atlas:tear_'), 'XYZ recoupés (Puissance-Zelda, ≤ 30 u)', '2 écarts expliqués par des erreurs de la source de recoupement.')
add('Bestiaire (fiches)', len(mons), None, 'inconnu', [], verified('bestiary:'), 'PV et/ou nom FR', 'Nombre total d’ennemis du jeu non établi : pas de taux de complétude.')
add('Bonus d’amalgame', len(fus), None, 'inconnu', [], verified('fusion:'), 'valeur du bonus', f"{len(WEB['fuse_power_missing_in_v6'])} matériaux sourcés absents de la liste V6 (noms FR non vérifiés).")
add('Armes (sélection V6, remplacée)', len(db['weapons']), None, 'inconnu', [], 0, '—', 'Sélection historique V6 conservée pour les sauvegardes ; remplacée par l’arsenal complet (174, recoupé).')
add('Armures (ensembles V6, remplacés)', len(db['armors']), None, 'inconnu', [], 0, '—', 'Sélection historique V6 conservée pour les sauvegardes ; remplacée par les 135 pièces recoupées.')
_THQ = rd('sources/thonky_quests_2026-11-11.json')
add('Quêtes (intitulés)', len(rd('quests.json')), 253, 'source', ['https://www.puissance-zelda.com/24-Tears-of-the-Kingdom/solution/854-Liste-de-toutes-les-quetes', 'https://zeldawiki.wiki/wiki/Data:Translations/TotK/Miscellaneous'], len(_THQ['en_names']), 'titre FR identique aux traductions Zelda Wiki', 'Titre anglais officiel associé à chaque quête recoupée.')
add('Quêtes (étapes et récompenses)', len(QD), len(rd('quests.json')), 'source', ['https://www.puissance-zelda.com/24-Tears-of-the-Kingdom/solution/854-Liste-de-toutes-les-quetes', 'https://www.thonky.com/zelda-tears-of-the-kingdom/list-of-quests'], verified('quests:'), 'récompense recoupée (Thonky et/ou ZeldaCentral)', f"{len(rd('quests.json')) - len(QD)} quête(s) sans source ; récompenses recoupées avec Thonky pour {verified('quests:')} quêtes.")
ENC = ENC0
add('Korogus (positions)', len(ENC['koroks']['items']), 900, 'source', [ENC['koroks']['source_url']], verified('korok:'), 'recoupés avec Puissance-Zelda (≤ 30 u ou ≤ 100 u partiel)', f"{sum(1 for r in ENC['koroks']['regions'] if r['imported'])} régions importées sur 16 ; totaux par région connus pour les 16 (900 rencontres, 1 000 graines).")
add('Vœux des Sages', len(ENC['sages']['items']), 20, 'source', [ENC['sages']['source_url']], sum(1 for w in ENC['sages']['items'] if w['checks']), 'recoupés avec ≥ 1 autre site (≤ 30 u)', 'Coffres célestes ; 3 gardés par un Roi Griock.')
add('Panneaux de Boulieh (Addison)', len(ENC['addison']['items']), 81, 'source', [ENC['addison']['source_url'], TH['pages']['addison']], verified('addison:'), 'XYZ recoupés (Thonky, Game8, ≤ 30 u)', 'Surface uniquement.')
add('Grottes', len(ENC['caves']['items']), 147, 'source', [ENC['caves']['source_url']], verified('caves:'), 'au moins une entrée recoupée (Thonky, ≤ 30 u)', f"{sum(len(c['entrances']) for c in ENC['caves']['items'])} entrées / 197 annoncées ; 1 conflit de nom (Oasis Source).")
add('Recettes (livre 1–228)', len(ENC['recipes']['items']), 228, 'source', [ENC['recipes']['source_url'], PZR_URL, ZW_URL], verified('recipes:'), 'n° et nom FR recoupés (Puissance-Zelda × Zelda Wiki)', 'Noms et ingrédients en français (Puissance-Zelda), formules ConsolePulse.')
add('Armures (pièces)', len(ENC['armor']['pieces']), 135, 'source', [ENC['armor']['source_url'], PZA['source_url']], verified('armor:'), 'DEF par palier et/ou XYZ recoupés (Puissance-Zelda)', '103 améliorables, coûts des 4 paliers inclus ; 135 noms français (Puissance-Zelda).')
add('Armes, arcs, boucliers', len(ENC['weapons']['items']), 174, 'source', [ENC['weapons']['source_url'], ZS['source_url_weapons']], verified('arsenal:'), 'puissance/durabilité recoupées (ZeldaCentral)', 'Numéros 329–503 du Compendium tous présents sauf 440 (flèche, sans statistiques).')
add('Ennemis communs (fiches sourcées)', len(ENC['enemies']['items']), None, 'inconnu', [ENC['enemies']['source_url'], ZS['source_url_enemies']], sum(1 for e in ENC['enemies']['items'] if e['name'] in ZS['enemies'] and str(e['hp']) == ZS['enemies'][e['name']]['hp'].replace(',', '')), 'PV recoupés (ZeldaCentral)', 'PV et butins possibles ; 2 écarts (Stal-Bokoblin, Stal-Lézalfos).')
add('Tables de butin (probabilités)', len(ENC['drops']['map']), len(mons), 'source', [ENC['drops']['source_url']], 0, 'source unique (données du jeu publiées)', f"{len(ENC['drops']['tables'])} tables (ennemis, caisses, gisements) ; {len(ENC['drops']['map'])} fiches du bestiaire reliées sur {len(mons)}.")

reg = {k: v for k, v in S.items()}
(D / 'v7' / 'verification.json').write_text(json.dumps(V, ensure_ascii=False, separators=(',', ':')) + '\n', encoding='utf-8')
(D / 'v7' / 'coverage.json').write_text(json.dumps(cov, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
(D / 'v7' / 'sources.json').write_text(json.dumps({'collected_at': WEB['collected_at'], 'method': WEB['method'], 'registry': reg,
    'same_origin_as_v6': WEB.get('same_origin_as_v6', [])}, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
c = collections.Counter(v['s'] for v in V.values())
print('enregistrements :', len(V), dict(c))
for row in cov:
    print(f"{row['cat']:28} {row['present']:>4} / {row['expected']!s:>4}  vérifiés {row['verified']}")
