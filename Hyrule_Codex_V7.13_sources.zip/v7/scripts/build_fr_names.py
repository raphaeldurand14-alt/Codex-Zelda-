#!/usr/bin/env python3
"""Construit data/v7/fr_names.json : noms français (Zelda Wiki) des objets, matériaux, ennemis et armes.
- totk : traductions propres à Tears of the Kingdom ;
- weapons_botw : armes absentes des traductions TotK, nom français de Breath of the Wild pour le même nom anglais
  (affiché avec la mention « nom BotW, à confirmer »). Les variantes « + » reprennent le nom de base suivi de « + »."""
from pathlib import Path
import json
D = Path(__file__).resolve().parents[1] / 'data'
Z = json.loads((D / 'sources' / 'zeldawiki_translations_2026-11-11.json').read_text(encoding='utf-8'))
E = json.loads((D / 'v7' / 'encyclo.json').read_text(encoding='utf-8')) if (D / 'v7' / 'encyclo.json').exists() else {'weapons': {'items': []}}
tot, botw = Z['totk'], Z['botw_weapons']
wb = {}
for w in E['weapons']['items']:
    n = w['name']; base = n.rstrip('+'); plus = '+' * (len(n) - len(base))
    if n in tot: continue
    if base in tot: wb[n] = tot[base] + plus
    elif base in botw: wb[n] = botw[base] + plus
# V7.13 : confirmation TotK par la liste française de Palais Zelda
import re as _re, unicodedata as _ud
PAL = json.loads((D / 'sources' / 'palaiszelda_armes_2026-11-11.json').read_text(encoding='utf-8'))
_nz = lambda x: _re.sub(r'[^a-z0-9]', '', _ud.normalize('NFD', x.lower()).encode('ascii', 'ignore').decode())
_pal = {_nz(x) for x in PAL['names_fr']}
confirmed = sorted(n for n, f in wb.items() if _nz(f.rstrip('+')) in _pal)
manual = {}
for w in E['weapons']['items']:
    n = w['name']; base = n.rstrip('+')
    if base in PAL['manual'] and n not in tot:
        wb[n] = PAL['manual'][base] + '+' * (len(n) - len(base)); manual[n] = True
out = {'source_url': Z['source_url'], 'source_url_botw': Z['source_url_botw'], 'collected_at': Z['collected_at'], 'totk': tot, 'weapons_botw': wb, 'weapons_confirmed': confirmed, 'weapons_manual': sorted(manual), 'source_url_palais': PAL['source_url']}
(D / 'v7' / 'fr_names.json').write_text(json.dumps(out, ensure_ascii=False, separators=(',', ':')) + '\n', encoding='utf-8')
print(f'Noms FR : {len(tot)} TotK, {len(wb)} armes sur {len(E["weapons"]["items"])} (dont {len(confirmed)} confirmées TotK, {len(manual)} appariées manuellement)')
