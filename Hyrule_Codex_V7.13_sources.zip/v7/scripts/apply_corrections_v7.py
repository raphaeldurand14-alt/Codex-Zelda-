#!/usr/bin/env python3
"""Applique les corrections V7 aux données (idempotent) et journalise chaque changement.

Chaque correction conserve l'ancienne valeur, la nouvelle, la justification et la source.
Le journal est écrit dans data/v7/corrections.json (embarqué et affiché dans l'app).
"""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
D = ROOT / 'data'
rd = lambda n: json.loads((D / n).read_text(encoding='utf-8'))
# Les corrections repartent TOUJOURS des fichiers V6 d'origine (idempotence et traçabilité).
ORIG = lambda n: json.loads((D / 'sources' / 'v6_original' / n).read_text(encoding='utf-8'))


def wr(n, obj):
    (D / n).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


WEB = rd('sources/web_checks_2026-11-11.json')
SRC = WEB['sources']
log = []


def record(key, field, old, new, why, sources, status):
    log.append({'key': key, 'field': field, 'old': old, 'new': new, 'why': why,
                'sources': sources, 'status': status})


# C1 — signe de X du sanctuaire Vami Toqa
shrines = ORIG('shrines.json')
s95 = next(s for s in shrines if s['id'] == 'shrine_95')
if s95['xyz'][0] == -3094:
    s95['xyz'][0] = 3094
record('shrines:shrine_95', 'x', -3094, 3094,
       'Signe de X incohérent : sa racine appariée « Aqot Imav » (root_95) est en X=3093 ; '
       'Samurai Gamers place la racine Kotimab (même paire) en 3095,-3209. Le sanctuaire est au-dessus de sa racine.',
       [SRC['samurai_roots']], 'corrige_a_confirmer')
wr('shrines.json', shrines)

# C2 — nom corrompu de la racine 119
roots = ORIG('lightroots.json')
r119 = next(r for r in roots if r['id'] == 'root_119')
old = 'Racine Uqnol Omeriautcnas'
if r119['name'] == old:
    r119['name'] = 'Racine Uqnol Om'
record('lightroots:root_119', 'name', old, 'Racine Uqnol Om',
       'Nom corrompu (« Omeriautcnas » = « sanctuaire » inversé). Une racine porte le nom inversé de son sanctuaire : '
       '« Mo Lonqu » → « Uqnol Om ». Coordonnées recoupées avec la racine Korom (1180,-778,-500).',
       [SRC['samurai_roots']], 'corrige_a_confirmer')
wr('lightroots.json', roots)

# C3 — noms français de variantes (alignés sur l'atlas V6 et Zelda Wiki)
db = ORIG('db_export.json')
mons = {m['id']: m for m in db['monsters']}
for n in WEB['monster_names_fr']:
    m = mons.get(n['id'])
    if not m or 'old' not in n:
        continue
    if m['name'] == n['old']:
        m['name'] = n['name']
    record(f"bestiary:{n['id']}", 'name', n['old'], n['name'],
           n.get('note', 'Nom français officiel (frF) relevé sur Zelda Wiki ; identique au libellé de l’atlas V6.'),
           [SRC[s] for s in n['src']], 'corrige' if n['src'] else 'corrige_a_confirmer')

# C4 — variante manquante : Lithorok fortifié (Battle Talus)
if 'lithorok_fortifie' not in mons:
    db['monsters'].insert(db['monsters'].index(mons['lithorok_rare']) + 1, {
        'id': 'lithorok_fortifie', 'name': 'Lithorok fortifié', 'type': 'Lithoroks', 'hp': 380,
        'tier': 'Intermédiaire', 'area': 'Surface et Profondeurs (voir l’atlas : variante « Lithorok fortifié »)',
        'loot': [], 'weak': 'Non renseigné en V7 (à compléter avec une source).',
        'tip': 'Fiche ajoutée en V7 : nom et PV sourcés, butin non encore importé.', 'icon': '🪨',
        'farm': 'Butin à documenter'})
record('bestiary:lithorok_fortifie', 'record', None, 'ajout (nom, PV 380)',
       'Variante présente 24 fois dans l’atlas V6 mais absente du bestiaire.',
       [SRC['zw_translations_enemies'], SRC['gtm_medals']], 'corrige')
# C5 — PV des ennemis communs : base RankedBoost (source unique, distincte de GamerTW)
RB = rd('sources/rankedboost_enemies_2026-11-11.json')
for e in RB['enemies']:
    m = mons.get(e['v6_id'] or '')
    if not m or m.get('hp') == e['hp']:
        continue
    old = m.get('hp')
    m['hp'] = e['hp']
    record(f"bestiary:{m['id']}", 'hp', old, e['hp'],
           ('PV absents en V6 ; ' if old is None else f'PV V6 ({old}) différents de la source ; ') + f"valeur « Life » de la fiche {e['name']}.",
           [RB['source_url']], 'complete_source' if old is None else 'corrige_a_confirmer')
# C6 — PV des boss de l'histoire (ZeldaCentral, page des stratégies de boss)
ZB = rd('sources/zeldacentral_stats_2026-11-11.json')['bosses']
for mid, en in [('ganon_fantome', 'Phantom Ganon (Boss)'), ('colgera_story', 'Colgera'), ('gohma_story', 'Marbled Gohma'), ('queen_gibdo_story', 'Queen Gibdo'),
                ('mucktorok_story', 'Mucktorok'), ('seized_construct_story', 'Seized Construct'), ('ganondorf_story', 'Demon King Ganondorf'), ('demon_dragon_story', 'Demon Dragon')]:
    m = mons.get(mid); v = ZB['hp'][en]
    if not m or m.get('hp') is not None:
        continue
    if '–' in v:
        m['tip'] = (m.get('tip') or '') + f" PV : {v.replace(',', ' ')} selon la phase ou l’affrontement (ZeldaCentral)."
        record(f'bestiary:{mid}', 'tip', None, f'PV {v}', f'Fourchette de PV publiée pour « {en} » : non convertie en valeur unique.', [ZB['url']], 'complete_source')
    else:
        m['hp'] = int(v.replace(',', ''))
        record(f'bestiary:{mid}', 'hp', None, m['hp'], f'PV absents en V6 ; valeur « Health » de « {en} ».', [ZB['url']], 'complete_source')
wr('db_export.json', db)
wr('bestiary.json', db['monsters'])
wr('materials.json', db['materials'])
wr('weapons.json', db['weapons'])
wr('armor_sets.json', db['armors'])

(D / 'v7').mkdir(exist_ok=True)
wr('v7/corrections.json', log)
print(f'{len(log)} corrections journalisées')
