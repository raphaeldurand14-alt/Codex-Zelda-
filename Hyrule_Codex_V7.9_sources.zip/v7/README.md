# Hyrule Codex V7.9

Encyclopédie / PWA iPhone gratuite, en français, pour *Zelda: Tears of the Kingdom*. **Ce n’est pas une encyclopédie complète** : l’onglet Fiabilité indique, donnée par donnée, ce qui est recoupé, importé, corrigé ou en conflit.

## Démarrer

```bash
python3 scripts/make_all.py              # tout reconstruire et tester (Playwright requis pour l’e2e)
python3 -m http.server 8000 --directory site
```

iPhone : publier le **contenu de `site/`** sur un hébergement HTTPS, ouvrir dans Safari → Partager → Sur l’écran d’accueil. Archive prête : `release/Hyrule_Codex_V7.9_iPhone.zip`.

## Dossiers

- `site/` : application construite (à déployer).
- `src/` : `app.js` (code V1–V6 + marqueurs de données), `v7.js`, `styles.css`, `v7.css`, `index.template.html`.
- `data/` : **source unique** des données ; `data/v7/` provenance, audit, corrections ; `data/sources/` relevés externes datés.
- `scripts/` : `make_all.py`, `build.py`, `audit_data.py`, `apply_corrections_v7.py`, `build_verification.py`.
- `tests/` : `verify_project.py` (structure), `e2e_iphone.py` (navigateur).
- `docs/` : `ETAT_VERIFIE.md`, `AUDIT_V7.md`, `TESTS.md`, `ARCHITECTURE.md`, `SOURCES_ET_QUALITE.md`, `PLAN_DE_COMPLETUDE.md`, `HISTORIQUE.md`.
- `release/` : archive V6 d’origine et archive V7.

## Ajouter ou corriger une donnée

1. Modifier le JSON concerné dans `data/` (ou ajouter une correction journalisée dans `scripts/apply_corrections_v7.py`).
2. Pour la marquer recoupée, ajouter le relevé daté et sa source dans `data/sources/`, puis l’exploiter dans `scripts/build_verification.py`.
3. `python3 scripts/make_all.py`.

Projet amateur, non affilié à Nintendo.
