# Tests V7

```bash
python3 scripts/make_all.py        # corrections, audit, vérification, build, tests
python3 tests/verify_project.py    # 55 tests structurels (données)
python3 tests/e2e_iphone.py        # 78 tests Playwright, viewport iPhone 390×844
```

Résultat du 11/11/2026 (V7.9) : **55/55 structurels, 78/78 e2e** (`docs/RESULTATS_TESTS_V7.txt`).

Couvert : chargement sans erreur JS ; 20 écrans ; absence de défilement horizontal ; badges et blocs de provenance ; parcours Où farmer (matériau → monstres → circuit, algorithme du plus proche voisin) ; persistance `localStorage` ; export/import V7 ; import d’une sauvegarde V5 ; fonctionnement avec l’API externe bloquée ; V7.1 : arsenal (174 lignes, colonne amalgame), armures (135 pièces, liste de courses vérifiée sur un cas calculé à la main, ajout au Sac à butin, détail 4 paliers), recettes (recherche par n°, coche partagée avec Collection), fiche ennemi sourcée, Où farmer à partir d’un butin anglais.

Non-régression : avant toute correction, `python3 scripts/build.py --legacy-only` reproduisait **octet pour octet** le `index.html` V6 à partir de `data/` (vérifié le 11/11/2026). Ce n’est plus le cas depuis les corrections de données, par construction.

## Non testé

- Safari sur un **iPhone réel**, mode écran d’accueil, service worker et hors ligne en HTTPS.
- Exactitude des données dans le jeu.
- VoiceOver et accessibilité complète.
