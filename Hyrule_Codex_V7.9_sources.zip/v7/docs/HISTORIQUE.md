# Historique de la création (versions antérieures)

Le projet a commencé par un fichier HTML interactif livré sans serveur. Des V2 à V4, ajout progressif d'un guide de farming, d'un suivi de progression et d'une interface PWA.

- **V5** : 253 intitulés de quêtes, 152 sanctuaires, 120 racines, 34 Lynels, 58 puits, 15 tours, 12 larmes du dragon, suivi de collections et recherche globale.
- **V6** : retrait au démarrage de 88 anciens emplacements peu vérifiés ; ajout de 249 emplacements de boss à partir de répertoires liés par famille, onglet « Boss + butins », total actif de 640 positions. Les boss possèdent des butins **possibles**, pas de probabilités importées.
- **Handoff** : copie du site V6, découpage déterministe du code en source maintenable, exports JSON non connectés et documentation de reprise pour Claude.

- **V7** (11/11/2026) : `data/` devient la source unique injectée au build ; audit automatique ; registre de provenance par enregistrement (774) ; recoupement externe des racines, PV et bonus d’amalgame ; 7 corrections journalisées ; onglets Fiabilité et Où farmer ? ; signalements locaux ; correction du bug d’import ; 75 tests automatisés.
- **V7.1** (11/11/2026) : arsenal complet (174), armures et améliorations (135 pièces, 4 paliers, liste de courses vers le Sac à butin), livre de recettes (228), 69 fiches d’ennemis communs ; 46 PV ajoutés au bestiaire ; corrections reconstruites à partir des fichiers V6 d’origine (`data/sources/v6_original/`).
- **V7.2** (11/11/2026) : écran Grottes (147, 197 entrées, Grenouilles Bubbul, Koltin) relié à Collection 100 % ; variantes et lieux des 34 Lynels recoupés (Thonky) et pris en compte par « Où farmer ? ».
- **V7.3** (11/11/2026) : 20 vœux des Sages et 81 panneaux de Boulieh positionnés dans Collection 100 %, fiche de position pour tous les collectables hors atlas.
- **V7.4** (11/11/2026) : Korogus rangés par région (16 régions, totaux sourcés), 79 positions détaillées (Lookout Landing, Great Sky Island) avec fiche, téléporteur et solution ; coûts de Hestu.
- **V7.5** (11/11/2026) : Korogus de Hyrule Field, Pikida Stonegrove et Thyphlo Ruins (212 positions sur 900) ; un fichier texte par région dans `data/sources/koroks/` et `scripts/build_koroks.py`.
- **V7.6** (11/11/2026) : Korogus ajoutés — Lindor's Brow, Rospro Pass, Mount Lanayru (393 positions sur 900).
- **V7.7** (11/11/2026) : Korogus ajoutés — Upland Zorana (469 positions sur 900).
- **V7.8** (11/11/2026) : Korogus ajoutés — Sahasra Slope (548 positions sur 900).
- **V7.9** (11/11/2026) : Korogus 900/900 positions (6 dernières régions ConsolePulse) ; étapes et récompenses de 252 quêtes sur 253, une source Puissance-Zelda par ligne ; bloc dépliable sous chaque quête ; 58 tests structurels, 78 e2e.

**Aucune version n'a atteint une exhaustivité démontrée.** Les anciens scripts de build du dossier `history/` servent à comprendre l'origine des données ; leurs chemins absolus ne sont pas portables.
