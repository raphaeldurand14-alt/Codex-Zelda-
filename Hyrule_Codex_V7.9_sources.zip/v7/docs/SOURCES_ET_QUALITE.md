# Sources, limites et politique de fiabilité

Les URL ci-dessous figurent dans le code V5/V6, ou dans le texte des anciens modules. **Leur existence dans le code n'implique pas qu'un contrôle individuel de toutes les lignes ait été effectué** ; elles doivent être auditées avant une publication présentée comme vérifiée.

| Source | Usage déclaré | Points de vigilance |
|---|---|---|
| `https://www.gamertw.com/fr/zelda/totk/lynel` | 34 Lynels | correspondance variante/XYZ à confirmer |
| `https://www.gamertw.com/fr/zelda/totk/stonetalus` | 87 Lithoroks | vérifier z, région et apparition |
| `https://www.gamertw.com/fr/zelda/totk/hinox` | 69 Hinox/Stalhinox | variations selon profondeur |
| `https://www.gamertw.com/fr/zelda/totk/frox` | 40 Gigatraciens | variantes à distinguer |
| `https://www.gamertw.com/fr/zelda/totk/flux-construct` | 35 Golemax | niveaux I/II/III |
| `https://www.gamertw.com/fr/zelda/totk/gleeok` | 14 Griocks | types et rois, étages |
| `https://www.gamertw.com/fr/zelda/totk/molduga` | 4 Moldarquors | coordonnées et libellé |
| `https://www.gamertw.com/fr/zelda/totk/shrine` | sanctuaires | comparer noms FR/EN et couches |
| `https://www.gamertw.com/fr/zelda/totk/lightroot` | racines | correspondance XYZ |
| `https://www.gamertw.com/fr/zelda/totk/well` | puits | complétude à recouper |
| `https://www.gamertw.com/fr/zelda/totk/tower` | tours | complétude à recouper |
| `https://www.gamertw.com/fr/zelda/totk/dragon-tear` | larmes | numérotation/noms |
| `https://www.puissance-zelda.com/24-Tears-of-the-Kingdom/solution/854-Liste-de-toutes-les-quetes` | noms des quêtes | listes ≠ solutions complètes |
| `https://www.puissance-zelda.com/24-Tears-of-the-Kingdom/solution/…` (73 pages, V7.9) | étapes et récompenses de 252 quêtes | source unique ; texte reformulé (pas de redistribution du texte original) ; lien vers la section exacte sur chaque ligne |
| `https://consolepulse.com/multiplatform/zelda/guides/zelda-totk-korok-seeds-<région>` (V7.4–V7.9) | positions des 900 Korogus | source unique ; seules les données factuelles (ID, graines, XYZ, téléporteur, type) sont reprises |
| `https://zeldacentral.com/games/tears-of-the-kingdom/game-data/drop-tables/` | probabilités de loot (renvoi) | **tableaux non importés** dans les données de V6 |
| `https://api.hyrule-compendium.com/v3/compendium/all?game=2` | catalogue distant | disponibilité, langue et couverture variables |
| `https://www.zeldadungeon.net/tears-of-the-kingdom-interactive-map/` | lien carte externe | ne pas présenter comme carte interne |

## Proposer un champ de traçabilité par enregistrement

```json
{
  "id": "boss_x",
  "name_fr": "...",
  "game": "TOTK",
  "xyz": [0, 0, 0],
  "layer": "Surface",
  "source_url": "https://...",
  "source_checked_at": null,
  "evidence": "répertoire public / confirmation indépendante / test en jeu",
  "verification_status": "imported_unverified"
}
```

## Contrôles nécessaires

- Vérifier séparément langue, coordonnées, signe de `z`, variantes, conditions de rencontre, valeurs de PV et taux de loot.
- Vérifier doublons de coordonnées dans une même catégorie et variantes mal attribuées ; conserver les vrais doublons entre différents étages si approprié.
- Stocker les dates de consultation et traiter les corrections communautaires.
- Respecter les conditions d'utilisation et droits des bases externes ; éviter de copier massivement un site sans autorisation.
- Afficher *inconnu* plutôt que `0 %`, *non vérifié* plutôt que *certain*.

## V7 — sources de recoupement utilisées

Registre complet : `data/v7/sources.json` ; relevés datés : `data/sources/`. Principales : Samurai Gamers (120 racines, coordonnées), ConsolePulse, Gamepur, Game8, ZeldaCentral (racines litigieuses), Zelda Dungeon et Twinfinite (PV des Lynels), GamerTagMythras (PV et effectifs des sous-boss, d’après Zelda Wiki/Thonky), ProGameGuides, Prima Games et Zelda Wiki (bonus d’amalgame), Zelda Wiki *Data:Translations* (noms français). Les sites tiers contiennent aussi des coquilles (voir `docs/AUDIT_V7.md`). Seules les **valeurs factuelles** (nombres, coordonnées) sont reprises, avec lien ; aucun texte n’est copié.
