# Consignes de reprise — Hyrule Codex

## Mission

Reprendre **un projet existant** d'encyclopédie communautaire pour *Zelda: Tears of the Kingdom* nommé Hyrule Codex. L'utilisateur est francophone, joue sur Switch 1 et veut une **PWA iPhone gratuite et exhaustive**, avec mode encyclopédie **spoilers autorisés** et un assistant conversationnel accessible dans ChatGPT. Il déteste les démonstrations inachevées et les coordonnées inventées. Il t'a donné carte blanche : **travaille sans questions de validation sur les décisions non bloquantes**.

## Règles non négociables

1. **Ne jamais inventer** une coordonnée, un taux de loot, un PV, une recette, un nom officiel ni une source. Toute donnée douteuse porte un statut « à vérifier » ou est exclue du contenu certifié.
2. **Ne pas affirmer « complet » avant audit** par catégorie avec critères mesurables. Les compteurs V6 sont des nombres d'enregistrements, PAS un taux de complétude du jeu.
3. Préserver le fonctionnement iPhone, la navigation et les exports de sauvegarde. Clé `localStorage` de la progression : `hyrule_codex_v1` ; cache API : `hyrule_codex_remote_totk_v3`. Si évolution de schéma, proposer migration versionnée.
4. Conserver la gratuité : aucune fonction essentielle derrière un paiement ou un service tiers payant. Pas de clé API privée dans le client.
5. **Tester les modifications** : compilation JavaScript, navigation mobile, filtres, sauvegarde et chargement du contenu. Mentionner ce qui n'a PAS été testé sur un iPhone réel.
6. Utiliser prioritairement les sources fiables et, pour tout gros import, conserver `source_url`, date de collecte, vérification de la précision de XYZ et politique de redistribution des données.
7. Aucun texte prétendant qu'un chat avec Claude/ChatGPT est « intégré » si la PWA ne possède qu'un raccourci ou un générateur de questions. Une vraie intégration nécessite serveur, clé gérée côté serveur et autorisations ; ne pas inventer cette capacité.
8. Conserver au minimum la possibilité de déployer `site/` sur un hébergeur HTTPS et de l’ajouter à l'écran d'accueil iPhone.
9. Répondre en français et **livrer les fichiers effectifs** de chaque étape. Ne pas « travailler en arrière-plan » en le promettant.

## État V7 (à lire en premier)

- `data/` est désormais **branché** : `scripts/build.py` injecte les JSON dans `src/app.js` (14 marqueurs). Ne plus éditer de grandes constantes dans le JS.
- Pipeline unique : `python3 scripts/make_all.py`. Il doit rester vert (55 tests structurels, 78 e2e). Le test e2e exige le paquet Python `playwright` à la même version que le Chromium préinstallé.
- Statuts autorisés : `verifie_multi`, `verifie_source`, `verifie_partiel`, `corrige`, `corrige_a_confirmer`, `conflit`, `importe`, `non_source`. Un statut « vérifié » exige une source **distincte** de la source d’import (GamerTW) ; le test le contrôle.
- Prochaines priorités : butins par variante avec taux sourcés, variantes des 34 Lynels, recoupement des 249 positions de boss, armes et armures complètes avec améliorations, recettes, solutions de quêtes.

## Importer une région de Korogus

1. Ouvrir l’URL de la région (`data/sources/koroks/regions.json`, champ `url`).
2. Créer `data/sources/koroks/<slug>.txt`, une ligne par Korogu : `ID|graines|x,y,z[;x,y,z]|téléporteur|type EN|F ou S`, dans l’ordre de la source.
3. Ajouter toute nouvelle énigme dans `types` (traduction descriptive). Le test exige que lignes et graines égalent le total régional.
   Régions importées : lookout-landing, hyrule-field, lindors-brow, rospro-pass, pikida-stonegrove, thyphlo-ruins, upland-zorana, mount-lanayru, sahasra-slope, great-sky-island.
4. `python3 scripts/make_all.py`.
   Régions restantes (6) : popla-foothills, rabella-wetlands, eldin-canyon, ulri-mountain, gerudo-canyon, gerudo-highlands. Elles exigent un accès réseau à `consolepulse.com` (refusé par le proxy le 11/11/2026 ; aucune position saisie de mémoire).

## Importer les étapes et récompenses d’une quête

1. Ouvrir la page source de la quête (référence française : Puissance-Zelda, URL de la liste dans `data/sources/quests/LISEZMOI.md`).
2. Créer `data/sources/quests/<id>.json` (`<id>` de `data/quests.json`) : `{"id", "collected_at": "AAAA-MM-JJ", "steps": [{"text", "src"}], "rewards": [{"text", "src"}]}`. **Une URL `src` par étape et par récompense.** Champ `note` facultatif.
3. Recopier, ne pas compléter : une étape ou une récompense non lue dans la source n’est pas saisie. Une quête sans fichier reste « à vérifier » (`non_source`).
4. `python3 scripts/make_all.py` : `scripts/build_quests.py` refuse toute ligne sans source https, tout identifiant inconnu et tout champ inattendu ; le registre de vérification passe la quête en `importe`.

## Fichiers essentiels (historique V6)

- `site/index.html` : généré par le build ; **ne jamais le modifier à la main**.
- `src/app.js` + `src/styles.css` + `src/index.template.html` : sources recommandées.
- `scripts/build.py` : assemble les sources en un `site/index.html` autonome.
- `data/*.json` : source unique des données (V7).
- `docs/ETAT_VERIFIE.md`, `docs/ARCHITECTURE.md`, `docs/SOURCES_ET_QUALITE.md`, `docs/PLAN_DE_COMPLETUDE.md`.

## Situation V6 en chiffres

Base statique de 95 fiches de monstres, 30 armes/équipements, 22 armures/ensembles, 87 matériaux, 38 bonus d'amalgame, 8 exemples de recettes, 253 intitulés de quêtes, 640 positions actives (dont 283 positions de boss, 152 sanctuaires, 120 racines). Tous ces nombres proviennent de la lecture des littéraux V6 ; **ne pas les interpréter comme des catégories exhaustives ni comme des valeurs toutes vérifiées sur le terrain**.

## Comment continuer efficacement

1. Ouvrir les docs et lancer un test de référence de la V6.
2. Construire un **rapport d'audit des données** : duplication, source, langue, variante, XYZ, coordonnées hors limites, termes incorrects, données contradictoires. Distinguer « importé » et « indépendamment vérifié ».
3. Prioriser le parcours utilisateur : **matériau recherché → monstres qui le donnent → variantes → probabilités si attestées → positions → meilleur circuit**, avec filtres Surface/Ciel/Profondeurs.
4. Compléter progressivement les données manquantes : 100 % des armes et variantes, armures et améliorations, bestiaire détaillé, butins par variante, cartes sourcées, quêtes avec solutions, recettes et collection Korogu. Dédupliquer et conserver provenance par fiche.
5. Déplacer le modèle de données vers `data/` consommé de façon explicite plutôt que maintenir de grandes constantes monolithiques (garder un build autonome/offline pour iPhone).
6. Ajouter tests de non-régression automatisés, validation schema, accessibilité tactile et sauvegardes versionnées.
7. Fournir à l'utilisateur un ZIP déployable **et** une archive de sources/documentation, puis un bilan exact « ajouté / vérifié / manquant ».

**Le premier besoin utilisateur est un livrable exploitable, pas une démo de plus.**
