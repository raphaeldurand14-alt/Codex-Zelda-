#!/usr/bin/env python3
"""Tests structurels des données (sans navigateur). Lancer : python3 tests/verify_project.py
Contrôle comptages, identifiants, schéma, cohérence couche/altitude et registre V7.
Ne certifie PAS l'exactitude des faits de jeu."""
from pathlib import Path
import json, collections, re, sys
r = Path(__file__).resolve().parents[1]; D = r / 'data'
load = lambda s: json.loads((D / s).read_text(encoding='utf-8'))
fails = []
def check(name, cond, detail=''):
    print(('PASS ' if cond else 'FAIL ') + name + (f' — {detail}' if detail else '')); cond or fails.append(name)

geo = []
for f in ['shrines.json', 'lightroots.json', 'lynels.json', 'wells.json', 'towers.json', 'dragon_tears.json']:
    for x in load(f): geo.append({**x, 'x': x['xyz'][0], 'y': x['xyz'][1], 'z': x['xyz'][2]})
geo += load('boss_locations_v6.json')
check('640 positions actives', len(geo) == 640, str(len(geo)))
check('identifiants uniques', len({x['id'] for x in geo}) == len(geo))
check('XYZ entiers', all(all(isinstance(x[k], int) for k in 'xyz') for x in geo))
check('X/Y dans la carte', all(abs(x['x']) <= 6000 and abs(x['y']) <= 5000 for x in geo))
check('Profondeurs ⇒ Z < 0', all(x['z'] < 0 for x in geo if x['layer'] == 'Profondeurs'))
check('couches valides', all(x['layer'] in ('Surface', 'Ciel', 'Profondeurs') for x in geo))
c = collections.Counter(x['type'] for x in geo)
for t, n in {'Sanctuaire': 152, 'Racine': 120, 'Lynel': 34, 'Puits': 58, 'Tour': 15, 'Larme du dragon': 12, 'Hinox': 69, 'Lithorok': 87,
             'Gigatracien': 40, 'Golemax': 35, 'Griock': 14, 'Moldarquor': 4}.items():
    check(f'{t} = {n}', c[t] == n, str(c[t]))
db = load('db_export.json')
ids = {m['id'] for m in db['monsters']}
check('bestiaire = 96 fiches', len(ids) == 96)
check('bestiary.json synchronisé avec db_export', load('bestiary.json') == db['monsters'])
check('sources des matériaux existantes', all(s in ids for m in db['materials'] for s in m['sources']))
check('schéma monstre', all({'id', 'name', 'type', 'hp', 'tier', 'area', 'loot', 'weak', 'tip', 'icon', 'farm'} <= set(m) for m in db['monsters']))
check('253 quêtes', len(load('quests.json')) == 253)
check('pas de racine au nom corrompu', not any('autcnas' in x['name'] for x in load('lightroots.json')))
V = load('v7/verification.json')
allowed = {'verifie_multi', 'verifie_source', 'verifie_partiel', 'corrige', 'corrige_a_confirmer', 'conflit', 'importe', 'non_source'}
check('statuts V7 valides', all(v['s'] in allowed for v in V.values()))
check('chaque position a un statut V7', all((('shrines:' if x['id'].startswith('shrine_') else 'lightroots:' if x['id'].startswith('root_') else 'atlas:') + x['id']) in V for x in geo))
check('chaque monstre a un statut V7', all('bestiary:' + i in V for i in ids))
check('tout « vérifié » cite une source', all(v.get('src') for v in V.values() if v['s'].startswith('verifie')))
same = set(load('v7/sources.json')['same_origin_as_v6'])
reg = load('v7/sources.json')['registry']
check('aucun « vérifié » ne repose sur la source d’import seule', all(any(u not in {reg[k] for k in same} for u in v['src']) for v in V.values() if v['s'].startswith('verifie')))
corr = load('v7/corrections.json')
check('corrections journalisées avec justification', corr and all(c['why'] and 'old' in c and 'new' in c for c in corr))
E = load('v7/encyclo.json')
A = E['armor']
check('135 pièces d’armure', len(A['pieces']) == 135)
check('103 pièces améliorables', sum(1 for p in A['pieces'] if p['recipe']) == 103)
check('recettes d’amélioration existantes', all(p['recipe'] in A['recipes'] for p in A['pieces'] if p['recipe']))
check('DEF max = DEF du palier ★4', all(A['recipes'][p['recipe']][3]['def'] == p['max'] for p in A['pieces'] if p['recipe']))
check('DEF croissante par palier', all(all(t[i]['def'] < t[i + 1]['def'] for i in range(3)) for t in A['recipes'].values()))
check('XYZ armures entiers', all(len(p['xyz']) == 3 and all(isinstance(v, int) for v in p['xyz']) for p in A['pieces']))
W = E['weapons']['items']
check('174 équipements, numéros 329–503 sans doublon', len(W) == 174 and len({w['no'] for w in W}) == 174 and set(range(329, 504)) - {w['no'] for w in W} == {440})
R = E['recipes']['items']
check('228 recettes numérotées 1–228', [x['no'] for x in R] == list(range(1, 229)))
check('ennemis sourcés reliés à des fiches existantes', all(e['v6_id'] in ids for e in E['enemies']['items'] if e['v6_id']))
check('chaque bloc encyclopédique cite sa source', all(E[k].get('source_url', '').startswith('https://') for k in ('armor', 'weapons', 'enemies', 'recipes')))
Cv = E['caves']['items']
check('147 grottes, 197 entrées', len(Cv) == 147 and sum(len(c['entrances']) for c in Cv) == 197)
check('4 grottes célestes', sum(1 for c in Cv if c['layer'] == 'Ciel') == 4)
check('34 Lynels appariés à une variante', len(E['lynels']['by_id']) == 34 and set(E['lynels']['by_id']) == {x['id'] for x in load('lynels.json')})
check('20 vœux des Sages au ciel (Z > 400)', len(E['sages']['items']) == 20 and all(w['xyz'][2] > 400 for w in E['sages']['items']))
check('81 panneaux de Boulieh en surface', len(E['addison']['items']) == 81 and all(-100 < a['xyz'][2] < 1400 for a in E['addison']['items']))
K = E['koroks']
check('Korogus : 16 régions = 900 rencontres / 1 000 graines', len(K['regions']) == 16 and sum(x['encounters'] for x in K['regions']) == 900 and sum(x['seeds'] for x in K['regions']) == 1000)
check('Korogus importés cohérents avec les totaux régionaux', all(sum(1 for k in K['items'] if k['region'] == r['name']) in (0, r['encounters']) for r in K['regions']))
check('Korogus : graines des régions importées', all(sum(k['seeds'] for k in K['items'] if k['region'] == r['name']) == r['seeds'] for r in K['regions'] if r['imported']))
QD = load('v7/quest_details.json')
qids = {q['id'] for q in load('quests.json')}
check('détails de quêtes rattachés à des quêtes existantes', set(QD['items']) <= qids and QD['total'] == len(qids))
check('chaque étape/récompense de quête cite une source https', all(e['src'].startswith('https://') and e['text'].strip() for d in QD['items'].values() for k in ('steps', 'rewards') for e in d[k]))
check('chaque quête a un statut V7', all('quests:' + i in V for i in qids))
check('quête sans source ⇒ « à vérifier » (non_source)', all(V['quests:' + i]['s'] == 'non_source' for i in qids - set(QD['items'])))
check('quête sourcée ⇒ sources du registre = sources des lignes', all(sorted({e['src'] for k in ('steps', 'rewards') for e in d[k]}) == V['quests:' + i].get('src') for i, d in QD['items'].items()))
js = (r / 'src' / 'app.js').read_text(encoding='utf-8')
check('14 marqueurs de données dans app.js', len(re.findall(r'/\*@data:[a-z0-9_]+\*/null', js)) == 14)
check('pas d’affirmation « VERIFIED » résiduelle', 'VERIFIED' not in js)
print(f'\n{"ÉCHEC" if fails else "OK"} — tests structurels (comptages, schéma, cohérence), PAS une certification des faits de jeu')
sys.exit(1 if fails else 0)
