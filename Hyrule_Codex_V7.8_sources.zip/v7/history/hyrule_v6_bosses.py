"""Independent index of the XYZ boss location facts visibly listed on GamerTW
and reviewed 2026-11-11. These coordinates are attributed in-app.
"""
from collections import Counter
BOSS_SOURCES={
'Moldarquor':'https://www.gamertw.com/fr/zelda/totk/molduga',
'Griock':'https://www.gamertw.com/fr/zelda/totk/gleeok',
'Hinox':'https://www.gamertw.com/fr/zelda/totk/hinox',
'Gigatracien':'https://www.gamertw.com/fr/zelda/totk/frox',
'Golemax':'https://www.gamertw.com/fr/zelda/totk/flux-construct',
'Lithorok':'https://www.gamertw.com/fr/zelda/totk/stonetalus'
}
# Format: 'layer abbreviation|variant|x,y,z'. Negative z = depths in these pages.
RAW='''
S|Moldarquor|-4797,-2800,0040
S|Moldarquor|-4029,-2589,0055
S|Moldarquor|-3323,-3316,0028
S|Moldarquor|-2401,-3268,0034
S|Griock des glaces|-3743,2992,0402
S|Griock des glaces|-4024,-0956,0708
S|Griock des glaces|-1835,3009,0256
S|Griock des flammes|-3625,0420,0268
S|Griock des flammes|-2115,-2640,0407
S|Griock des flammes|-0047,-2491,0051
S|Griock des flammes|2239,0694,0793
S|Griock électrique|-1150,-1263,0058
S|Griock électrique|1059,-3614,0089
S|Griock électrique|3423,1298,0344
C|Roi griock|-4471,2275,1274
C|Roi griock|-4448,-2627,1437
C|Roi griock|4652,-3724,1089
P|Roi griock|0334,3122,-0547
S|Hinox|-2825,2433,0409
S|Hinox|-2736,1334,0169
S|Hinox|-2221,0759,0113
S|Hinox|-1246,2109,0116
S|Hinox|-1080,0462,0047
S|Hinox|-0407,2011,0186
S|Hinox|-0742,1263,0092
S|Hinox|0693,-1081,0023
S|Hinox|1305,0910,0039
S|Hinox|1470,-1330,0109
S|Hinox|2051,-2004,0032
S|Hinox|1879,-2948,-0027
S|Hinox|-2275,-0723,0116
S|Hinox bleu|-3655,3806,0238
S|Hinox bleu|-2014,-1200,0112
S|Hinox bleu|-0807,-3019,0129
S|Hinox bleu|1273,-2175,0258
S|Hinox bleu|3401,0271,0256
S|Hinox bleu|3160,-2596,0116
S|Hinox bleu|4435,0740,0122
S|Hinox bleu|1652,-2911,0165
S|Hinox noir|-4205,-1292,0433
S|Hinox noir|0840,3363,0207
S|Hinox noir|1562,-2416,0201
S|Hinox noir|1098,-2872,0079
S|Hinox noir|1687,-3873,0015
S|Hinox noir|4643,1778,0042
S|Hinox noir|4603,3530,-0052
S|Hinox noir|2025,-3061,0106
S|Hinox noir|-0154,1064,0223
S|Stalhinox|-3794,1557,0150
S|Stalhinox|-1177,-0115,0046
S|Stalhinox|0780,-1954,0026
S|Stalhinox|2142,3011,0435
S|Stalhinox|2414,-1167,0207
S|Stalhinox|2771,-2713,0162
S|Stalhinox|3435,3327,-0124
S|Stalhinox|-0322,0458,-0024
S|Stalhinox|-2058,1559,-0057
S|Stalhinox|1434,-0137,-0001
P|Hinox|-1070,-0821,-0458
P|Hinox|-1439,-2366,-0535
P|Hinox|0046,-1335,-0446
P|Hinox|0366,-0007,-0456
P|Hinox bleu|-4325,-3465,-0457
P|Hinox bleu|-2736,1334,-0586
P|Hinox bleu|1305,0910,-0459
P|Hinox bleu|1562,-2416,-0617
P|Hinox bleu|1098,-2872,-0495
P|Hinox bleu|1213,-2672,-0571
P|Hinox bleu|1652,-2911,-0683
P|Hinox noir|-4205,-1292,-0844
P|Hinox noir|-3655,3806,-0654
P|Hinox noir|-2783,2031,-0732
P|Hinox noir|-0146,2382,-0598
P|Hinox noir|1470,-1330,-0528
P|Hinox noir|1687,-3873,-0436
P|Hinox noir|2051,-2004,-0452
P|Hinox noir|4643,1778,-0462
P|Stalhinox|-3793,1557,-0568
P|Stalhinox|-3571,-3555,-0448
P|Stalhinox|-1093,0047,-0465
P|Stalhinox|-1177,-0115,-0466
P|Stalhinox|0913,2908,-0653
P|Stalhinox|0779,-1956,-0446
P|Stalhinox|2138,3008,-0846
P|Stalhinox|2244,-1134,-0656
P|Stalhinox|2875,-2405,-0548
P|Stalhinox|3257,3445,-0411
P|Gigatracien|-3428,-3229,-0447
P|Gigatracien|-2253,-1975,-0561
P|Gigatracien|-2771,-3330,-0421
P|Gigatracien|-2439,-3123,-0454
P|Gigatracien|-1910,-2608,-0566
P|Gigatracien|-0572,0223,-0444
P|Gigatracien|-0293,-1814,-0441
P|Gigatracien|-0794,-1089,-0449
P|Gigatracien|-0846,-2868,-0494
P|Gigatracien|-0325,-3142,-0445
P|Gigatracien|0177,-0863,-0456
P|Gigatracien|2119,1750,-0728
P|Gigatracien anthracite|-4094,-2555,-0470
P|Gigatracien anthracite|-4674,-3502,-0447
P|Gigatracien anthracite|-2249,0451,-0527
P|Gigatracien anthracite|-2998,-2680,-0442
P|Gigatracien anthracite|-0960,2852,-0596
P|Gigatracien anthracite|-1340,0973,-0519
P|Gigatracien anthracite|-1619,-0395,-0478
P|Gigatracien anthracite|-0190,2938,-0593
P|Gigatracien anthracite|-0875,1742,-0523
P|Gigatracien anthracite|0552,3440,-0569
P|Gigatracien anthracite|0845,-3388,-0454
P|Gigatracien anthracite|2491,0842,-0479
P|Gigatracien anthracite|3036,-0798,-0491
P|Gigatracien anthracite|4028,2188,-0449
P|Gigatracien anthracite|4142,1002,-0661
P|Gigatracien opalin|-4398,2661,-0643
P|Gigatracien opalin|-4696,-1228,-0910
P|Gigatracien opalin|-3191,2671,-0860
P|Gigatracien opalin|-3719,1003,-0529
P|Gigatracien opalin|-3891,0560,-0551
P|Gigatracien opalin|-3628,-1549,-0778
P|Gigatracien opalin|-2280,1934,-0687
P|Gigatracien opalin|-1780,3658,-0653
P|Gigatracien opalin|-1839,2413,-0652
P|Gigatracien opalin|-0764,0833,-0444
P|Gigatracien opalin|0204,0890,-0452
P|Gigatracien opalin|1069,-0041,-0445
P|Gigatracien opalin|2127,-3474,-0427
C|Golemax|-3472,3519,0926
C|Golemax|0442,2468,1645
C|Golemax|-3834,2721,0547
C|Golemax|0492,-1516,1426
C|Golemax amélioré|3386,0633,1280
C|Golemax amélioré|3674,1809,0984
C|Golemax amélioré|-1344,-1548,0800
C|Golemax amélioré|3000,-0252,0891
C|Golemax ultime|1133,-3273,0756
C|Golemax ultime|3301,3434,0793
C|Golemax ultime|3044,-2777,1192
C|Golemax ultime|2559,-3601,0891
C|Golemax ultime|-2290,-0412,0891
C|Golemax ultime|-0326,-2591,0891
C|Golemax ultime|-3450,0658,1421
P|Golemax|-2182,-1503,-0662
P|Golemax|0717,-0644,-0437
P|Golemax|0101,-3714,-0432
P|Golemax amélioré|-4147,-2961,-0464
P|Golemax amélioré|-0723,1263,-0493
P|Golemax amélioré|0225,3674,-0490
P|Golemax amélioré|2680,3473,-0654
P|Golemax amélioré|2639,-0937,-0633
P|Golemax amélioré|2512,-1272,-0622
P|Golemax amélioré|3701,2906,-0451
P|Golemax amélioré|3198,1020,-0816
P|Golemax amélioré|3527,-1340,-0582
P|Golemax ultime|-4413,2240,-0524
P|Golemax ultime|-4086,-0953,-1079
P|Golemax ultime|-2620,1705,-0663
P|Golemax ultime|0870,0678,-0517
P|Golemax ultime|3263,-3703,-0426
P|Golemax ultime|-1795,-3463,-0501
P|Golemax ultime|-0815,3534,-0658
P|Golemax ultime|4655,3697,-0426
S|Lithorok|-3387,1076,0209
S|Lithorok|-3298,0649,0198
S|Lithorok|0098,2370,0185
S|Lithorok|4063,2973,0160
S|Lithorok rare|-3491,0171,-0091
S|Lithorok rare|-2306,-2453,0363
S|Lithorok rare|-0394,2956,0157
S|Lithorok rare|0524,-3710,0070
S|Lithorok rare|1019,-3383,0035
S|Lithorok rare|1826,-3495,0039
S|Lithorok rare|4678,2998,0015
S|Lithorok rare|-2600,-1782,0187
S|Lithorok nox|-2860,-0521,0024
S|Lithorok nox|-2221,-0585,0275
S|Lithorok nox|0703,3692,0105
S|Lithorok nox|2710,3303,0248
S|Lithorok nox|2483,0908,0077
S|Lithorok nox|3029,-1778,0019
S|Lithorok nox|3195,-2958,0077
S|Lithorok nox|4191,0518,0357
S|Lithorok nox|4141,0543,0194
S|Lithorok nox|0575,0766,0021
S|Lithorok nox|3628,0274,-0089
S|Lithorok nox|1483,-0975,0022
S|Lithorok nox|0340,-1984,-0031
S|Lithorok fortifié|-4393,1935,0122
S|Lithorok fortifié|-3987,-1703,0317
S|Lithorok fortifié|-3109,1287,0166
S|Lithorok fortifié|-2550,-0111,0138
S|Lithorok fortifié|-1448,1026,0147
S|Lithorok fortifié|-1364,-0789,0022
S|Lithorok fortifié|-1092,-1659,0085
S|Lithorok fortifié|-0770,0811,0058
S|Lithorok fortifié|-0109,-0802,0047
S|Lithorok fortifié|0677,0506,0041
S|Lithorok fortifié|0202,0531,0040
S|Lithorok fortifié|0770,-1223,0036
S|Lithorok fortifié|0587,-1934,0076
S|Lithorok fortifié|1256,-1165,0119
S|Lithorok fortifié|2974,1488,0292
S|Lithorok fortifié|3951,1189,0251
S|Lithorok fortifié|3277,-3408,0039
S|Lithorok fortifié|4181,2228,0027
S|Cryorok|-4433,3387,0293
S|Cryorok|-4500,2450,0123
S|Cryorok|-4321,-1203,0393
S|Cryorok|-2685,3353,0249
S|Cryorok|-2833,-1326,0555
S|Cryorok|4057,-1056,0318
S|Magrok|1944,3194,0427
S|Magrok|1291,1717,0262
S|Magrok|2479,3637,0332
S|Magrok|2015,2398,0463
S|Magrok|2215,1780,0322
S|Magrok|2630,2745,0533
P|Lithorok|-4010,-1696,-0729
P|Lithorok|-3531,-2443,-0464
P|Lithorok|-0460,-1005,-0467
P|Lithorok|-0826,-3350,-0516
P|Lithorok|-0004,-0012,-0451
P|Lithorok rare|-4433,3387,-0708
P|Lithorok rare|-4500,2450,-0541
P|Lithorok rare|-3387,1076,-0625
P|Lithorok rare|-2635,1492,-0391
P|Lithorok rare|0697,0513,-0462
P|Lithorok rare|1483,-0975,-0576
P|Lithorok nox|-2221,-0585,-0690
P|Lithorok nox|-0394,2956,-0575
P|Lithorok nox|0951,3673,-0533
P|Lithorok nox|1056,-3417,-0457
P|Lithorok nox|2479,3637,-0746
P|Lithorok nox|3029,-1779,-0440
P|Lithorok nox|4678,2998,-0435
P|Lithorok nox|4191,0518,-0770
P|Lithorok nox|4057,-1056,-0733
P|Lithorok fortifié|-4393,1935,-0540
P|Lithorok fortifié|-3108,1288,-0583
P|Lithorok fortifié|-2527,-0107,-0554
P|Lithorok fortifié|-0109,-0802,-0467
P|Lithorok fortifié|2985,1449,-0705
P|Lithorok fortifié|3277,-3408,-0460
P|Cryorok|-4723,-0391,-1054
P|Cryorok|-3629,2196,-0569
P|Cryorok|2642,-1943,-0507
P|Magrok|1454,3175,-0811
P|Magrok|1672,1610,-0701
P|Magrok|2913,2556,-0933
'''

def build():
 out=[]; by_family=Counter(); ident=Counter(); seen=set()
 for line in RAW.strip().splitlines():
  layer,variant,coords=line.strip().split('|')
  family=('Moldarquor' if variant.startswith('Moldarquor') else 'Griock' if 'griock' in variant.lower() else 'Hinox' if 'hinox' in variant.lower() else 'Gigatracien' if 'Gigatracien' in variant else 'Golemax' if 'Golemax' in variant else 'Lithorok')
  if variant in ('Cryorok','Magrok'):family='Lithorok'
  xyz=[int(v) for v in coords.split(',')]
  ident[family]+=1
  layer_name={'S':'Surface','P':'Profondeurs','C':'Ciel'}[layer]
  key=(family,layer_name,tuple(xyz));assert key not in seen,key;seen.add(key)
  out.append({'id':'boss_'+family.lower()+'_'+str(ident[family]).zfill(3),'type':family,'variant':variant,'layer':layer_name,'name':variant+' · '+layer_name+' #'+str(ident[family]),'x':xyz[0],'y':xyz[1],'z':xyz[2],'place':'Rencontre de '+variant+' · '+layer_name,'source':BOSS_SOURCES[family],'tip':'Coordonnées reprises du répertoire GamerTW ; vérifie la variante en jeu, qui peut changer avec la progression.'})
  by_family[family]+=1
 assert by_family=={'Lithorok':87,'Hinox':69,'Gigatracien':40,'Golemax':35,'Griock':14,'Moldarquor':4},by_family
 assert len(out)==249,len(out)
 return out
if __name__=='__main__':print(len(build()),Counter(x['type'] for x in build()))
