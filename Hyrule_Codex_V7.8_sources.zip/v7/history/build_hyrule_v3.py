import json, re, zipfile, shutil
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
p=Path('/mnt/data/hyrule_codex_v3');p.mkdir(exist_ok=True)
s=Path('/mnt/data/hyrule_codex_v2/index.html').read_text(encoding='utf-8')
m=re.search(r'const DB=(\{.*?\});\nconst navs=',s,re.S)
assert m
DB=json.loads(m.group(1)); IDS={a['id'] for a in DB['monsters']}
def mon(id,name,cat,hp,area,loot,weak,tip='Butins soumis aux conditions et variantes du monstre.',tier='Intermédiaire',icon='👹'):
 if id not in IDS:
  DB['monsters'].append(dict(id=id,name=name,type=cat,hp=hp,area=area,loot=loot,weak=weak,tip=tip,tier=tier,icon=icon,farm=' / '.join(loot[:2]))); IDS.add(id)
mon('lizalfos_bleu','Lézalfos bleu','Lézalfos',110,'Zones humides et camps',['Corne de Lézalfos bleu','Griffe de Lézalfos','Queue de Lézalfos bleu'],'Vise la tête avec une flèche.','La queue est un butin aléatoire.',icon='🦎')
mon('lizalfos_noir','Lézalfos noir','Lézalfos',288,'Zones avancées, surface et Profondeurs',['Corne de Lézalfos noir','Griffe de Lézalfos','Queue de Lézalfos noir'],'Esquive ses bonds rapides.',icon='🦎')
mon('lizalfos_argent','Lézalfos d’argent','Lézalfos',864,'Zones de niveau avancé',['Corne de Lézalfos d’argent','Griffe de Lézalfos','Queue de Lézalfos d’argent'],'Combats-le isolément ; méfie-toi de sa mobilité.',tier='Difficile',icon='🦎')
mon('boko_chef_bleu','Bokoblin chef bleu','Bokoblins',400,'Camps évolués de surface',['Corne de Bokoblin chef bleu','Croc de Bokoblin chef','Viscère de Bokoblin chef'],'Élimine d’abord les Bokoblins autour.',icon='👑')
mon('boko_chef_noir','Bokoblin chef noir','Bokoblins',750,'Camps évolués',['Corne de Bokoblin chef noir','Croc de Bokoblin chef','Viscère de Bokoblin chef'],'Affronte-le à distance pour éviter sa zone d’attaque.',tier='Difficile',icon='👑')
mon('boko_chef_argent','Bokoblin chef d’argent','Bokoblins',1200,'Camps de fin de progression',['Corne de Bokoblin chef d’argent','Croc de Bokoblin chef','Viscère de Bokoblin chef'],'Débarrasse-toi de son groupe avant le duel.',tier='Difficile',icon='👑')
mon('golem_capitaine_2','Golem capitaine II','Golems soneaus',200,'Îles célestes et sanctuaires',['Corne de Golem capitaine II'],'Désarme-le avec Emprise ou une parade.',icon='🤖')
mon('golem_capitaine_3','Golem capitaine III','Golems soneaus',380,'Îles célestes et lieux soneaus',['Corne de Golem capitaine III'],'Attention à ses armes amalgamées.',icon='🤖')
mon('golem_capitaine_4','Golem capitaine IV','Golems soneaus',1200,'Lieux soneaus avancés',['Corne de Golem capitaine IV'],'Utilise de bons boucliers et l’esquive parfaite.',tier='Difficile',icon='🤖')
mon('golem_soldat_2','Golem soldat II','Golems soneaus',None,'Ruines soneaus, ciel',['Corne de Golem soldat II'],'Évite ses attaques télégraphiées.',icon='🤖')
mon('golem_soldat_3','Golem soldat III','Golems soneaus',None,'Ruines soneaus, ciel',['Corne de Golem soldat III'],'Contre-attaque après sa série de coups.',icon='🤖')
mon('golem_soldat_4','Golem soldat IV','Golems soneaus',None,'Lieux soneaus avancés',['Corne de Golem soldat IV'],'Utilise le terrain pour interrompre ses attaques.',tier='Difficile',icon='🤖')
mon('chauve_souris','Chauve-souris','Ennemis',1,'Grottes, ruines et nuit',['Aile de chauve-souris','Œil de chauve-souris'],'Tire un projectile sur l’essaim.',tier='Accessible',icon='🦇')
mon('chauve_souris_feu','Chauve-souris de feu','Ennemis',1,'Ordinn, grottes chaudes',['Aile de chauve-souris de feu','Œil de chauve-souris de feu'],'Évite le contact et utilise une flèche.',tier='Accessible',icon='🔥')
mon('chauve_souris_glace','Chauve-souris de glace','Ennemis',1,'Hébra et zones froides',['Aile de chauve-souris de glace','Œil de chauve-souris de glace'],'Privilégie le feu pour la vaincre.',tier='Accessible',icon='❄️')
mon('chauve_souris_elec','Chauve-souris électrique','Ennemis',1,'Gerudo, zones orageuses',['Aile de chauve-souris électrique','Œil de chauve-souris électrique'],'Tire à distance pour éviter le choc.',tier='Accessible',icon='⚡')
mon('aerocuda','Aérocuda','Ennemis',None,'Ciel et camps de la surface',['Aile d’Aérocuda','Œil d’Aérocuda'],'Vise les ailes avec une flèche.',tier='Accessible',icon='🪽')
mon('yiga','Soldat Yiga','Ennemis',None,'Campements Yiga et routes',['Bananes lame','Roupies','Armes Yiga'],'Anticipe la téléportation avant de contre-attaquer.',icon='🥷')
mon('chuchu','Chuchu','Ennemis',None,'Forêts et plaines',['Gelée chuchu'],'Les gelées élémentaires servent aux flèches.',tier='Accessible',icon='💧')
mon('wizrobe_feu','Sorcier de feu','Ennemis',None,'Surface, zones chaudes',['Arme élémentaire (équipement tenu)'],'Une attaque de glace peut le neutraliser.',icon='🧙')
mon('wizrobe_glace','Sorcier de glace','Ennemis',None,'Surface, zones froides',['Arme élémentaire (équipement tenu)'],'Une attaque de feu est très efficace.',icon='🧙')
mon('wizrobe_elec','Sorcier électrique','Ennemis',None,'Surface, régions diverses',['Arme élémentaire (équipement tenu)'],'Garde tes distances pendant ses décharges.',icon='🧙')
# Data in version 2 contains some loose, partly inaccurate drop lists: preserve for compatibility, but disclose selection and uncertainty.
for x in DB['monsters']:
 if x['id']=='stalinox': x['hp']=1000
# Add items that are actually farmed; use the established bestiary relationships.
materials_seen={x['name'] for x in DB['materials']}
def mat(name,use,ids,icon='💎'):
 if name not in materials_seen:
  DB['materials'].append(dict(name=name,use=use,sources=[v for v in ids if v in IDS],icon=icon));materials_seen.add(name)
for name,use,source,icon in [
 ('Corne de Lézalfos d’argent','Amalgame : +34 dégâts (valeur de fusion).',['lizalfos_argent'],'⚔️'),
 ('Corne de Golem capitaine IV','Amalgame : +35 dégâts.',['golem_capitaine_4'],'🤖'),
 ('Corne de Bokoblin chef d’argent','Amalgame : +37 dégâts.',['boko_chef_argent'],'👑'),
 ('Corne de Lézalfos noir','Pour renforcer une arme et certaines tenues.',['lizalfos_noir'],'⚔️'),
 ('Corne de Bokoblin chef noir','Fusion et amélioration d’armure.',['boko_chef_noir'],'👑'),
 ('Corne de Lézalfos bleu','Fusion et amélioration.',['lizalfos_bleu'],'⚔️'),
 ('Œil de chauve-souris','Permet des flèches à tête chercheuse.',['chauve_souris'],'👁️'),
 ('Œil de chauve-souris de feu','Guidage des flèches avec propriété élémentaire.',['chauve_souris_feu'],'🔥'),
 ('Œil de chauve-souris de glace','Guidage des flèches avec propriété élémentaire.',['chauve_souris_glace'],'❄️'),
 ('Œil de chauve-souris électrique','Guidage des flèches avec propriété élémentaire.',['chauve_souris_elec'],'⚡'),
 ('Aile d’Aérocuda','Augmente la portée des tirs de flèches.',['aerocuda'],'🪽'),
 ('Gelée chuchu','Peut devenir élémentaire au contact du feu, de la glace ou de l’électricité.',['chuchu'],'💧'),
 ('Corne de Golem soldat IV','Matériau d’amalgame soneau.',['golem_soldat_4'],'🤖'),
 ('Os de Gibdo','Amalgame puissant (+40), se casse rapidement.',['gibdo'],'🦴'),
 ('Corne de Lynel blanc','Amalgame haut de gamme ; choisir la corne tranchante.',['lynel_blanc'],'⚔️'),
 ('Viscère d’Horriblin','Amélioration d’armures et élixirs.',['horroblin','horroblin_bleu','horroblin_noir'],'🧪'),
 ('Corne de Golem capitaine III','Amalgame +25 ; donjons et îles soneaus.',['golem_capitaine_3'],'🤖'),
 ('Queue de Lézalfos d’argent','Matériau rare de fusion et d’amélioration.',['lizalfos_argent'],'🦎'),
]:mat(name,use,source,icon)
# Extra commonly searched equipment (unknown stats deliberately not fabricated).
WIDS={x['id'] for x in DB['weapons']}
def weapon(id,name,kind,area,how,trait='La puissance dépend de l’état et de l’amalgame.',power='Variable',icon='⚔️'):
 if id not in WIDS:
  DB['weapons'].append(dict(id=id,name=name,kind=kind,area=area,how=how,trait=trait,power=power,icon=icon));WIDS.add(id)
for item in [
 ('trident_ecaille','Trident d’écailles radieuses','Lance','Domaine Zora','Achever la quête de fabrication du forgeron Zora.', 'Bonus de dégâts quand Link est mouillé.','22','🔱'),
 ('brise_montagne','Brise-montagne','Deux mains','Cité Goron','Forger à la Cité Goron après la quête principale des Gorons.','Arme de champion Goron, pratique contre les roches.','38','🪓'),
 ('arc_aigle','Arc de l’Aigle','Arc','Village Piaf','Faire fabriquer l’arc après la quête principale des Piafs.','Trois flèches pour une seule consommée.','28','🏹'),
 ('epee_garde_royale_2m','Espadon de garde royal','Deux mains','Château d’Hyrule','Explorer le château et les ombres des Profondeurs.','Gros bonus lorsque l’arme menace de se briser.','Variable','🗡️'),
 ('arc_garde_royale','Arc de garde royal','Arc','Château d’Hyrule','Explorer le château.','Puissant, mais fragile.','50','🏹'),
 ('arc_crepuscule','Arc du crépuscule','Arc','Château d’Hyrule','Sur le point culminant du château, puis conditions de réapparition.','Flèches à longue portée.','30','🏹'),
 ('arc_gerudo','Arc gerudo','Arc','Désert Gerudo','Coffres et ennemis du désert.','Permet de viser loin.','25','🏹'),
 ('lance_garde_royale','Lance de garde royal','Lance','Château d’Hyrule','Explorer les zones d’armes du château.','Puissance accrue juste avant rupture.','Variable','🔱'),
 ('bouclier_royal','Bouclier royal','Bouclier','Château et ennemis avancés','Coffres et monstres équipés.','Bonne protection.','Variable','🛡️'),
 ('baguette_magique','Baguette magique','Sceptre','Coffres et ennemis sorciers','Chercher les ennemis sorciers ou des coffres de ruines.','Utile avec gemmes élémentaires.','Variable','🪄'),
]:weapon(*item)
AIDS={x['id'] for x in DB['armors']}
for item in [
 ('hylien','Ensemble Hylien','Défense simple, facile à améliorer','Fort de guet','Acheter au Fort de guet.','🧥'),
 ('soldat','Ensemble de soldat','Bonne défense','Passages secrets de la capitale','Explorer les galeries sous le Fort de guet.','🛡️'),
 ('soneau','Ensemble soneau','Économie de batterie soneau','Îles célestes','Explorer les casse-têtes des îles célestes.','🔋'),
 ('foudre','Casque de foudre','Protège de la foudre','Repaire Yiga','Réussir les épreuves Yiga.','⚡'),
 ('fougue','Ensemble du héros du ciel','Tenue d’hommage / bonus d’ensemble','Profondeurs','Trouver les pièces dans les coffres des Profondeurs.','🌤️'),
 ('chauffer','Ensemble désert','Résistance à la chaleur','Désert Gerudo et commerces','Acheter les pièces dans les boutiques de la région Gerudo.','🏜️'),
]:
 if item[0] not in AIDS:DB['armors'].append(dict(zip(['id','name','bonus','area','how','icon'],item)));AIDS.add(item[0])
s=s[:m.start()]+'const DB='+json.dumps(DB,ensure_ascii=False,separators=(',',':'))+';\nconst navs='+s[m.end():]
# Atlas: exact 3D coordinates, independent of the game map projection. labels are adapted/translated.
points=[]
def pin(type_,layer,name,coord,place,source,tip=''):
 x,y,z=map(int,coord.split(','));points.append({'id':'a'+str(len(points)+1),'type':type_,'layer':layer,'name':name,'x':x,'y':y,'z':z,'place':place,'source':source,'tip':tip})
LY='https://www.thonky.com/zelda-tears-of-the-kingdom/list-of-lynel-locations'
GL='https://www.thonky.com/zelda-tears-of-the-kingdom/list-of-gleeok-locations'
MO='https://www.thonky.com/zelda-tears-of-the-kingdom/list-of-molduga-locations'
OT='https://www.thonky.com/zelda-tears-of-the-kingdom/list-of-monster-locations'
DR='https://www.thonky.com/zelda-tears-of-the-kingdom/list-of-geoglyph-locations'
for t,layer,name,coord,place in [
 ('Lynel','Surface','Lynel rouge · crête de Lindor','-2160,1528,0217','Au nord-ouest de la tour de Lindor'),
 ('Lynel','Surface','Lynel rouge · pont de Tabanta','-3373,0021,0093','Au sud-ouest du relais du pont de Tabanta'),
 ('Lynel','Surface','Lynel rouge · village Piaf','-2804,1841,0307','Collines à l’est du village Piaf'),
 ('Lynel','Surface','Lynel rouge · relais de Delass','-1581,0161,0109','Au sud du relais de Delass'),
 ('Lynel','Surface','Lynel rouge · Akkala est','3672,2963,0031','Au nord-ouest du relais d’Akkala est'),
 ('Lynel','Profondeurs','Lynel rouge · sous le relais des abords','-1440,-1271,-0485','Près de la racine Mu-ustust'),
 ('Lynel','Profondeurs','Lynel rouge · plaines centrales','0242,-1178,-0471','Au sud-ouest de la racine Stakijat'),
 ('Lynel','Surface','Lynel bleu · Hauteurs d’Hébra','-4542,2680,0228','Ouest de la tour du col de Rospro'),
 ('Lynel','Surface','Lynel bleu · marécages de Lanelle','1990,-0300,0009','Au sud-est du sanctuaire Jonsau'),
 ('Lynel','Surface','Lynel bleu · nord Cocorico','2489,-0532,0113','À l’est du sanctuaire Kurakat'),
 ('Lynel','Surface','Lynel bleu · est Cocorico','2682,-0978,0221','Au nord-ouest du sanctuaire O-ogim'),
 ('Lynel','Surface','Lynel bleu · canyon Gerudo','-1460,-2709,0141','Au nord du sanctuaire Kitawak'),
 ('Lynel','Surface','Lynel bleu · sud de Firone','-0588,-3835,0050','Au sud du sanctuaire Ishokin'),
 ('Lynel','Surface','Lynel bleu · sud lac Hylia','0093,-3385,0005','Entre les sanctuaires Ishokin et Utsushok'),
 ('Lynel','Profondeurs','Lynel bleu · sous Akkala Est','4246,2721,-0575','Sous le relais d’Akkala est'),
 ('Lynel','Profondeurs','Lynel bleu · sous Akkala sud','3144,1684,-0650','Au sud-est de la racine Gedihcayam'),
 ('Lynel','Profondeurs','Lynel bleu · sous le relais du pied','2599,1152,-0597','Au sud de la racine Anonisik'),
 ('Lynel','Profondeurs','Lynel bleu · sous le relais de la forêt','1037,1131,-0474','Au sud de la racine Uihcoke'),
 ('Lynel','Profondeurs','Lynel bleu · sous le relais du canyon','-2787,-2239,-0482','À l’ouest de la racine Kimakarut'),
 ('Lynel','Profondeurs','Lynel bleu · sous le relais du lac','1560,-3494,-0512','Au nord-est de la racine U-u-ujoj'),
 ('Lynel','Surface','Lynel blanc · plateau de Kamah','1472,-3031,0207','Nord du relais de la forêt de Firone'),
 ('Lynel','Surface','Lynel blanc · plaine d’Ukuku','3902,0973,0249','Au nord-est du domaine Zora'),
 ('Lynel','Surface','Lynel blanc · chaînes Gerudo','-4441,-0995,0507','Au nord-ouest de la tour Gerudo'),
 ('Lynel','Profondeurs','Lynel blanc · douves du château','-0243,0801,-1089','Dans l’abîme du château d’Hyrule'),
 ('Lynel','Profondeurs','Lynel blanc · sous le relais de Delass','-1238,0783,-0551','Près de la racine Kawakanis'),
 ('Lynel','Profondeurs','Lynel blanc · sous le relais de la plaine neigeuse','-1586,2538,-0684','Près de la racine Muihcoro'),
 ('Lynel','Profondeurs','Lynel blanc · sous le relais des Géminés','1754,-1912,-0463','À l’est de la racine Sohse'),
 ('Lynel','Profondeurs','Lynel blanc · sous le relais des alpages','0457,-3454,-0501','Au sud-ouest de la racine Kohsustu'),
 ('Lynel','Profondeurs','Lynel argenté · sous le relais des marécages','1047,-0284,-0468','À l’est de la racine Korakut'),
 ('Lynel','Profondeurs','Colisée flottant · 5 Lynels','-1120,-1171,-0499','5 combats successifs, près de la racine Mu-ustust'),
]: pin(t,layer,name,coord,place,LY,'Le rang de certains Lynels peut évoluer avec la progression.' if t=='Lynel' else '')
for layer,name,coord,place in [
 ('Surface','Griock de feu · colonnes antiques','-3590,0415,0264','Ouest du pont de Tabanta'),
 ('Surface','Griock de feu · pont d’Hylia','-0053,-2479,0039','Sur le pont du lac Hylia'),
 ('Surface','Griock de feu · rocher de la Longue-Vue','-2112,-2668,0412','Au sud-est de la tour du canyon Gerudo'),
 ('Surface','Griock de feu · vallée de Trilby','2373,0675,0803','Dans les airs au-dessus de la vallée de Trilby'),
 ('Surface','Griock de glace · plateau de Biron','-3695,3061,0351','Au nord de la tour du col de Rospro'),
 ('Surface','Griock de glace · sommet Gerudo','-4008,-0978,0718','Nord de la tour des hauteurs Gerudo'),
 ('Surface','Griock de glace · plaine neigeuse de Tabanta','-1779,2945,0239','Nord du relais de la plaine neigeuse'),
 ('Surface','Griock électrique · arènes de la surface','-1153,-1264,0092','Ruines du colisée'),
 ('Surface','Griock électrique · sud du lac Herin','1116,-3610,0093','Ouest du sanctuaire Joju-u-u'),
 ('Surface','Griock électrique · Akkala sud','3417,1305,0343','Plaine sud d’Akkala'),
 ('Profondeurs','Roi Griock · antre des Griocks','0188,3122,-0623','Sous les ruines des Obscurcies'),
 ('Ciel','Roi Griock · ciel d’Hébra','-4462,2260,1282','Au sud-ouest du sanctuaire Ijo-o'),
 ('Ciel','Roi Griock · ciel de Gerudo','-4315,-2599,1451','Îlot très éloigné au sud-ouest du ciel Gerudo'),
 ('Ciel','Roi Griock · ciel de Necluda','4602,-3667,1102','Îlot très éloigné au sud-est du ciel Necluda'),
]:pin('Griock',layer,name,coord,place,GL)
for name,coord,place in [
 ('Moldarquor · landes orientales','-2362,-3314,0019','Au sud-est du désert Gerudo, près du sanctuaire Siwakama'),
 ('Moldarquor · sud des terres désolées de Palu','-3308,-3289,0015','Au sud du bazar Assek, près du sanctuaire Chichim'),
 ('Moldarquor · dunes de Toruma','-4795,-2928,0027','Au nord du sanctuaire Miryotanog'),
 ('Moldarquor · désert Gerudo','-4015,-2549,0042','Au nord-ouest de la cité Gerudo'),
]: pin('Moldarquor','Surface',name,coord,place,MO)
for layer,name,coord,place in [
 ('Surface','Hinox · marais de Ludfo','-2226,0752,0102','Au sud-ouest de la tour de Lindor'),
 ('Surface','Hinox · grotte du mont Satori','-2200,-0646,0106','Grotte des contreforts du mont Satori'),
 ('Surface','Hinox · plaine de Rowan','-1256,2118,0106','À l’ouest du sanctuaire Kiuyoyou'),
 ('Surface','Hinox · plaine de Trilby','1297,0905,0027','Au sud-est du relais de la forêt'),
 ('Surface','Hinox · plaine de Blatchery','2077,-2000,0017','À l’est du relais des Géminés'),
 ('Profondeurs','Hinox · ouest de la plaine d’Hyrule','-1063,-0824,-0477','À l’ouest de la racine Nihcayam'),
 ('Surface','Hinox · tunnel du lac Rodai','1876,-2956,-0042','Grotte au nord du lac de Floria'),
]:pin('Hinox',layer,name,coord,place,OT)
for name,coord,place in [
 ('Gigatracien bleu-blanc · sous le château Est','0200,0935,-0473','À l’est du château d’Hyrule'),
 ('Gigatracien bleu-blanc · sud du village Piaf','-3734,0982,-0551','Nord-ouest de la racine Koro-nui'),
 ('Gigatracien bleu-blanc · îlot des douves Ouest','-0791,0819,-0464','Sous l’îlot des douves Ouest'),
 ('Gigatracien bleu-blanc · plaine neigeuse','-1859,2443,-0676','Au sud-ouest de la racine Muihcoro'),
 ('Gigatracien bleu-blanc · Hébra','-2316,1932,-0712','Au sud de la racine Aduon'),
 ('Gigatracien bleu-blanc · mont Gerudo','-4669,-1263,-0940','Au nord de la racine Stamayam'),
 ('Gigatracien d’obsidienne · Obscurcies','0473,3466,-0592','À l’est de la racine Katenim'),
 ('Gigatracien d’obsidienne · forêt Korogu','-0167,2897,-0616','Au nord-est de la racine Nikakik'),
 ('Gigatracien d’obsidienne · Est Necluda','2965,-0705,-0514','Au sud-est de la racine Takaruk'),
 ('Gigatracien d’obsidienne · Akkala sud','4133,1012,-0684','Au sud de la racine Kawikatisar'),
]: pin('Gigatracien','Profondeurs',name,coord,place,OT)
for t,layer,name,coord,place in [
 ('Golemax','Ciel','Golemax I · ciel d’Hébra ouest','-3798,2752,0544','Sous le sanctuaire Ijo-o'),
 ('Golemax','Ciel','Golemax I · ciel d’Hyrule nord','0443,2527,1662','Au sud-est du sanctuaire Mayam'),
 ('Golemax','Ciel','Golemax I · île céleste du Prélude','0485,-1517,1439','Au nord-est du sanctuaire Nachoyah'),
 ('Golemax','Profondeurs','Golemax I · canyon Gerudo','-2195,-1521,-0686','Au nord-est de la racine Kawiraus'),
 ('Golemax','Profondeurs','Golemax III · village d’Écaraille','3255,-3687,-0446','Au sud-est de la racine Mimufis'),
 ('Golemax','Profondeurs','Golemax III · labyrinthe d’Akkala','4654,3693,-0445','Labyrinthe souterrain d’Akkala'),
 ('Golemax','Profondeurs','Golemax III · labyrinthe nord','-0815,3534,-0682','Labyrinthe souterrain nord'),
 ('Golemax','Ciel','Golemax III · archipel Tabanta','-3442,0704,1434','Au sud-est du sanctuaire Ga-ahisas'),
 ('Lithorok','Surface','Lithorok magmatique · rivière Goronbi','1281,1709,0254','À l’ouest du sanctuaire Timawak'),
 ('Lithorok','Surface','Lithorok magmatique · lac Darman','1945,3188,0421','Au nord d’Ordinn, ouest du sanctuaire Sibajitak'),
 ('Lithorok','Surface','Lithorok de glace · sommet ouest Hébra','-4499,2459,0117','Sud du sanctuaire Tauyosipun'),
 ('Lithorok','Surface','Lithorok de glace · sommet est Hébra','-2682,3343,0240','À l’ouest du sanctuaire Sisuran'),
]:pin(t,layer,name,coord,place,OT)
for i,(coord,place) in enumerate([
 ('-1410,0963,0124','Près du relais de Delass'),('-2548,1888,0319','Collines de Tabanta'),('1828,0734,0090','Sud-est de la tour du canyon d’Ordinn'),('0692,-1307,0053','Ouest de la tour du plateau de Sahasla'),('-3175,-1700,0419','Nord-ouest de la tour du canyon Gerudo'),('-3096,-0080,0211','Plateau Illumeni'),('3322,-3565,0005','Côte de Gogobi'),('-1862,3623,0237','Nord de la plaine neigeuse de Tabanta'),('4467,-0301,0075','Est des hauteurs de Lanelle'),('-0651,-2681,0068','Rive ouest du lac Hylia'),('0889,2951,0363','Est des ruines des Obscurcies')],1):pin('Géoglyphe','Surface','Larme de dragon n°'+str(i),coord,place,DR,'La larme suivante se révèle après celles-ci.')
FUSE=[
 ('Corne affilée de Lynel d’argent',55,'Lynel d’argent','⚔️','Dégâts élevés'),('Corne briseuse de Lynel d’argent',51,'Lynel d’argent','🔨','Bonne contre les roches'),('Lame ancestrale',50,'Trésors et objets spécifiques','🗡️','Peut faire disparaître certains ennemis et leur butin'),('Corne affilée de Lynel blanc',44,'Lynel blanc','⚔️','Dégâts élevés'),('Corne briseuse de Lynel blanc',40,'Lynel blanc','🔨','Arme contondante'),('Os de Gibdo',40,'Gibdo','🦴','Fusion fragile / effet os'),('Corne de Bokoblin chef d’argent',37,'Bokoblin chef d’argent','👑','Matériau puissant'),('Croc de Gigatracien bleu-blanc',35,'Gigatracien bleu-blanc','🐸','Matériau contondant'),('Corne de Golem capitaine IV',35,'Golem capitaine IV','🤖','Dégâts élevés'),('Corne de Lézalfos d’argent',34,'Lézalfos d’argent','🦎','Arme tranchante'),('Corne affilée de Lynel bleu',33,'Lynel bleu','⚔️','Arme tranchante'),('Corne de Moblin d’argent',33,'Moblin d’argent','🪓','Arme tranchante'),('Mâchoire de Moldarquor',32,'Moldarquor','🦂','Effet os : synergie possible'),('Corne d’Horriblin d’argent',32,'Horriblin d’argent','🦇','Arme tranchante'),('Corne de Bokoblin d’argent',31,'Bokoblin d’argent','🪓','Matériau courant en fin de jeu'),('Queue de Lézalfos d’argent',31,'Lézalfos d’argent','🦎','Portée étendue'),('Corne de Griock des flammes',30,'Griock des flammes','🔥','Effet feu'),('Corne de Griock des glaces',30,'Griock des glaces','❄️','Effet glace'),('Corne de Griock électrique',30,'Griock électrique','⚡','Effet électrique'),('Corne briseuse de Lynel bleu',29,'Lynel bleu','🔨','Arme contondante'),('Corne de Stalhinox',29,'Stalhinox','💀','Bonus de dégâts'),('Corne de Bokoblin chef noir',27,'Bokoblin chef noir','👑','Matériau de fusion'),('Corne d’Hinox noir',27,'Hinox noir','👹','Matériau contondant'),('Corne de Lézalfos noir',26,'Lézalfos noir','🦎','Matériau tranchant'),('Corne de Dinraal',26,'Dinraal','🔥','Effet feu'),('Corne de Rordrac',26,'Rordrac','⚡','Effet électrique'),('Corne de Nedrac',26,'Nedrac','❄️','Effet glace'),('Diamant',25,'Lithorok rare / filons','💎','Matériau précieux'),('Corne de Golem capitaine III',25,'Golem capitaine III','🤖','Bonus soneau'),('Corne de Moblin noir',24,'Moblin noir','🪓','Matériau solide'),('Aile de Griock',24,'Griock','🪽','Effet de portée sur projectile'),('Croc de Gigatracien d’obsidienne',24,'Gigatracien d’obsidienne','🐸','Arme contondante'),('Corne de Golem soldat IV',24,'Golem soldat IV','🤖','Bonus soneau'),('Corne affilée de Lynel',22,'Lynel rouge','⚔️','Arme tranchante'),('Corne de dragon blanc',20,'Dragon blanc','✨','Effet de soin sur frappe'),('Éclat de croc de Dinraal',20,'Dinraal','🔥','Effet feu'),('Éclat de croc de Rordrac',20,'Rordrac','⚡','Effet électrique'),('Éclat de croc de Nedrac',20,'Nedrac','❄️','Effet glace')]
# Do not assert singular gear names or special weapon mechanics if unavailable: let user supply game-shown base number.
ROUTES=[
 dict(title='Le circuit des 5 Lynels',level='Expert',time='Après une Lune de sang',items='Cornes affilées, cornes briseuses, sabots, viscères',desc='Au Colisée flottant dans les Profondeurs, enchaîne les cinq Lynels. Prends des plats de soin contre les miasmes, des arcs à tirs multiples et des boucliers.',spots=['Colisée flottant · 5 Lynels'],ref='https://www.zeldadungeon.net/wiki/Floating_Coliseum'),
 dict(title='Le tour des 4 Moldarquors',level='Intermédiaire',time='Après une Lune de sang',items='Mâchoire, viscères, ailerons',desc='Attire chaque Moldarquor en lançant un objet sur le sable, fais-le jaillir avec une fleur bombe, puis frappe sa partie vulnérable.',spots=['Moldarquor · landes orientales','Moldarquor · dunes de Toruma','Moldarquor · désert Gerudo'],ref=MO),
 dict(title='Chasse aux Griocks',level='Expert',time='Après une Lune de sang',items='Cornes élémentaires, ailes, viscères',desc='Vise rapidement les trois têtes avec des flèches et des yeux de chauve-souris. Prévois une protection adaptée à l’élément du boss.',spots=['Griock de feu · pont d’Hylia','Griock électrique · arènes de la surface','Griock de glace · plateau de Biron'],ref=GL),
 dict(title='Farmer les Gigatraciens',level='Intermédiaire',time='Après une Lune de sang',items='Sonium, crocs et viscères de Gigatracien',desc='Dans les Profondeurs : lance une fleur bombe vers sa bouche ouverte, puis grimpe sur son dos pour briser les filons.',spots=['Gigatracien bleu-blanc · sous le château Est','Gigatracien d’obsidienne · Obscurcies'],ref='https://www.thonky.com/zelda-tears-of-the-kingdom/list-of-frox-locations'),
 dict(title='Récupérer les larmes du Dragon',level='Exploration',time='Une fois chacune',items='Souvenirs de l’histoire',desc='Parcours les géoglyphes, utilise la vue depuis les tours et repère la petite larme de dragon. Ce parcours dévoile des éléments majeurs de l’histoire.',spots=['Larme de dragon n°1','Larme de dragon n°2','Larme de dragon n°3'],ref=DR),
 dict(title='Améliorer l’équipement',level='Débutant',time='À la demande',items='Matériaux d’armures, fées, roupies',desc='Débloque les Grandes Fées, puis consulte le coût exact d’amélioration de chaque pièce. Ne vends pas automatiquement les viscères de boss ou les queues de Lézalfos.',spots=[],ref='https://zeldacentral.com/games/tears-of-the-kingdom/armor-sets/'),
]
CHECKS=[('Sanctuaires',152,'⛩️'),('Racines des Profondeurs',120,'🌱'),('Tours de reconnaissance',15,'🗼'),('Grottes',147,'🕳️'),('Puits',58,'🪣'),('Larmes de dragon',12,'💧'),('Graines Korogu',1000,'🌿')]
# Consistent totals for optional collectible tracking: seeds 1000 (from 900 puzzles); no implication these are the exact in-game 100% counter.
RECIPES=[('🍌','Attaque','Bananes lame','Plusieurs bananes lame cuites ensemble renforcent l’attaque.'),('🥕','Endurance bonus','Carottes enduro','Les carottes enduro procurent des cercles supplémentaires d’endurance.'),('🌶️','Résistance au froid','Piments','Cuis des piments pour résister au froid pendant une durée limitée.'),('🍄','Récupération complète','Truffe max','Une truffe max cuisinée redonne tous les cœurs avec un bonus temporaire.'),('🧊','Résistance à la chaleur','Ingrédients glagla','Cuisine des ingrédients portant l’effet « glagla ».'),('⚡','Résistance électrique','Ingrédients volt','Combine des ingrédients électriques pour réduire les dégâts de foudre.'),('🌱','Discrétion','Ingrédients silencio','Cuisine des ingrédients « silencio » pour augmenter la discrétion.'),('🧪','Élixir','Insecte + partie de monstre','Combine une créature à effet avec une partie de monstre, sans nourriture ordinaire.')]
# Add navigation sections and improve labels.
s=s.replace("['farming','💎','Farming'],", "['farming','💎','Farming'],['atlas','🗺️','Atlas'],['fusion','🧪','Amalgame'],")
s=s.replace("['armor','🛡️','Armures'],", "['armor','🛡️','Armures'],['guides','📖','Guides'],")
s=s.replace('<section class="hidden" id="screen-catalogue"></section>', '<section class="hidden" id="screen-catalogue"></section><section class="hidden" id="screen-atlas"></section><section class="hidden" id="screen-fusion"></section><section class="hidden" id="screen-guides"></section>')
s=s.replace('farming:renderFarming,catalogue:renderCatalogue', 'farming:renderFarming,atlas:renderAtlas,fusion:renderFusion,catalogue:renderCatalogue')
s=s.replace('weapons:renderWeapons,armor:renderArmor,assistant:', 'weapons:renderWeapons,armor:renderArmor,guides:renderGuides,assistant:')
s=s.replace("['catalogue','🔎','Catalogue +','Base en ligne : monstres, butins, équipement et ressources'],", "['catalogue','🔎','Catalogue +','Base en ligne : monstres, butins, équipement et ressources'],['atlas','🗺️','Atlas des boss','Coordonnées précises et suivi des rencontres'],['fusion','🧪','Atelier d’amalgame','Calcule les dégâts des fusions d’armes'],['guides','📖','Guides & progression','Routes, recettes et listes de collection'],")
s=s.replace('Version 2 · Catalogue externe optionnel', 'Version 3 · Atlas avec coordonnées · Atelier d’amalgame · Catalogue externe optionnel')
s=s.replace('Gratuit · Sauvegarde locale · V2','Gratuit · Sauvegarde locale · V3')
s=s.replace('name="description" content="Compagnon Zelda Tears of the Kingdom : boss, butins, farming et encyclopédie gratuite."','name="description" content="Hyrule Codex V3 : atlas des boss, farming, butins, armes, amalgame et progression pour Zelda Tears of the Kingdom."')
s=s.replace('<title>Hyrule Codex — Zelda Companion</title>','<title>Hyrule Codex V3 — Zelda Companion</title>')
# Differentiate total statistics with new features; no false exhaustiveness claim.
s=s.replace('const total=DB.monsters.length;', 'const total=DB.monsters.length;')
# persist extra state while preserving V1/V2 user progress; use new keys safely
s=s.replace('goals:[],notes:\'\'};', "goals:[],notes:'',atlasDone:{},checkCounts:{}};")
s=s.replace("const stKey='hyrule_codex_v1'", "const stKey='hyrule_codex_v1'")
# Remote compendium caching (offline after successful fetch). Avoid 5MB quota overshoots. localStorage cache lasts until refresh.
s=s.replace("let remoteCompendium=null, remoteLoading=false, remoteError='';", "let remoteCompendium=null, remoteLoading=false, remoteError='';try{const c=JSON.parse(localStorage.getItem('hyrule_codex_remote_totk_v3')||'null');if(Array.isArray(c)&&c.length>10)remoteCompendium=c}catch(e){}")
s=s.replace('remoteCompendium=arr.filter(x=>x&&typeof x.name===\'string\'&&typeof x.category===\'string\');', "remoteCompendium=arr.filter(x=>x&&typeof x.name==='string'&&typeof x.category==='string');try{localStorage.setItem('hyrule_codex_remote_totk_v3',JSON.stringify(remoteCompendium))}catch(e){}")
s=s.replace('🌐 Données étendues : anglais','🌐 Données étendues : noms du jeu en anglais')
s=s.replace("const pic=imageURL?", "const pic=imageURL?", 1)
# If search among sources too, include translated aliases for some names, without falsely auto-translating whole compendium.
# new content injection before init for functions to be declared before runtime.
js = r'''
/* V3 — Atlas, atelier d’amalgame, guides, compteurs, référence externe. */
const ATLAS=__ATLAS__;
const FUSIONS=__FUSE__;
const ROUTES=__ROUTES__;
const CHECKS=__CHECKS__;
const RECIPES=__RECIPES__;
const SOURCE_URLS={boss:'https://www.thonky.com/zelda-tears-of-the-kingdom/list-of-monster-locations',map:'https://www.zeldadungeon.net/tears-of-the-kingdom-interactive-map/',drops:'https://zeldacentral.com/games/tears-of-the-kingdom/game-data/drop-tables/',compendium:'https://hyrule-compendium.com/',fuse:'https://questfern.com/totk/weapons/fuse-guide/'};
let atlasType='Tous',atlasLayer='Tous',atlasSearch='',atlasOnlyRemaining=false,atlasFocus=null,atlasLimit=120;
function formattedCoord(p){return [p.x,p.y,p.z].map(x=>(x<0?'-':'')+String(Math.abs(x)).padStart(4,'0')).join(' / ')}
function atlasMatches(){let q=norm(atlasSearch);return ATLAS.filter(x=>(atlasType==='Tous'||x.type===atlasType)&&(atlasLayer==='Tous'||x.layer===atlasLayer)&&(!atlasOnlyRemaining||!state.atlasDone?.[x.id])&&norm(x.name+' '+x.place+' '+x.type+' '+formattedCoord(x)).includes(q));}
function pinIcon(t){return ({Lynel:'🦁',Griock:'🐉',Moldarquor:'🦂',Hinox:'👹',Gigatracien:'🐸',Golemax:'🤖',Lithorok:'🪨',Géoglyphe:'💧'})[t]||'📍'}
function renderAtlas(){state.atlasDone=state.atlasDone||{};let filtered=atlasMatches(),nDone=ATLAS.filter(x=>state.atlasDone[x.id]).length;
const selectors=`<div class="atlas-filter"><label class="search">⌕ <input id="atlas-search" value="${escapeHTML(atlasSearch)}" placeholder="Rechercher une zone, un boss, des coordonnées…" aria-label="Rechercher dans l’atlas"></label><select id="atlas-type" aria-label="Type de marqueur"><option value="Tous">Tous les types</option>${[...new Set(ATLAS.map(x=>x.type))].map(t=>`<option value="${t}" ${t===atlasType?'selected':''}>${pinIcon(t)} ${t}</option>`).join('')}</select><select id="atlas-layer" aria-label="Couche"><option value="Tous">🌍 Les 3 régions</option>${['Surface','Ciel','Profondeurs'].map(k=>`<option value="${k}" ${k===atlasLayer?'selected':''}>${k}</option>`).join('')}</select></div><label class="atlas-toggle"><input type="checkbox" id="atlas-remaining" ${atlasOnlyRemaining?'checked':''}> Masquer les emplacements cochés</label>`;
const display=filtered.slice(0,atlasLimit);let visual=filtered.slice(0,160);const pins=visual.map(p=>`<button class="atlas-pin ${p.id===atlasFocus?'selected':''} ${state.atlasDone[p.id]?'cleared':''}" style="left:${Math.max(2,Math.min(98,50+p.x/105))}%;top:${Math.max(3,Math.min(97,50-p.y/100))}%" aria-label="${escapeHTML(p.name)}" title="${escapeHTML(p.name)}" data-xy="${p.id}">${pinIcon(p.type)}</button>`).join('');
el('screen-atlas').innerHTML=section('Atlas d’Hyrule','Coordonnées XYZ de '+ATLAS.length+' rencontres et géoglyphes sélectionnés, avec suivi individuel.')+
`<div class="atlas-stats"><span>📍 ${ATLAS.length} lieux référencés</span><span>✅ ${nDone} cochés</span><span>🧭 ${filtered.length} résultats</span></div>${selectors}<div class="atlas-split"><div><div class="atlas-map" role="group" aria-label="Repère schématique de coordonnées XY"><div class="atlas-map-label">SCHÉMA XY · ${atlasLayer==='Tous'?'TOUTES COUCHES':atlasLayer.toUpperCase()}<small>Nord ↑ · Est →</small></div><div class="axis-center axis-v"></div><div class="axis-center axis-h"></div>${pins}</div><p class="atlas-disclaimer">Ce quadrillage est un <b>repère de coordonnées</b>, pas une carte fidèle du terrain. Les lieux à des altitudes différentes se superposent. Pour une vraie carte, utilise le lien ci-dessous.</p><div class="toolstrip"><a class="btn ghost" target="_blank" rel="noopener" href="${SOURCE_URLS.map}">↗ Carte interactive du jeu</a><button class="btn mini ghost" id="atlas-show-all">📍 Tout afficher</button></div></div><div class="atlas-listbox"><div class="atlas-list-title">RÉSULTATS · ${Math.min(display.length,filtered.length)} / ${filtered.length}</div><div class="atlas-list" id="atlas-results">${display.length?display.map(p=>`<div class="atlas-row ${state.atlasDone[p.id]?'marked':''}" id="row-${p.id}"><button class="atlas-mark" data-toggle-atlas="${p.id}" title="Cocher comme terminé" aria-label="${state.atlasDone[p.id]?'Marquer à refaire':'Marquer terminé'}">${state.atlasDone[p.id]?'✅':'◯'}</button><button class="atlas-row-main" data-open-atlas="${p.id}"><strong>${pinIcon(p.type)} ${escapeHTML(p.name)}</strong><small>${escapeHTML(p.place)} · ${escapeHTML(p.layer)}</small><em>⌖ ${formattedCoord(p)}</em></button><button class="atlas-copy" data-copy-xyz="${p.id}" title="Copier les coordonnées">⧉</button></div>`).join(''):'<p class="small" style="padding:22px">Aucun lieu correspondant aux filtres.</p>'}</div>${filtered.length>atlasLimit?'<button class="btn ghost" id="atlas-more">Afficher davantage de lieux</button>':''}</div></div><div class="note">💡 <b>Sur les Lynels :</b> certaines variantes évoluent selon l’avancement. Les cinq ennemis du Colisée flottant ont une seule entrée de lieu dans l’Atlas. Les géoglyphes sont une sélection (11 premières larmes) ; les boss marqués réapparaissent après une Lune de sang.</div><div class="sourcebox">Coordonnées recoupées à partir des listes publiées par <a href="${SOURCE_URLS.boss}" rel="noopener" target="_blank">Thonky</a> ; chaque fiche conserve le lien de la liste correspondante.</div>`;
 el('atlas-search').oninput=e=>{atlasSearch=e.target.value;atlasLimit=120;updateAtlasArea()};el('atlas-type').onchange=e=>{atlasType=e.target.value;atlasLimit=120;renderAtlas()};el('atlas-layer').onchange=e=>{atlasLayer=e.target.value;atlasLimit=120;renderAtlas()};el('atlas-remaining').onchange=e=>{atlasOnlyRemaining=e.target.checked;renderAtlas()};el('atlas-show-all').onclick=()=>{atlasLayer='Tous';atlasType='Tous';atlasSearch='';atlasOnlyRemaining=false;atlasLimit=120;renderAtlas()};wireAtlas();}
function updateAtlasArea(){const value=atlasSearch;renderAtlas();const input=el('atlas-search');input.focus();input.setSelectionRange(value.length,value.length)}
function wireAtlas(){el('screen-atlas').querySelectorAll('[data-xy],[data-open-atlas]').forEach(b=>b.onclick=()=>openAtlas(b.dataset.xy||b.dataset.openAtlas));el('screen-atlas').querySelectorAll('[data-toggle-atlas]').forEach(b=>b.onclick=()=>{const id=b.dataset.toggleAtlas;state.atlasDone[id]=!state.atlasDone[id];save();renderAtlas()});el('screen-atlas').querySelectorAll('[data-copy-xyz]').forEach(b=>b.onclick=()=>{const p=ATLAS.find(x=>x.id===b.dataset.copyXyz);if(p)copyXYZ(p)});if(el('atlas-more'))el('atlas-more').onclick=()=>{atlasLimit+=100;renderAtlas()}}
async function copyXYZ(p){const c=formattedCoord(p);try{await navigator.clipboard.writeText(c);toast('Coordonnées copiées : '+c)}catch(e){const t=document.createElement('textarea');t.value=c;document.body.append(t);t.select();document.execCommand('copy');t.remove();toast('Coordonnées : '+c)}}
function openAtlas(id){let p=ATLAS.find(x=>x.id===id);if(!p)return;let nearby=ATLAS.filter(a=>a.id!==id&&a.layer===p.layer&&Math.hypot(a.x-p.x,a.y-p.y)<550).slice(0,4);
const html=`<div class="detail"><button class="close" id="close-detail">✕ Fermer</button><div class="eyebrow">📍 FICHE DE L’ATLAS · ${escapeHTML(p.type)} · ${p.layer}</div><div class="bigicon">${pinIcon(p.type)}</div><h2>${escapeHTML(p.name)}</h2><div class="tags"><span class="tag gold">${p.layer}</span><span class="tag">${escapeHTML(p.type)}</span></div><h4>🧭 Coordonnées (X / Y / Z)</h4><div class="xyz-big">${formattedCoord(p)}</div><p>${escapeHTML(p.place)}</p>${p.tip?`<div class="note">${escapeHTML(p.tip)}</div>`:''}${nearby.length?`<h4>À proximité (même couche)</h4><ul>${nearby.map(x=>`<li>${escapeHTML(x.name)} · ${formattedCoord(x)}</li>`).join('')}</ul>`:''}<div class="toolstrip"><button class="btn" id="atlas-detail-copy">⧉ Copier XYZ</button><button class="btn ghost" id="atlas-detail-toggle">${state.atlasDone?.[p.id]?'✓ Terminé':'◯ Marquer terminé'}</button></div><div class="toolstrip"><a target="_blank" rel="noopener" href="${escapeHTML(p.source)}">↗ Source des coordonnées</a><a target="_blank" rel="noopener" href="${SOURCE_URLS.map}">↗ Carte interactive</a></div></div>`;
el('modalroot').innerHTML=`<div class="detail-dimmer" id="detail-dimmer" role="dialog" aria-modal="true" aria-label="${escapeHTML(p.name)}">${html}</div>`;
el('close-detail').onclick=closeDetail;el('detail-dimmer').onclick=e=>{if(e.target===el('detail-dimmer'))closeDetail()};el('atlas-detail-copy').onclick=()=>copyXYZ(p);el('atlas-detail-toggle').onclick=()=>{state.atlasDone=state.atlasDone||{};state.atlasDone[p.id]=!state.atlasDone[p.id];save();closeDetail();renderAtlas()};document.body.style.overflow='hidden';}
let fuseMatIndex=0,fuseBase=24,fuseSort='attack';
function renderFusion(){const materials=FUSIONS.map((f,i)=>({...{id:i,name:f[0],power:f[1],source:f[2],icon:f[3],trait:f[4]}}));let ordered=materials.slice().sort((a,b)=>fuseSort==='name'?a.name.localeCompare(b.name,'fr'):b.power-a.power);const selected=materials[fuseMatIndex]||materials[0], base=Number(fuseBase)||0;
el('screen-fusion').innerHTML=section('Atelier d’amalgame','Un calculateur pour estimer les dégâts affichés sur une arme, hors multiplicateurs spéciaux.')+
`<div class="fusion-box"><div class="fusion-controls"><div class="fusion-field"><label for="fuse-base">⚔️ Puissance de ton arme (dans l’inventaire, sans amalgame)</label><input type="number" id="fuse-base" min="0" max="999" step="1" value="${escapeHTML(fuseBase)}" inputmode="numeric"><span class="small">Entre la valeur exacte affichée dans TON jeu (arme corrodée ou intacte).</span></div><div class="fusion-plus">＋</div><div class="fusion-field"><label for="fuse-material">💎 Matériau d’amalgame</label><select id="fuse-material">${materials.map((x,i)=>`<option value="${i}" ${i===fuseMatIndex?'selected':''}>${x.name} (+${x.power})</option>`).join('')}</select><span class="small">${escapeHTML(selected.source)} · ${escapeHTML(selected.trait)}</span></div></div><div class="fusion-result"><div>PUISSANCE CALCULÉE <span>${base} + ${selected.power}</span></div><strong>${base+selected.power}</strong><div class="small">Puissance de base + bonus d’amalgame. Ne tient pas compte des multiplicateurs contextuels, des effets élémentaires, des coups critiques ni de la durabilité.</div></div></div>`+
`<div class="toolbar" style="justify-content:space-between"><h3 class="subhead">Matériaux les plus puissants (${FUSIONS.length})</h3><select class="inline-select" id="fuse-sort"><option value="attack" ${fuseSort==='attack'?'selected':''}>Trier par puissance</option><option value="name" ${fuseSort==='name'?'selected':''}>Trier par nom</option></select></div><div class="fusion-mats">${ordered.map(x=>`<button class="fuse-item ${x.id===fuseMatIndex?'selected':''}" data-fuse-id="${x.id}"><span class="fuse-ico">${x.icon}</span><span><strong>${escapeHTML(x.name)}</strong><small>${escapeHTML(x.source)}</small></span><b>+${x.power}</b></button>`).join('')}</div><div class="sourcebox">Référence des puissances de fusion : <a href="${SOURCE_URLS.fuse}" target="_blank" rel="noopener">données de matériaux Tears of the Kingdom</a> ; certaines fiches de dégâts de sites tiers sont contradictoires, les valeurs utilisées ici sont celles relevées dans ce tableau de données. La valeur finale en combat peut varier selon le type d’arme.</div>`;
el('fuse-base').oninput=e=>{const n=Number(e.target.value);fuseBase=Number.isFinite(n)?Math.max(0,Math.min(999,Math.round(n))):0;renderFusionResultOnly()};el('fuse-material').onchange=e=>{fuseMatIndex=+e.target.value;renderFusion()};el('fuse-sort').onchange=e=>{fuseSort=e.target.value;renderFusion()};el('screen-fusion').querySelectorAll('[data-fuse-id]').forEach(b=>b.onclick=()=>{fuseMatIndex=+b.dataset.fuseId;renderFusion();el('fuse-material').scrollIntoView({behavior:'smooth',block:'center'})});}
function renderFusionResultOnly(){let b=Number(fuseBase)||0,p=FUSIONS[fuseMatIndex][1];el('screen-fusion').querySelector('.fusion-result strong').textContent=b+p;el('screen-fusion').querySelector('.fusion-result span').textContent=b+' + '+p}
let guidesPane='routes';
function renderGuides(){state.checkCounts=state.checkCounts||{};const checks=CHECKS.map(([name,total,icon])=>{let done=state.checkCounts[name]||0;return `<div class="check-counter"><div><strong>${icon} ${name}</strong><small>${done} / ${total}</small></div><div class="check-input"><button data-minus="${escapeHTML(name)}" aria-label="Enlever un">−</button><input type="number" inputmode="numeric" min="0" max="${total}" value="${done}" aria-label="${escapeHTML(name)}" data-count="${escapeHTML(name)}"><button data-plus="${escapeHTML(name)}" aria-label="Ajouter un">＋</button></div><div class="progress" style="grid-column:1/-1"><span style="width:${Math.round(done/total*100)}%"></span></div></div>`}).join('');
let content=guidesPane==='routes'?`<div class="route-grid">${ROUTES.map((r,i)=>`<article class="route-card"><div class="route-top"><span class="eyebrow">ITINÉRAIRE ${i+1}</span><span class="tag">${escapeHTML(r.level)}</span></div><h3>${escapeHTML(r.title)}</h3><div class="small">📅 ${escapeHTML(r.time)}</div><p>${escapeHTML(r.desc)}</p><div class="route-drops">🎁 ${escapeHTML(r.items)}</div><div class="toolstrip"><button class="btn mini" data-goalroute="${i}">＋ Objectif</button>${r.spots.length?`<button class="btn mini ghost" data-locroute="${i}">🗺️ Localiser</button>`:''}<a href="${r.ref}" target="_blank" rel="noopener">Source ↗</a></div></article>`).join('')}</div>`:guidesPane==='collection'?`<div class="checks-wrap">${checks}</div><div class="note">Ces compteurs sont personnels : ils ne se synchronisent pas avec la Switch. Les 1 000 graines Korogu proviennent de 900 énigmes (certaines récompensent deux graines). Ces totaux ne sont pas une définition complète du « 100 % » du compteur du jeu.</div>`:`<div class="recipe-grid">${RECIPES.map(([icon,effect,ingredient,note])=>`<div class="recipe-card"><div class="fuse-ico">${icon}</div><div><strong>${escapeHTML(effect)}</strong><p class="small">${escapeHTML(ingredient)}</p><p>${escapeHTML(note)}</p></div></div>`).join('')}</div><div class="note">💡 N’associe pas des effets de repas différents dans une même préparation : ils peuvent s’annuler. Quantités, qualité, moment de cuisine et bonus éventuels modifient les valeurs finales.</div>`;
el('screen-guides').innerHTML=section('Guides & progression','Itinéraires de farming, suivi du 100 % et aide à la cuisine.')+
`<div class="tabs-guides"><button data-guide="routes" class="${guidesPane==='routes'?'active':''}">🗺️ Circuits</button><button data-guide="collection" class="${guidesPane==='collection'?'active':''}">🏆 Collectibles</button><button data-guide="recettes" class="${guidesPane==='recettes'?'active':''}">🍲 Cuisine</button></div>${content}<div class="sourcebox">Pour les butins très détaillés (y compris les probabilités), consulte <a target="_blank" rel="noopener" href="${SOURCE_URLS.drops}">les tables de butin externes</a>. Les itinéraires sont des suggestions, pas un calcul automatique de trajet.</div>`;
el('screen-guides').querySelectorAll('[data-guide]').forEach(b=>b.onclick=()=>{guidesPane=b.dataset.guide;renderGuides()});el('screen-guides').querySelectorAll('[data-goalroute]').forEach(b=>b.onclick=()=>{const r=ROUTES[+b.dataset.goalroute];state.goals.push({id:String(Date.now())+Math.random(),text:'Circuit : '+r.title,done:false});save();toast('Circuit ajouté aux objectifs')});el('screen-guides').querySelectorAll('[data-locroute]').forEach(b=>b.onclick=()=>{const r=ROUTES[+b.dataset.locroute];atlasType='Tous';atlasLayer='Tous';atlasOnlyRemaining=false;atlasSearch=r.spots[0].split(' · ')[0];goto('atlas')});el('screen-guides').querySelectorAll('[data-count]').forEach(b=>b.onchange=()=>updateCounter(b.dataset.count,Number(b.value)));el('screen-guides').querySelectorAll('[data-plus]').forEach(b=>b.onclick=()=>updateCounter(b.dataset.plus, (state.checkCounts[b.dataset.plus]||0)+1));el('screen-guides').querySelectorAll('[data-minus]').forEach(b=>b.onclick=()=>updateCounter(b.dataset.minus,(state.checkCounts[b.dataset.minus]||0)-1));}
function updateCounter(name,n){let total=CHECKS.find(x=>x[0]===name)?.[1]||0;state.checkCounts=state.checkCounts||{};state.checkCounts[name]=Math.max(0,Math.min(total,Number.isFinite(n)?Math.round(n):0));save();renderGuides();}
'''
js=js.replace('__ATLAS__',json.dumps(points,ensure_ascii=False,separators=(',',':'))).replace('__FUSE__',json.dumps(FUSE,ensure_ascii=False,separators=(',',':'))).replace('__ROUTES__',json.dumps(ROUTES,ensure_ascii=False,separators=(',',':'))).replace('__CHECKS__',json.dumps(CHECKS,ensure_ascii=False,separators=(',',':'))).replace('__RECIPES__',json.dumps(RECIPES,ensure_ascii=False,separators=(',',':')))
s=s.replace('function init(){',js+'\nfunction init(){')
# add an inline shortcut on front page to new features if the quickgrid list replacement misses due existing markup.
if "['atlas','🗺️','Atlas des boss'" not in s:
 s=s.replace("['farming','💎','Trouver un matériau','Quel ennemi farmer pour une ressource ?'],", "['farming','💎','Trouver un matériau','Quel ennemi farmer pour une ressource ?'],['atlas','🗺️','Atlas des boss','Coordonnées et marques terminées'],['fusion','🧪','Atelier d’amalgame','Dégâts de fusion des armes'],['guides','📖','Guides & routes','Circuits, cuisine et progression'],")
# Add clickable cross-links to atlas from detailed monster fiches; small but useful.
s=s.replace('<button class="btn ghost" id="detail-ask">✦ Demander plus</button>', '<button class="btn ghost" id="detail-ask">✦ Demander plus</button><button class="btn ghost" id="detail-atlas">📍 Dans l’atlas</button>')
s=s.replace("el('detail-ask').onclick=()=>{closeDetail();", "el('detail-atlas').onclick=()=>{let key=isMon?(x.name.includes('Griock')?'Griock':x.name.includes('Lynel')?'Lynel':x.name.includes('Moldarquor')?'Moldarquor':x.name.includes('Hinox')?'Hinox':x.name.includes('Golemax')?'Golemax':x.name.includes('Gigatracien')?'Gigatracien':x.name.includes('Lithorok')?'Lithorok':''):'';closeDetail();atlasType=key||'Tous';atlasLayer='Tous';atlasSearch='';goto('atlas')};el('detail-ask').onclick=()=>{closeDetail();")
# Add accurate encyclopedia note, plus links when offline.
s=s.replace('<div class="footer">Version 3', '<div class="footer">✦ V3 autonome : ${DB.monsters.length} fiches françaises, atlas à coordonnées et guide de fusion. Le compendium en ligne est complémentaire ; aucune fiche prétend couvrir toutes les quêtes. · Version 3')
# Oops above is plain HTML not template string; fix to actual counts.
s=s.replace('${DB.monsters.length} fiches françaises',str(len(DB['monsters']))+' fiches françaises')
# Extend export and import to V3 progress without losing V1/V2 compatibility.
s=s.replace("JSON.stringify({owned:state.owned,defeated:state.defeated,goals:state.goals},null,2)", "JSON.stringify({version:3,owned:state.owned,defeated:state.defeated,goals:state.goals,atlasDone:state.atlasDone||{},checkCounts:state.checkCounts||{}},null,2)")
s=s.replace("state.goals=t.goals.filter(x=>x&&typeof x.text==='string'&&typeof x.id==='string').slice(0,500);save();render()", "state.goals=t.goals.filter(x=>x&&typeof x.text==='string'&&typeof x.id==='string').slice(0,500);if(t.atlasDone&&typeof t.atlasDone==='object'&&!Array.isArray(t.atlasDone)){state.atlasDone=Object.fromEntries(Object.entries(t.atlasDone).filter(([key,value])=>/^a[0-9]+$/.test(key)&&typeof value==='boolean').slice(0,1000))}if(t.checkCounts&&typeof t.checkCounts==='object'&&!Array.isArray(t.checkCounts)){state.checkCounts=Object.fromEntries(Object.entries(t.checkCounts).filter(([name,value])=>CHECKS.some(x=>x[0]===name)&&Number.isFinite(value)).map(([name,value])=>[name,Math.max(0,Math.min(CHECKS.find(x=>x[0]===name)[1],Math.round(value)))]))}save();render()")
# Add CSS and mobile horizontal navigation.
css=r'''
/* Hyrule Codex V3 additions */
@media(max-width:760px){main{padding-bottom:calc(104px + env(safe-area-inset-bottom))}.mobile-nav{display:flex;overflow-x:auto;overscroll-behavior-x:contain;scroll-snap-type:x proximity;scrollbar-width:none;gap:0;justify-content:flex-start}.mobile-nav::-webkit-scrollbar{display:none}.mobile-nav button{flex:0 0 78px;min-width:78px;scroll-snap-align:start;padding:11px 2px 9px;min-height:67px}.mobile-nav .nav-ico{font-size:21px}}
.atlas-filter{display:grid;grid-template-columns:2.3fr 1fr 1fr;gap:10px;align-items:stretch}.atlas-filter .search{width:100%}.atlas-filter select,.inline-select{background:#152c31;color:var(--text);border:1px solid var(--line);border-radius:10px;padding:12px;min-height:48px}.atlas-toggle{font-size:13px;display:flex;align-items:center;gap:9px;margin:12px 0 18px;color:var(--muted)}.atlas-toggle input{width:18px;height:18px;accent-color:var(--mint)}.atlas-stats{display:flex;flex-wrap:wrap;gap:9px;margin-bottom:17px}.atlas-stats span{font-size:12px;background:#183336;border:1px solid var(--line);color:var(--gold2);padding:8px 12px;border-radius:100px}.atlas-split{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(0,.9fr);gap:18px;align-items:start}.atlas-map{position:relative;min-height:480px;overflow:hidden;border-radius:17px;border:1px solid #49786b;background:linear-gradient(90deg,transparent 49.9%,#609c8233 50%,transparent 50.1%),linear-gradient(0deg,transparent 49.9%,#609c8233 50%,transparent 50.1%),repeating-linear-gradient(90deg,#ffffff00 0,#ffffff00 calc(20% - 1px),#ffffff0f 20%),repeating-linear-gradient(0deg,#ffffff00 0,#ffffff00 calc(20% - 1px),#ffffff0f 20%),radial-gradient(ellipse at 50% 53%,#214b42,#162d38 70%,#0d212b);box-shadow:inset 0 0 80px #09161b}.atlas-map-label{position:absolute;top:14px;left:16px;z-index:3;color:var(--gold2);font-size:11px;letter-spacing:2px;font-weight:900;background:#0c1c25bd;border:1px solid #416358;border-radius:9px;padding:8px}.atlas-map-label small{display:block;color:var(--muted);font-size:10px;letter-spacing:0;margin-top:4px}.atlas-pin{position:absolute;z-index:2;transform:translate(-50%,-50%);border:1px solid #ffffff66;border-radius:50%;background:#1f4a47;color:#fff;width:28px;height:28px;display:grid;place-items:center;font-size:14px;box-shadow:0 3px 8px #0008;transition:scale .12s}.atlas-pin:focus,.atlas-pin.selected{scale:1.4;border-color:var(--gold);z-index:4}.atlas-pin.cleared{opacity:.43;filter:grayscale(.7)}.atlas-disclaimer{font-size:12px;line-height:1.6;color:var(--muted)}.atlas-listbox{border:1px solid var(--line);border-radius:16px;overflow:hidden;background:#0e2229}.atlas-list-title{font-size:11px;letter-spacing:2px;font-weight:800;color:var(--gold);padding:14px 16px;border-bottom:1px solid var(--line)}.atlas-list{max-height:565px;overflow:auto;overscroll-behavior:contain}.atlas-row{display:flex;gap:6px;align-items:center;padding:8px 7px;border-bottom:1px solid #36504d55}.atlas-row.marked{opacity:.62}.atlas-mark,.atlas-copy{border:0;background:none;color:var(--gold2);font-size:21px;padding:8px;flex-shrink:0}.atlas-copy{font-size:19px}.atlas-row-main{flex:1;text-align:left;background:transparent;border:0;color:var(--text);min-width:0;padding:6px 0}.atlas-row-main strong{font-size:13px;display:block}.atlas-row-main small{display:block;color:var(--muted);font-size:11px;line-height:1.5;margin:5px 0}.atlas-row-main em{font-style:normal;color:var(--mint);letter-spacing:1px;font-size:12px;font-weight:800}.xyz-big{font-weight:900;letter-spacing:3px;border:1px dashed #63827f;border-radius:12px;padding:16px;color:var(--gold2);font-size:clamp(20px,4vw,32px);background:#162f32}.fusion-box{border:1px solid var(--line);border-radius:20px;background:linear-gradient(120deg,#213735,#112732);padding:22px;margin-bottom:26px}.fusion-controls{display:grid;grid-template-columns:1fr 38px 1.3fr;gap:16px;align-items:center}.fusion-field{display:grid;gap:9px}.fusion-field label{color:var(--gold2);font-weight:800;font-size:13px}.fusion-field input,.fusion-field select{width:100%;padding:14px;background:#10232b;color:var(--text);border:1px solid #597d74;border-radius:11px;min-height:51px}.fusion-field .small{min-height:36px}.fusion-plus{font-size:27px;color:var(--mint);text-align:center;font-weight:900}.fusion-result{text-align:center;border:1px solid #83987966;background:#0b1a23e1;border-radius:14px;padding:23px;margin-top:23px}.fusion-result>div:first-child{letter-spacing:2px;color:var(--muted);font-size:12px}.fusion-result span{color:var(--mint);letter-spacing:0;display:block;font-size:17px;margin-top:7px}.fusion-result strong{display:block;font-size:clamp(60px,10vw,100px);color:var(--gold2);line-height:1.25}.fusion-result .small{max-width:600px;margin:auto}.fusion-mats{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}.fuse-item{display:flex;align-items:center;gap:10px;min-width:0;background:#162c32;border:1px solid var(--line);border-radius:12px;text-align:left;padding:13px;color:var(--text)}.fuse-item.selected{border-color:var(--gold);background:#31443b}.fuse-item span:nth-child(2){flex:1;min-width:0}.fuse-item strong,.fuse-item small{display:block}.fuse-item strong{font-size:13px}.fuse-item small{font-size:11px;color:var(--muted);margin-top:6px}.fuse-item b{color:var(--gold2);font-size:19px}.fuse-ico{font-size:24px;flex-shrink:0}.subhead{font-size:18px;color:var(--gold2)}.tabs-guides{display:flex;gap:8px;overflow-x:auto;margin:8px 0 19px;padding-bottom:4px}.tabs-guides button{color:var(--text);border:1px solid var(--line);background:#132d33;border-radius:99px;padding:10px 17px;white-space:nowrap;font-size:13px;font-weight:800}.tabs-guides button.active{background:#46614d;border-color:var(--gold);color:var(--gold2)}.route-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.route-card{border:1px solid var(--line);background:#162c32;border-radius:18px;padding:23px}.route-card h3{font-size:22px;color:var(--gold2);margin:11px 0}.route-card p{line-height:1.7;font-size:13px}.route-top{display:flex;justify-content:space-between;align-items:center;gap:8px}.route-drops{border-left:3px solid var(--mint);background:#193d3d;padding:10px 13px;font-size:12px;line-height:1.7;border-radius:7px;margin:12px 0}.route-card .toolstrip{align-items:center;margin-top:16px}.route-card .toolstrip a{font-size:12px}.checks-wrap{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:13px}.check-counter{background:#183037;border:1px solid var(--line);border-radius:14px;padding:16px;display:grid;grid-template-columns:1fr auto;gap:12px;align-items:center}.check-counter strong,.check-counter small{display:block}.check-counter strong{font-size:13px}.check-counter small{font-size:12px;color:var(--muted);margin-top:6px}.check-input{display:flex;gap:5px;align-items:center}.check-input button{border:1px solid var(--line);background:#28433e;border-radius:9px;color:var(--gold2);height:33px;min-width:33px}.check-input input{width:66px;text-align:center;background:#0e2129;color:var(--text);border:1px solid var(--line);border-radius:8px;padding:7px;font-size:13px}.recipe-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.recipe-card{display:flex;gap:14px;background:#172e34;border-radius:15px;border:1px solid var(--line);padding:18px}.recipe-card strong{color:var(--gold2)}.recipe-card p{margin:7px 0;font-size:12px;line-height:1.6}
@media(max-width:960px){.atlas-split{grid-template-columns:1fr}.atlas-map{min-height:380px}.atlas-list{max-height:450px}}
@media(max-width:680px){.atlas-filter{grid-template-columns:1fr 1fr}.atlas-filter .search{grid-column:1/-1}.atlas-map{min-height:340px}.atlas-pin{height:24px;width:24px;font-size:11px}.fusion-controls{grid-template-columns:1fr;gap:13px}.fusion-plus{line-height:1}.fusion-mats,.route-grid,.checks-wrap,.recipe-grid{grid-template-columns:1fr}.fusion-box{padding:15px}.route-card{padding:17px}}
'''
s=s.replace('</style></head>',css+'</style></head>')
# Point counts captured on homepage stat in hero intro, with accurate metrics.
s=s.replace('Version 2', 'Version 3')
# Rev service worker cache after any update
p.joinpath('index.html').write_text(s,encoding='utf-8')
for asset in ['icon-192.png','icon-512.png','apple-touch-icon.png']:
 shutil.copy('/mnt/data/hyrule_codex_v2/'+asset,p/asset)
manifest=json.loads(Path('/mnt/data/hyrule_codex_v2/manifest.webmanifest').read_text())
manifest['name']='Hyrule Codex V3 — Tears of the Kingdom';manifest['description']='Guide Zelda non officiel : atlas GPS XYZ, bestiaire, farming, fusions, armures et progression, sans abonnement.'
(p/'manifest.webmanifest').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
sw="""const CACHE='hyrule-codex-v3-20261111';const ASSETS=['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png','./apple-touch-icon.png'];self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)));self.skipWaiting()});self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))));self.clients.claim()});self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;const u=new URL(e.request.url);if(u.origin!==self.location.origin)return;e.respondWith(caches.match(e.request).then(cached=>{const network=fetch(e.request).then(r=>{if(r.ok){const cp=r.clone();caches.open(CACHE).then(c=>c.put(e.request,cp))}return r}).catch(()=>cached||caches.match('./index.html'));return cached||network}))});"""
(p/'sw.js').write_text(sw)
readme=f'''HYRULE CODEX V3 — Application web gratuite pour Zelda Tears of the Kingdom
===============================================================

Fonctions : {len(DB['monsters'])} fiches en français (sélection, pas exhaustif), {len(points)} repères exacts de lieu (le Colisée flottant compte pour 1 lieu), {len(FUSE)} matériaux avec puissance de fusion, {len(DB['materials'])} ressources de farming, {len(DB['weapons'])} fiches d'arsenal, {len(DB['armors'])} armures, 6 circuits, 7 compteurs de collectibles, recettes, objectifs et import/export.

Le catalogue externe Hyrule Compendium API (en anglais) se charge avec Internet depuis https://api.hyrule-compendium.com/v3/compendium/all?game=2 . Une fois chargé, le texte est mémorisé pour lecture hors ligne dans le navigateur. Les images distantes restent soumises à Internet et à la disponibilité du service.

INSTALLATION IPHONE :
1. Décompresser le ZIP ; publier ce dossier sur un hébergement HTTPS de sites statiques (par ex. Netlify Drop). Il contient index.html à la racine.
2. Ouvrir l'adresse publique du site dans SAFARI sur iPhone.
3. Menu de page Safari → Partager → Sur l'écran d'accueil → Ouvrir comme app web → Ajouter.
4. Ouvrir l'icône Hyrule Codex sur l'écran d'accueil.

L'aperçu HTML dans ChatGPT / l'app Fichiers iOS n'exécute pas forcément JavaScript : utiliser Safari sur un site HTTPS. Les fonctions locales principales sont disponibles hors ligne après la première visite et l'installation PWA. Un usage hors-ligne au premier lancement n'est pas garanti.

PROGRESSION : La clé localStorage « hyrule_codex_v1 » reste identique à V1/V2 pour conserver les anciennes cases cochées si publié sur la même origine/URL. Si le domaine change, exporter la progression depuis l'ancien site et réimporter depuis le nouveau. Attention : stocker les données sur le même domaine peut ne pas être possible si vous publiez sur un autre site Netlify.

SOURCES INFORMATIVES :
- Thonky, coordonnées : https://www.thonky.com/zelda-tears-of-the-kingdom/list-of-monster-locations
- Zelda Central, tables de butin : https://zeldacentral.com/games/tears-of-the-kingdom/game-data/drop-tables/
- QuestFern, puissances de fusion : https://questfern.com/totk/weapons/fuse-guide/
- Hyrule Compendium API (MIT) : https://github.com/gadhagod/Hyrule-Compendium-API
- Zelda Dungeon, carte : https://www.zeldadungeon.net/tears-of-the-kingdom-interactive-map/

Il s'agit d'un projet amateur non affilié à Nintendo. Les noms et marques liés à Zelda appartiennent à leurs propriétaires. Aucune promesse d'exhaustivité ni de chances de butin garanties.
'''
(p/'README.txt').write_text(readme)
zip_path=Path('/mnt/data/Hyrule_Codex_V3_iPhone.zip')
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(p.iterdir()):z.write(f,f.name)
Path('/mnt/data/Hyrule_Codex_V3.html').write_text(s)
print('DB', {k:len(v) for k,v in DB.items()},'atlas',len(points),'fuse',len(FUSE),'zip',zip_path.stat().st_size)
