"""Reference names & in-game coordinates compiled from public location indexes.
Titles are game factoids, no prose copied. Verify against the linked map when precision matters.
"""
SHRINE_RAW='''
Taji Qatu|0344,-1009,0042
Joti Iyu|4347,2876,0188
Si Tumoï|2369,2596,0802
Olom Uaqa|-3079,1617,0264
Maya Tinoü|-0706,-0869,0057
Musano Qila|0408,2134,0167
Len Ize|0756,0824,0106
Sahilo Ua|-3354,2386,0380
Rotu Mam|-3407,-1363,0355
Maya Matuno|-4638,-1513,0470
Seltabo Mati|-0179,1170,0301
Moga Uaqa|3300,0424,0136
Zanmi Qalqa|3470,-2181,0171
Ziu Qoüme|0868,-2278,0165
Iün Oloq|-3539,0851,-0105
Solyota Nigo|-3882,-2963,0147
Maya Qoqo|1270,3733,0130
Gemi Miqa|4513,2116,0027
Olo Tiüm|-1637,2642,0261
Sinaqa Uaqa|-1415,0757,0113
Taü Yosipuni|-4539,2880,0283
Tuqa Loqu|0915,-0251,0059
Siq Quti|0699,2793,0248
Siua Qama|-2446,-3344,0067
Tulaqa Uaqa|-3498,-0197,0090
Riö Goqo|-1441,-1616,0113
Aneda Mimiqa|4232,-2178,0013
Maya Usiyu|-1167,2602,-0057
Ixoda Qun|-0879,0423,0074
Qiü Yoyoü|-1107,2088,0128
Eqo Tiü|1063,1280,0071
Tadalo Qun|-1082,-2187,0152
Qalaha Tagi|-3728,-3625,0068
Qisi Nona|2568,1246,0196
Oxo Sagnu|-1404,3678,0308
Ga Sasa|-4153,0098,0066
Tula Qamiqa|-2657,-2237,0092
Gata Qisa|-3652,1806,0191
Ihe Na|3786,0578,0503
Tut Ume|-1423,-1351,0092
Qamatu Qisa|3431,3357,0095
Se Papa|0222,1085,0053
Maya Tata|-3291,-2512,0050
Susu Yaï|-0785,-0434,0044
Apo Geqe|3887,-0217,0187
Domi Zuïno|3305,1443,0444
Qiqa Qun|-0396,2736,0308
Sivaji Taqiö|2400,3275,0421
Utu Xoqi|0670,-3358,0096
Ziqa Isen|4267,-1673,0204
Qita Uaqa|-1530,-2929,0341
Sona Pano|-1922,-0359,0250
Malaq Guti|1762,2510,0455
Runa Qita|-2530,1170,0200
Uaö Osa|-4058,1990,0206
Qyoq Goni|-0709,-1551,0032
Noü Da|-2318,2201,0196
Eüto Ume|-3507,3570,0406
Isi Sime|1842,2842,0383
Maya Tidegina|3061,1824,0238
Otu Tuma|-4469,-0671,0526
Uto Zixi|1218,-2543,0121
Qami Zuna|-0178,-1558,0048
Suäli Uaqa|-2524,-1770,0155
Laqa Quda Zito|-2037,-1853,0089
Lasitaqi Uaqa|4167,1323,0251
Zaq Suqa|3526,-1482,0190
Jojo Niü|1202,0330,0052
Sifu Mimi|2826,-3270,0102
Ota Qalqa|-4391,3714,0234
Milio Tanigo|-4680,-3086,0079
Qima Yata|2864,3638,0262
Momo Siqa|2960,2758,0541
Iga Xuq|4655,3714,0154
Taqi Ihabano|-1830,1195,0171
En Oma|0103,-2518,-0061
Yomi Zuqi|4413,-0613,0060
Maya Hisiqa|3729,-2059,0211
Motu Sisi|-1795,-3487,0070
Maoï Qesqa|2276,0147,0103
Moxa Pin|2679,1904,0154
Usa Zuma|-2139,-0874,0118
Jo Niü|2918,0507,0178
Zio Taqiö|1834,3180,0279
Iqa Taq|-3951,1139,0135
Titi Maü|-3211,-3007,-0024
Nin Zixi|0355,1892,0201
Toqi Yoü|2304,-2378,-0003
Sequn Bomala|0167,2320,0202
Ruta Fuüme|-2998,3102,0531
O Ogin|2756,-1089,0124
Jo Goü|3346,-1187,0082
Maya Liïna|4631,-3712,0044
Pupun Qe|0621,2211,0187
Vami Toqa|-3094,-3210,0106
Ila Saqu|-4159,-3825,0053
Qula Qata|2361,-0511,0179
Susu Bië|0349,-2052,-0001
Exo Se|1566,-1945,0180
Oya Miö|0333,0470,0054
Ten Ziten|-0075,-1116,0046
Maya Otaqi|-0825,3535,0256
Maqlu Qisa|-2847,0630,0255
Sinata Niqalqa|3842,2300,0073
Joti Xiü|0931,-1903,0055
Ixo Qin|-0565,-3524,0152
Sisu Rana|-2559,3354,0266
Ten Maten|-0595,1551,0011
Joti Ihiga|3811,1219,0115
Maqa Sula|1770,-1052,0189
Qyono Nisiü|-0205,0451,0046
Tima Uaqa|1800,1640,0332
Jon Saü|1744,0018,0051
Lasi Uaqa|4664,3263,0027
Qudani Sala|-4167,-2143,0075
Joju Uü|1515,-3577,0165
Zio Siniö|-0241,-0371,0052
Gata Nisisi|4498,0826,0119
Mo Lonqu|1182,-0779,0157
Mineta Qalqa|0394,3485,0093
Laqa Xogo|-1715,-2119,1155
Ten Vezaï|-0970,3535,1019
Ijo O|-3861,2682,0716
Mayaü Meqisa|-2948,3051,0907
Ziruta Gumati|2916,0534,0960
Gata Unali|1882,1203,1255
Mogi Sali|4655,3500,1018
Siya Motusi|-1795,-3295,1019
Uqo Uho|0275,-0913,1460
Gutan Bati|0709,-1383,1582
In Isa|0026,-1504,1409
Nacho Yaha|0390,-1661,2284
Maya Nasi|4613,-0947,1784
Igo Xon|3481,0666,1328
Joq Usini|1075,-3348,0798
Ximoxi Uaqa|0162,1972,0771
Yansa Mino|2351,-1783,1475
Qumama Ino|2857,-2856,1216
Giqa Qun|4506,2166,1160
Qahata Naüme|-3296,3432,1349
Joq U|1376,-3340,0447
Nata Qalqa|3671,1484,1163
Gano Sa|-3370,0467,1691
Taün Hiyo|-2402,0825,0630
Jo Siü|1758,-1208,0933
Gaahi Sasa|-3596,0961,1694
Zino Qaö|-1257,-1487,1016
Siha Jogoü|4546,-0846,1127
Maya Siäla|-3547,-0321,1956
Maya Miï|0340,2815,1814
Uqo Ozixi|1469,-2169,0601
Tanino Uda|-1802,3407,0958
'''
ROOT_NAMES='''
Utaq Ijat
Uyi Itoj
Iömut Is
Aqau Molo
Uönit Ayam
Aliq Onasum
Ezi Nel
Au Olihas
Mam Utor
Onutam Ayam
Itam Obatles
Aqau Agom
Aqlaq Imnaz
Emuöq Uiz
Qolo Nuï
Ogin Atoylos
Oqoq Ayam
Aqim Imeg
Muït Olo
Aqau Aqanis
Inupisoy Üat
Uqol Aqut
Ituq Qis
Amaq Auis
Aqau Aqalut
Oqog Oïr
Aqimim Adena
Uyisu Ayam
Nuq Adoxi
Uöyoy Uïq
Uït Oqe
Nuq Oladat
Igat Ahalaq
Anon Isiq
Ungas Oxo
Asas Ag
Aqimaq Alut
Asiq Atag
An Ehi
Emu Tut
Asiq Utamaq
Apap Es
Atat Ayam
Iäy Usus
Eqeg Opa
Oniüz Imod
Nuq Aqiq
Oïqat Ijavis
Iqox Utu
Nesi Aqiz
Aqau Atiq
Onap Anos
Itug Qalam
Atiq Anur
Aso Oäu
Inog Qoyq
Ad Uön
Emu Otuë
Emis Isi
Anigedit Ayam
Amut Uto
Ixiz Otu
Anuz Imaq
Aqau Ilaüs
Otiz Aduq Aqal
Aqau Iqatisal
Aqus Qaz
Uïn Ojoj
Imim Ufis
Aqlaq Ato
Oginat Oilim
Atay Amiq
Aqis Omom
Qux Agi
Onabahi Iqat
Amo Ne
Iquz Imoy
Aqisih Ayam
Isis Utom
Aqseq Iöam
Nip Axom
Amuz Asu
Uïn Oj
Oïqat Oiz
Qat Aqi
Uäm Itit
Ixiz Nin
Uöy Iqot
Alamob Nuqes
Emuüf Atur
Nigo O
Uög Oj
Aniïl Ayam
Eq Nupup
Aqot Imav
Uqas Ali
Ataq Aluq
Eïb Usus
Es Oxe
Oïm Ayo
Netiz Net
Iqato Ayam
Asiq Ulqam
Aqlaqin Atanis
Uïx Itoj
Niq Oxi
Anar Usis
Netam Net
Agihi Itoj
Alus Aqam
Uïsin Onoyq
Aqau Amit
Uäs Noj
Aqau Isal
Alas Inaduq
Uü Ujoj
Oïnis Oiz
Isisin Atag
Uqnol Omeriautcnas
Aqlaq Atenim
'''
# Lynel entries from public field index; spawn variants can change with game progression.
LYNEL_RAW='''
Lynel|-3378,0030,0105|Surface
Lynel|-2170,1552,0226|Surface
Lynel|-2799,1840,0315|Surface
Lynel|-1554,0138,0119|Surface
Lynel|3681,2959,0039|Surface
Lynel bleu|-4536,2683,0236|Surface
Lynel bleu|-1463,-2708,0152|Surface
Lynel bleu|-0590,-3834,0062|Surface
Lynel bleu|0098,-3367,0018|Surface
Lynel bleu|1996,-0307,0022|Surface
Lynel bleu|2501,-0519,0125|Surface
Lynel bleu|2661,-0946,0232|Surface
Lynel blanc|-4445,-0989,0511|Surface
Lynel blanc|1464,-3036,0215|Surface
Lynel blanc|3877,0951,0256|Surface
Lynel (blindé)|-1439,-1262,-0464|Profondeurs
Lynel (blindé)|0253,-1187,-0453|Profondeurs
Lynel|-1167,-1321,-0478|Profondeurs
Lynel bleu|-1109,-1305,-0478|Profondeurs
Lynel bleu (blindé)|-2799,-2238,-0462|Profondeurs
Lynel bleu (blindé)|1041,1124,-0454|Profondeurs
Lynel bleu (blindé)|1585,-3496,-0491|Profondeurs
Lynel bleu (blindé)|2604,1145,-0575|Profondeurs
Lynel bleu (blindé)|3150,1693,-0626|Profondeurs
Lynel bleu (blindé)|4212,2721,-0551|Profondeurs
Lynel blanc|-0246,0792,-1059|Profondeurs
Lynel blanc|-1207,-1278,-0478|Profondeurs
Lynel blanc (blindé)|-1603,2523,-0660|Profondeurs
Lynel blanc (blindé)|-1224,0764,-0530|Profondeurs
Lynel blanc (blindé)|0500,-3457,-0479|Profondeurs
Lynel blanc (blindé)|1761,-1926,-0443|Profondeurs
Lynel d'argent|-1097,-1249,-0478|Profondeurs
Lynel d'argent (blindé)|1084,-0267,-0446|Profondeurs
Lynel d'argent (blindé)|-1192,-1222,-0478|Profondeurs
'''

def parse_xyz(s):return [int(t) for t in s.split(',')]
def parse_shrines():
 lines=SHRINE_RAW.strip().splitlines(); assert len(lines)==152,len(lines)
 return [{'id':f'shrine_{i+1}','name':'Sanctuaire '+(line.split('|')[0]),'type':'Sanctuaire','layer':'Ciel' if i>=120 else 'Surface','xyz':parse_xyz(line.split('|')[1])} for i,line in enumerate(lines)]
def parse_roots(shrines):
 names=ROOT_NAMES.strip().splitlines();assert len(names)==120,len(names)
 # XY matching is approximate: surfaced sanctuaries and depths roots may differ a few metres.
 return [{'id':f'root_{i+1}','name':'Racine '+n,'type':'Racine','layer':'Profondeurs','xyz':[shrines[i]['xyz'][0],shrines[i]['xyz'][1],None], 'approx':True} for i,n in enumerate(names)]
def parse_lynels():
 lines=LYNEL_RAW.strip().splitlines();assert len(lines)==34,len(lines)
 return [{'id':f'lynel_{i+1}','name':a.split('|')[0], 'xyz':parse_xyz(a.split('|')[1]), 'layer':a.split('|')[2], 'type':'Lynel'} for i,a in enumerate(lines)]

QUESTS_MAIN='''
À la recherche de Zelda
Abattre Ganondorf
Babil, du Village Piaf
Des gens dans les profondeurs ?
Enquêtes régionales
Étrange phénomène au château
Impa et les géoglyphes
La gravure cassée
La lame perdue du héros
La piste vers le ciel
La porte close
La statue couverte de vase
La voix venue du passé
Le cinquième Sage
Le secret des vestiges circulaires
Le temple des profondeurs
Les larmes du dragon
Pour restaurer l'armure zora
Retour en Hyrule
Riju, de la Cité Gerudo
Sidon, du domaine Zora
Sur les traces de l'épée de légende
Yunobo, du Village Goron
'''
QUESTS_ADVENTURES='''
À la pointe du long dragon
Activer l'amulette de téléportation
Activer le mode empreinte
En présence de six dragons
En quête du cristal d'Elusis
En quête de vérité !
Entre les deux dragons
Fouille des Ruines des Obscurcies
Goutiée ou Baldinn ?
Infiltration chez les Yigas
Invasion de pirates !
L'appel des profondeurs
L'enlèvement de Zelda ?!
L'examen d'officier yiga
L'Île céleste du Prélude
L'oracle cocotte
La danse des abeilles
La princesse chevauchant une bête
La voix du démon
Le cheval doré de Zelda
Le collectionneur de monstres 1
Le collectionneur de monstres 2
Le collectionneur de monstres 3
Le collectionneur de monstres 4
Le collectionneur de monstres 5
Le départ de Tinieh
Le détecteur encyclopédique
Le grand débat
Le joueur de flûte des alpages
Le laboratoire Pru'ha d'Elimith
Le puits hors service
Le sauvetage du joueur de cor
Le secret de Baldinn
Le secret de Goutiée
Les chèvres en fuite
Les ennuis de Noïa
Les gourmets n'arrivent pas
Les malheurs de Naye
Les outils disparus
Les pérégrinations de Koltin
Les plans du Grand Kohga
Négociations diaboliques
Pacification d'Akkala
Pacification d'Hébra
Pacification d'Ordinn
Pacification de Firone
Pacification de la plaine
Pacification de Necluda
Personne en détresse
Pour l'amour de la princesse
Reconstruction d'Écaraille
Sérénade pour Caesa
Sérénade pour Cotura
Sérénade pour Mijah
Sérénade pour une grande fée
Sous la garde des dragons
Tout un fromage !
Un message des temps anciens
Un sinistre chant
Votre encyclopédie personnelle
'''
QUESTS_SHRINE='''
À dos de géant
En noir et blanc
L'oiseau blanc et la grotte
La jolie pierre et les pommes
La légende de la source et des anneaux
La légende du javelot
Le refuge de Makus
Le sanctuaire céleste d'Akkala sud
Le sanctuaire céleste d'Hébra est
Le sanctuaire céleste d'Hyrule nord
Le sanctuaire céleste d'Hyrule sud
Le sanctuaire céleste de Lanelle sud
Le sanctuaire céleste de Necluda
Le sanctuaire céleste de Necluda nord
Le sanctuaire céleste de Necluda ouest
Le sanctuaire céleste de Tabanta
Le sanctuaire d'Hébra nord
Le sanctuaire d'Hébra ouest
Le sanctuaire de l'île de la Carrière
Le sanctuaire de la caldeira de la Mort
Le sanctuaire de la veine de Lars
Le sanctuaire de Lanelle
Le sanctuaire du canyon Gerudo
Le sanctuaire du cratère d'Oriolo
Le sanctuaire du lac de Torgol
Le sanctuaire du lac Hylia
Le sanctuaire du lac Nêche
Le sanctuaire du mont Satori
Les clés nées de l'eau
On ne passe pas !
Un rocher à vendre
'''
QUESTS_MISSIONS='''
À l'épreuve de la chaleur
À l'épreuve du froid
À la chasse à l'Hinox
À la chasse au Lithorok
À la chasse au Moldarquor
À la recherche du paradis
Adieu les virevoltants
Angoisses nocturnes
Au secours de Peiffa
Barricadés dans la cabane
Bienvenue à Wagoland !
Brise-montagne, l'âme des Gorons
Conduis-moi jusqu'aux ruines
Couvert de vase
D'un coup d'un seul
Décorer le nouveau relais de Delass
Décorer le relais de l'est d'Akkala
Décorer le relais de l'orée de la plaine
Décorer le relais de forêt
Décorer le relais de la rivière
Décorer le relais des alpages
Décorer le relais des Géminés
Décorer le relais des marécages
Décorer le relais des prairies gelées
Décorer le relais du canyon Gerudo 1
Décorer le relais du canyon Gerudo 2
Décorer le relais du lac
Décorer le relais du pied de la montagne
Décorer le relais du pont de Tabanta
Décorer le relais du sud d'Akkala
Des champignons brillants
Des glaçons pour la glacière
Des provisions convoitées
Des viscères de Griock
En plein dans le puits
Et il triompha de toutes les épreuves
L'âme à l'héroïsme véritable
L'Arc de l'aigle des Piafs
L'aubergiste disparu
L'écurie inachevée
L'épouse montée au ciel
L'impératrice disparue
L'acheteuse d'ambre
L'arme ultime
L'artéfact soneau maîtrisé
L'énorme silhouette mystérieuse
La cachette dans l'Arbre Mojo
La chasse aux trésors de Cernus
La chemise bleue de Papa
La cité antique de Gorondia !
La cité antique de Gorondia ?
La fierté d'Elimith
La fierté des Gerudos
La grotte bloquée
La horde de pirates
La jument perdue
La lance d'écailles radieuse
La meilleure stratégie
La nouvelle attraction d'Écaraille
La pierre bleue
La princesse zora au clair de lune
La prophétie d'Edal - Sud
La prophétie d'Edal - Nord
La prophétie de l'Île d'Edal
La propriétaire disparue
La requête de Mohino
La statue de la source de la Force
La statue de la source de la Sagesse
La statue de la source du Courage
La statue matriarche
La tente accaparée
La tenue du Dieu démon
Lames ancestrales des profondeurs
Le bateau à la dérive
Le caravanier disparu
Le défi de Tiklama
Le désir secret d'Hamel
Le fort du Plateau de Jarbu
Le Grand fossile d'Hébra
Le Grand fossile d'Ordinn
Le Grand fossile du désert
Le mal des miasmes
Le menu du jour
Le mineur abandonné
Le mystérieux géant du ciel
Le mystérieux monstre à trois têtes
Le plat maison de Ghenkott
Le plat ultime... ?
Le potager de Florène
Le projet de Lorelo
Le rallye d'Euzero
Le repaire des pirates
Le secret des héroïnes
Le trésor caché du Désert Gerudo
Le trésor de rêve de Lambda 1
Le trésor de rêve de Lambda 2
Le trésor de rêve de Lambda 3
Le trésor des étangs lézards
Le trésor dormant des sources
Le trésor du poisson géant
Les animaux de Tabos
Les bains secrets
Les cercles qui tournent
Les dalles ancestrales
Les égarés du Canyon Gerudo
Les Gorons et la lune
Les joies de l'enseignement
Les joies de l'enseignement 2
Les œufs des Cocottes
Les trois frères des grottes
Notre trésor
Nouvel entraînement piaf
Objectif : cocottes !
On ne gâche pas la viande !
Parcours expert
Parcours intermédiaire
Passion déco
Pour l'amour des puits
Qu'est-ce qu'il y a dedans ?
Remontrances sans fin
Rhodo, maître crémier
Si j'avais un chariot
Sus au trésor de Lambda
Traversée en eaux froides
Trésor de Lambda : les héroïnes
Trésor de Lambda : les jumeaux
Trésor de Lambda : les pirates
Troc chez les Piafs
Un généreux trésor
Un gigot de caillasse ou rien !
Un modèle de Chuchu
Un pont à réparer
Un silex au goût riche
Un symbole d'amitié
Un village en détresse
Une bouteille à la mer
Une crabuleuse affaire
Une maison de rêve
Une nouvelle tunique de Prodige
'''

def parse_quests():
 groups=[('main','Quêtes principales',QUESTS_MAIN,23),('adventures','Quêtes secondaires',QUESTS_ADVENTURES,60),('shrine','Quêtes de sanctuaire',QUESTS_SHRINE,31),('missions','Missions',QUESTS_MISSIONS,139)]
 ret=[]
 for id_,label,data,target in groups:
  lines=data.strip().splitlines()
  assert len(lines)==target,(id_,len(lines),target)
  ret+= [{'id':id_+'_'+str(i+1),'name':name,'group':id_,'category':label,'no':i+1} for i,name in enumerate(lines)]
 assert len(ret)==253
 return ret
# Exact root XYZ coordinates from same game map index, in its corresponding shrine order.
ROOT_XYZ_RAW='''
0343,-1008,-0468
4347,2877,-0606
2368,2597,-0940
-3078,1617,-0683
-0706,-0868,-0481
0407,2134,-0590
0757,0824,-0531
-3354,2386,-0797
-3406,-1364,-0774
-4638,-1512,-0883
-0178,1170,-0515
3298,0420,-0744
3470,-2182,-0592
0868,-2277,-0555
-3539,0852,-0574
-3883,-2963,-0435
1269,3733,-0552
4512,2115,-0454
-1638,2642,-0682
-1416,0757,-0537
-4538,2880,-0703
0916,-0252,-0481
0698,2793,-0668
-2440,-3343,-0465
-3487,-0215,-0515
-1442,-1616,-0537
4233,-2177,-0521
-1168,2602,-0353
-0879,0423,-0497
-1107,2089,-0552
1063,1281,-0495
-1081,-2186,-0560
-3729,-3625,-0494
2568,1247,-0598
-1404,3678,-0708
-4154,0098,-0489
-2656,-2238,-0488
-3653,1807,-0418
3785,0578,-0918
-1423,-1352,-0517
3431,3358,-0520
0221,1084,-0474
-3291,-2511,-0476
-0785,-0433,-0470
3886,-0216,-0606
3304,1443,-0785
-0397,2735,-0721
2401,3276,-0838
0671,-3358,-0484
4267,-1673,-0626
-1531,-2929,-0727
-1922,-0360,-0633
1763,2511,-0715
-2529,1170,-0620
-4058,1989,-0671
-0708,-1551,-0516
-2318,2201,-0776
-3508,3569,-0820
1842,2843,-0832
3061,1825,-0660
-4470,-0672,-0940
1219,-2544,-0610
-0179,-1559,-0474
-2525,-1770,-0709
-2037,-1852,-0504
4167,1322,-0670
3525,-1482,-0610
1201,0330,-0573
2825,-3269,-0526
-4390,3714,-0699
-4681,-3086,-0503
2865,3639,-0681
2961,2758,-0955
4655,3732,-0382
-1829,1196,-0719
0103,-2519,-0415
4413,-0612,-0513
3728,-2059,-0662
-1795,-3498,-0457
2276,0150,-0501
2680,1904,-0685
-2138,-0875,-0541
2918,0508,-0790
1835,3181,-0831
-3952,1140,-0550
-3211,-3006,-0471
0355,1893,-0623
2303,-2379,-0615
0167,2321,-0623
-2998,3101,-0997
2756,-1088,-0548
3346,-1186,-0608
4630,-3712,-0505
0622,2211,-0609
3093,-3209,-0622
-4158,-3826,-0478
2360,-0510,-0587
0350,-2052,-0471
1563,-1945,-0464
0334,0469,-0479
-0074,-1116,-0472
-0850,3535,-0614
-2846,0630,-0619
3841,2300,-0488
0930,-1904,-0460
-0564,-3524,-0573
-2559,3354,-0686
-0595,1550,-0597
3812,1219,-0536
1769,-1053,-0606
-0204,0451,-0472
1800,1640,-0745
1743,0018,-0460
4664,3264,-0454
-4169,-2142,-0487
1514,-3578,-0529
-0240,-0372,-0478
4497,0827,-0534
1181,-0779,-0500
0394,3484,-0593
'''

def parse_roots(shrines):
 names=ROOT_NAMES.strip().splitlines();coords=ROOT_XYZ_RAW.strip().splitlines()
 assert len(names)==len(coords)==120,(len(names),len(coords))
 return [{'id':f'root_{i+1}','name':'Racine '+n,'type':'Racine','layer':'Profondeurs','xyz':parse_xyz(coords[i])} for i,n in enumerate(names)]

WELL_RAW='''
Puits du col de Pigar|-3832,2105,0135
Puits du village de Tabanta|-2359,1872,0270
Puits de la place de Delass|-1811,1623,0102
Puits de la plaine de Stulys|-1069,2326,0109
Puits de la plaine de Betula|-0911,1616,0101
Puits du mont Ulmus|-0671,1352,0083
Puits du pont de Caroc|-1040,0415,0031
Puits du mont Gustave|-0913,0331,0016
Puits du mont Daphnès|-1314,-0623,0006
Puits du lac Aquam|-0879,-1102,0018
Puits du relais de l'orée|-1461,-1297,0029
Puits de la colline de l'orée|-1681,-1349,0116
Puits du mont Nabooru|-1720,-2238,0032
Puits du hameau de Rauru|0662,1267,0036
Puits de la citadelle|0063,0548,0024
Puits de la cité des Mouettes|-0068,-0163,0021
Puits du pont de Rébona|0787,0008,0027
Puits de l'étang sans fond|0686,-0766,0014
Puits du lac Nabi méridional|0783,-1497,0032
Puits nord d'Adeya|0317,-1857,0006
Puits du village d'Adeya|0322,-1927,0007
Puits est d'Adeya|0423,-2043,0006
Puits sud d'Adeya|0340,-2099,0024
Puits des hauteurs d'Huko|0316,-2128,0041
Puits nord des Peuliers|0594,-2100,0088
Puits sud des Peuliers|0606,-2261,0047
Puits du camp des landes|1544,0170,0006
Puits de l'île de Sazu|1436,-0136,0007
Puits du hameau des Anémones|1529,-0327,0007
Puits des marécages de Lanelle|1220,-0397,0007
Puits des collines de Lorico|1716,-0651,0020
Puits du morne Bois|2746,0176,0125
Puits du hameau de Malficio|3057,2311,0325
Puits du bazar Assek|-3235,-2606,0020
Puits du village d'Écaraille|2941,-3378,0008
Puits du relais du lac|1535,-3554,0058
Puits du relais des alpages|0538,-3427,0045
Puits du relais des prairies gelées|-1680,2586,0229
Puits du canyon Gerudo|-2820,-2233,0027
Puits du relais de la rivière|0365,-1126,0008
Puits du relais des marécages|0885,-0195,0024
Puits sud du relais des marécages|0858,-0263,0024
Puits du relais des Géminés|1795,-1950,0009
Puits nord d'Elimith|3422,-2030,0134
Puits ouest d'Elimith|3357,-2050,0114
Puits est d'Elimith|3514,-2152,0125
Puits sud d'Elimith|3385,-2212,0132
Puits de chez Zelda|3301,-2301,0127
Puits du relais de Delass|-1357,0700,0073
Puits de Cocorico|1875,-1044,0120
Puits du relais de la forêt|1093,1154,0020
Puits du fort de guet|-0212,0135,0017
Puits du pied de la montagne|2618,1169,0144
Puits du chantier|3720,1588,0088
Puits du relais du sud d'Akkala|3195,1716,0196
Puits du relais de l'est d'Akkala|4233,2780,0122
Puits de l'étang de Raille|0395,-3387,0044
Puits du relais du pont|-2959,0532,0165
'''
TOWER_RAW='''
Tour du fort de guet|-0299,0143,0030
Tour du mont Labulat|-1910,1245,0297
Tour de la prairie d'Urban|-2311,3062,0441
Tour du ravin d'Ordinn|1642,1191,0227
Tour du mont Ramol|3499,2026,0190
Tour de la plaine de Sahasla|1341,-1178,0169
Tour du plateau Zoran|2866,0581,0379
Tour de la plaine d'Hyrule|-0761,-1019,0069
Tour du canyon Gerudo|-2439,-2183,0307
Tour des hauteurs Gerudos|-3961,-1306,0421
Tour de Rabelle|2420,-2755,0224
Tour des ruines des Obscurcies|0344,3142,0182
Tour des Peuliers|0605,-2127,0103
Tour de la montagne de Lanelle|3848,-1315,0535
Tour du col de Térel|-3680,2346,0235
'''
TEAR_RAW='''
Larme du dragon n°1|-1413,0966,0134
Larme du dragon n°2|-2551,1889,0326
Larme du dragon n°3|1828,0738,0101
Larme du dragon n°4|0695,-1309,0065
Larme du dragon n°5|-3178,-1700,0424
Larme du dragon n°6|-3096,-0077,0220
Larme du dragon n°7|3326,-3566,0017
Larme du dragon n°8|-1864,3622,0245
Larme du dragon n°9|4468,-0305,0086
Larme du dragon n°10|-0649,-2683,0080
Larme du dragon n°11|0892,2952,0369
Larme du dragon n°12|4535,2144,0013
'''
def parse_simple_raw(data,prefix,type_,layer):
 lines=data.strip().splitlines();return [{'id':f'{prefix}_{i+1}','name':s.split('|')[0],'xyz':parse_xyz(s.split('|')[1]),'type':type_,'layer':layer} for i,s in enumerate(lines)]
def parse_wells():
 p=parse_simple_raw(WELL_RAW,'well','Puits','Surface');assert len(p)==58,len(p);return p
def parse_towers():
 p=parse_simple_raw(TOWER_RAW,'tower','Tour','Surface');assert len(p)==15,len(p);return p
def parse_tears():
 p=parse_simple_raw(TEAR_RAW,'tear','Larme du dragon','Surface');assert len(p)==12,len(p);return p
