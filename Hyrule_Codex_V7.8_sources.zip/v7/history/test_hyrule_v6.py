import asyncio, json, re
from pathlib import Path
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  ctx=await browser.new_context(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True,accept_downloads=True)
  pg=await ctx.new_page();errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  await pg.set_content(Path('/mnt/data/hyrule_codex_v6/index.html').read_text(),wait_until='domcontentloaded')
  await pg.wait_for_timeout(280)
  assert not errors,errors
  counts=await pg.evaluate('''() => ({atlas:ATLAS.length,bosses:V6_BOSS_PLACES.length,old:ATLAS.filter(x=>/^a\\d+$/.test(x.id)).length,types:Object.fromEntries([...new Set(V6_BOSS_PLACES.map(x=>x.type))].map(y=>[y,V6_BOSS_PLACES.filter(x=>x.type===y).length]))})''')
  assert counts['atlas']==640,counts
  assert counts['bosses']==283,counts
  assert counts['old']==0,counts
  assert counts['types']=={'Lynel':34,'Lithorok':87,'Hinox':69,'Gigatracien':40,'Golemax':35,'Griock':14,'Moldarquor':4},counts
  print('COUNTS',counts)
  for tab in ['home','bosses','searchall','bestiary','farming','inventory','atlas','fusion','catalogue','photodex','weapons','armor','guides','assistant','goals','quests','collections','fullmap']:
   await pg.locator(f'#mobile-nav [data-tab="{tab}"]').click(force=True)
   assert await pg.locator('#screen-'+tab).is_visible(),tab
   if tab=='home':
    assert await pg.locator('#v6-enter').count()==1
   elif tab=='bosses':
    assert await pg.locator('.v6-family').count()==7
    assert '283' in await pg.locator('.v6-banner').inner_text()
    await pg.locator('[data-v6-select="Griock"]').click(force=True)
    assert '14 positions' in await pg.locator('.v6-head').inner_text()
    await pg.locator('#v6-layer').select_option('Ciel')
    assert '3 positions' in await pg.locator('.v6-head').inner_text()
    await pg.locator('[data-v6-open]').first.click(force=True)
    assert 'https://www.gamertw.com/fr/zelda/totk/gleeok' in await pg.locator('#modalroot').inner_html()
    await pg.locator('#close-detail').click(force=True)
    await pg.locator('[data-v6-check]').first.click(force=True)
    assert '1' in await pg.locator('.v6-banner').inner_text()
    await pg.locator('#v6-layer').select_option('Toutes')
    await pg.locator('[data-v6-select="Gigatracien"]').click(force=True)
    assert '40 positions' in await pg.locator('.v6-head').inner_text()
    await pg.locator('[data-v6-select="Lithorok"]').click(force=True)
    assert '87 positions' in await pg.locator('.v6-head').inner_text()
    await pg.locator('#v6-search').fill('-3387')
    assert '1 positions' in await pg.locator('.v6-head').inner_text() or '2 positions' in await pg.locator('.v6-head').inner_text()
    await pg.locator('#v6-search').fill('')
   elif tab=='atlas':
    assert '640' in await pg.locator('#screen-atlas').inner_text()
    await pg.locator('#atlas-type').select_option('Griock')
    await pg.locator('#atlas-search').fill('-4471')
    assert await pg.locator('[data-open-atlas]').count()==1
   elif tab=='searchall':
    await pg.locator('#v5-global-search').fill('Moldarquor')
    assert await pg.locator('.v5-searchrow').count()>=4
   elif tab=='quests':assert '253' in await pg.locator('#screen-'+tab+' .v5-feature').inner_text()
   elif tab=='collections':assert '152' in await pg.locator('#screen-'+tab+' .v5-feature').inner_text()
   size=await pg.evaluate('({w:document.documentElement.scrollWidth,inner:window.innerWidth})')
   assert size['w']<=size['inner']+2,(tab,size)
   print('tested',tab)
  assert not errors,errors
  await pg.locator('#mobile-nav [data-tab="bosses"]').click(force=True)
  await pg.locator('#v6-search').fill('')
  await pg.locator('[data-v6-select="Lynel"]').click(force=True)
  await pg.screenshot(path='/mnt/data/Hyrule_Codex_V6_apercu_iPhone.png',full_page=False)
  await browser.close()
  print('ALL PASSED no JS pageerror',errors)
asyncio.run(main())
