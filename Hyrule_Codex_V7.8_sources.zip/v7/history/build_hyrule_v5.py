from pathlib import Path
import json, re, shutil, zipfile, datetime, sys
sys.path.insert(0,'/mnt/data')
from hyrule_v5_data import parse_shrines,parse_roots,parse_lynels,parse_quests,parse_wells,parse_towers,parse_tears
base=Path('/mnt/data/hyrule_codex_v4')
out=Path('/mnt/data/hyrule_codex_v5');out.mkdir(exist_ok=True)
for f in ['icon-192.png','icon-512.png','apple-touch-icon.png']:shutil.copy2(base/f,out/f)
html=(base/'index.html').read_text()
sha=parse_shrines();roots=parse_roots(sha);lynels=parse_lynels();wells=parse_wells();towers=parse_towers();tears=parse_tears();quests=parse_quests()
assert (len(sha),len(roots),len(lynels),len(quests))==(152,120,34,253)
data_js='\n'.join('const '+name+'='+json.dumps(data,ensure_ascii=False,separators=(',',':'))+';' for name,data in [('V5_SHRINES',sha),('V5_ROOTS',roots),('V5_LYNELS',lynels),('V5_WELLS',wells),('V5_TOWERS',towers),('V5_TEARS',tears),('V5_QUESTS',quests)])
extra=Path('/mnt/data/hyrule_v5_extras.js').read_text()
extra += '''
navs.splice(1,0,['searchall','⌕','Tout chercher']);
navs.splice(5,0,['collections','🌿','Collection 100 %']);
navs.splice(6,0,['quests','📜','253 quêtes']);
navs.splice(7,0,['fullmap','🌍','Carte totale']);
const V5_originalHome=renderHome;
renderHome=function(){
  V5_originalHome();
  const cards=`<div class="v5-homegrid">
  <button data-v5home="searchall"><span>⌕</span><b>Recherche globale</b><small>La fonction la plus rapide pour trouver une arme, un boss, une quête ou une ressource.</small></button>
  <button data-v5home="quests"><span>📜</span><b>253 quêtes nommées</b><small>23 principales, 60 secondaires, 31 sanctuaires, 139 missions, en français.</small></button>
  <button data-v5home="collections"><span>🌿</span><b>Objectif 100 %</b><small>152 sanctuaires, 120 racines, 900 énigmes Korogu et bien plus.</small></button>
  <button data-v5home="fullmap"><span>🌍</span><b>Carte d’Hyrule</b><small>La carte intégrale externe et les coordonnées intégrées à l’atlas.</small></button></div>`;
  el('screen-home').insertAdjacentHTML('afterbegin',cards);
  el('screen-home').querySelectorAll('[data-v5home]').forEach(b=>b.onclick=()=>goto(b.dataset.v5home));
};
'''
html=html.replace('<title>Hyrule Codex V4', '<title>Hyrule Codex V5').replace('✦ V4 autonome','✦ V5 enrichie').replace('· Version 4 ·','· Version 5 ·')
html=html.replace('Gratuit · Sauvegarde locale · V4','Gratuit · Sauvegarde locale · V5')
html=html.replace('Hyrule Codex V4 : atlas des boss, farming, butins, armes, amalgame et progression pour Zelda', 'Hyrule Codex V5 : 253 quêtes, sanctuaires, racines, boss, butins, armes, amalgame et progression pour Zelda')
html=html.replace("window.scrollTo({top:0,behavior:'smooth'});","window.scrollTo({top:0,behavior:'auto'});")
html=html.replace('Nouvelle version : sac à butin, suivi du recueil et compteurs de progression. Gratuit, sans compte ni paiement.','Nouvelle version : recherche globale, 253 quêtes, 152 sanctuaires, 120 racines, 34 Lynels et suivi des collections. Toujours gratuit.')
html=html.replace('const fn={home:renderHome,','const fn={home:renderHome,quests:renderQuests,collections:renderCollections,fullmap:renderFullMap,searchall:renderSearchAll,')
html=html.replace("if(state.tab==='photodex')renderPhotodex()", "if(state.tab==='photodex')renderPhotodex();if(state.tab==='searchall')renderSearchAll()")
html=html.replace("({Lynel:'🦁',Griock:","({Sanctuaire:'⛩️',Racine:'🌱',Lynel:'🦁',Griock:")
html=html.replace('Coordonnées XYZ de '+"'+ATLAS.length+'", 'Coordonnées XYZ de '+"'+ATLAS.length+'") # no-op
# Improve existing atlas explanation (new named sources included).
html=html.replace('rencontres et géoglyphes sélectionnés, avec suivi individuel.', 'rencontres, sanctuaires, racines et géoglyphes, avec suivi individuel.')
html=html.replace('<section id="screen-home"></section>','<section id="screen-home"></section><section class="hidden" id="screen-searchall"></section><section class="hidden" id="screen-collections"></section><section class="hidden" id="screen-quests"></section><section class="hidden" id="screen-fullmap"></section>')
html=html.replace("'hyrule-codex-v4-sauvegarde.json'","'hyrule-codex-v5-sauvegarde.json'")
html=html.replace('JSON.stringify({version:4,inventory:','JSON.stringify({version:5,questDone:state.questDone||{},collectDone:state.collectDone||{},collectNotes:state.collectNotes||{},inventory:')
html=html.replace('/^a[0-9]+$/.test(key)',r'/^(?:a[0-9]+|shrine_[0-9]+|root_[0-9]+|lynel_[0-9]+)$/.test(key)')
html=html.replace("save();render();toast('Progression importée')", """if(t.questDone&&typeof t.questDone==='object'&&!Array.isArray(t.questDone))state.questDone=Object.fromEntries(Object.entries(t.questDone).filter(([k,v])=>/^(main|adventures|shrine|missions)_[0-9]{1,3}$/.test(k)&&v===true).slice(0,253));if(t.collectDone&&typeof t.collectDone==='object'&&!Array.isArray(t.collectDone))state.collectDone=Object.fromEntries(Object.entries(t.collectDone).filter(([k,v])=>/^(korok|cave|well|tower|tear|sage|addison|chasm|dispenser|tablet|recipe)_[0-9]{1,4}$/.test(k)&&v===true).slice(0,2500));if(t.collectNotes&&typeof t.collectNotes==='object'&&!Array.isArray(t.collectNotes))state.collectNotes=Object.fromEntries(Object.entries(t.collectNotes).filter(([k,v])=>/^(korok|cave|well|tower|tear|sage|addison|chasm|dispenser|tablet|recipe)_[0-9]{1,4}$/.test(k)&&typeof v==='string').slice(0,2500).map(([k,v])=>[k,v.slice(0,120)]));save();render();toast('Progression importée')""")
style=r'''
/* V5: journal, atlas complet, recherche et collection tactile. */
.v5-feature{display:flex;align-items:center;justify-content:space-between;gap:18px;padding:21px 23px;margin:14px 0 20px;background:linear-gradient(115deg,#23463f,#142d37 70%);border:1px solid #64806d;border-radius:21px;min-height:125px}
.v5-number{font-weight:850;font-size:43px;line-height:1.15;color:#f9df9d;display:block;margin:8px 0 6px}.v5-number small{font-size:18px;color:#b7d1cb}.v5-ring{--p:0%;width:85px;height:85px;flex:0 0 85px;border-radius:50%;background:conic-gradient(#e2ba70 var(--p),#284740 var(--p));display:grid;place-items:center;position:relative}.v5-ring:before{content:'';background:#1b3635;position:absolute;inset:8px;border-radius:50%}.v5-ring span{position:relative;color:#f7ddb4;font-size:15px;font-weight:900}
.v5-pills{display:flex;flex-wrap:wrap;gap:7px;margin:14px 0}.v5-pill{padding:10px 14px;min-height:44px;border:1px solid #47605d;border-radius:11px;background:#182e34;color:#c4d6d0;font-weight:700;text-align:left}.v5-pill small{font-size:11px;color:#b5e5d5;margin-left:4px}.v5-pill.active,.v5-group.active{background:#bda06b;color:#182428;border-color:#eed3a1}.v5-pill.active small{color:#183630}
.v5-toolbar{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:12px;align-items:center;margin:15px 0}.v5-toolbar .search{width:100%}.v5-check{display:flex;gap:7px;align-items:center;white-space:nowrap;font-size:12px;color:#c8d9d4}.v5-check input,.v5-row input{accent-color:#e2ba70;width:19px;height:19px}.v5-progress{height:7px;background:#243e42;border-radius:999px;margin:8px 0 18px;overflow:hidden}.v5-progress i{display:block;height:100%;background:#e2ba70;border-radius:inherit}
.v5-list{display:flex;flex-direction:column;gap:8px}.v5-row{border:1px solid #2e4a4c;background:#132831;border-radius:12px;padding:12px 14px;display:flex;align-items:center;gap:13px;min-height:64px;cursor:pointer}.v5-row:hover{border-color:#75938c}.v5-row.v5-done{background:#1b3732;border-color:#526c55}.v5-row-text{flex:1;min-width:0}.v5-row-text strong{font-size:13px;line-height:1.45;display:block}.v5-row-text small{font-size:11px;color:#94b7ae;margin-top:4px;display:block;overflow-wrap:anywhere}.v5-done .v5-row-text strong{text-decoration:line-through;color:#b6c6ae}.v5-checkmark{color:#bbd1c2;font-size:19px}.v5-tick{display:flex;gap:6px;align-items:center;flex:0 0 auto}.v5-tick span{font-size:19px;color:#e6c686}.v5-smallbtn{border:1px solid #57726b;color:#e3c68d;background:#23403d;border-radius:9px;min-width:43px;min-height:43px;font-size:19px}
.v5-group-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin:17px 0}.v5-group{display:grid;grid-template-columns:35px 1fr;grid-template-rows:auto auto;gap:3px 7px;padding:11px 10px;border:1px solid #405959;background:#142931;color:#e7ede6;border-radius:12px;text-align:left;align-items:center}.v5-group span{grid-row:1/3;font-size:22px}.v5-group b{font-size:11px;line-height:1.25}.v5-group small{font-size:10px;color:#a6c5bb}.v5-group.active small{color:#203d37}.v5-linkbar{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:12px 0 16px;flex-wrap:wrap}.v5-pager{display:flex;gap:12px;align-items:center;justify-content:center;margin:20px auto}.v5-pager span{font-weight:700;font-size:12px;color:#e9d7b3}
.v5-bigsearch{display:flex;width:100%;padding:7px 13px;font-size:19px;margin:16px 0}.v5-bigsearch input{font-size:18px;width:100%}.v5-searchrow{min-height:66px;border:1px solid #385558;border-radius:12px;background:#152c32;display:flex;gap:11px;align-items:center;text-align:left;color:#f0efe5;padding:11px 13px}.v5-searchrow:hover{border-color:#e2ba70}.v5-searchico{font-size:23px;flex:0 0 35px;text-align:center}.v5-searchrow span:nth-child(2){flex:1;min-width:0}.v5-searchrow b{display:block;line-height:1.4;font-size:14px}.v5-searchrow small{color:#a7bdb9;font-size:11px;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;margin-top:3px}.v5-searchrow em{font-size:22px;color:#d2b77b}
.v5-homegrid{display:grid;grid-template-columns:repeat(2,1fr);gap:11px;margin:0 0 23px}.v5-homegrid button{display:flex;flex-direction:column;align-items:flex-start;text-align:left;border:1px solid #8a805852;background:linear-gradient(120deg,#2f493f,#172d36);color:#f5f0df;border-radius:15px;padding:17px;min-height:123px}.v5-homegrid button:hover{border-color:#e2ba70}.v5-homegrid span{font-size:28px;color:#e2ba70;margin-bottom:7px}.v5-homegrid b{font-size:15px}.v5-homegrid small{margin-top:5px;color:#b9cfc6;line-height:1.35;font-size:11px}
.v5-maptiles{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:13px;margin:22px 0}.v5-maplink{border:1px solid #48615d;border-radius:15px;background:linear-gradient(140deg,#25433c,#162b34);color:#f5e4c3!important;display:flex;flex-direction:column;align-items:flex-start;gap:10px;padding:21px;min-height:151px;text-decoration:none}.v5-maplink strong{font-size:18px}.v5-maplink small{font-size:12px;color:#bed0c6;line-height:1.4}.v5-maplink>span{font-size:12px;margin-top:auto;font-weight:800;color:#8ce1c3}
@media(max-width:1020px){.v5-group-grid{grid-template-columns:repeat(3,1fr)}}
@media(max-width:600px){.v5-feature{padding:15px 16px;min-height:110px}.v5-number{font-size:36px}.v5-ring{width:75px;height:75px;flex-basis:75px}.v5-group-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}.v5-toolbar{grid-template-columns:1fr;gap:8px}.v5-check{margin-bottom:4px}.v5-maptiles{grid-template-columns:1fr;gap:9px}.v5-maplink{min-height:130px}.v5-homegrid{gap:8px}.v5-homegrid button{padding:13px;min-height:145px}.v5-homegrid b{font-size:13px}.v5-homegrid small{font-size:11px}.v5-row{padding:11px 9px;gap:9px}.v5-row-text strong{font-size:12px}.v5-row input{width:17px;height:17px}.v5-pill{font-size:12px}.v5-group{padding:9px}.v5-group b{font-size:10px}}
'''
html=html.replace('</style>',style+'</style>')
# Add the data and JS before init() at end, not before definitions used by V4.
assert html.count('\ninit();\n')==1
html=html.replace('\ninit();\n','\n'+data_js+'\n'+extra+'\ninit();\n')
# Rewrite footer correctly to disclose coverage and external deps.
html=html.replace('V5 enrichie : 95 fiches françaises, atlas à coordonnées et guide de fusion. Le compendium en ligne est complémentaire ; aucune fiche prétend couvrir toutes les quêtes.', 'V5 : 253 quêtes nommées, 152 sanctuaires, 120 racines, 34 repaires de Lynels, 58 puits, 15 tours et 12 larmes du dragon, bestiaire français et compendium étendu en ligne. Les coordonnées et nombres sont susceptibles de correction selon les sources. Collections numérotées sans localisation = repères personnels. Sans publicité ni achat intégré.')
# Logo / hero copy same aesthetic with correct version name.
html=html.replace('🔎 Catalogue +','🔎 Catalogue +')
(out/'index.html').write_text(html)
manifest=json.loads((base/'manifest.webmanifest').read_text())
manifest['name']='Hyrule Codex V5 — Guide Zelda TOTK'
manifest['description']='Encyclopédie française, 253 quêtes, 152 sanctuaires, 120 racines, 34 Lynels, boss, butins, farming, atlas et collection.'
(out/'manifest.webmanifest').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
sw=(base/'sw.js').read_text().replace('hyrule-codex-v4-20261111','hyrule-codex-v5-20261111-b')
(out/'sw.js').write_text(sw)
(out/'README.txt').write_text('HYRULE CODEX V5\n\nApplication web gratuite et indépendante, non affiliée à Nintendo.\n\nInstaller sur iPhone : déposer tous les fichiers contenus dans ce ZIP comme dossier/site sur Netlify ou un autre hébergement HTTPS, ouvrir l’adresse dans Safari > Partager > Sur l’écran d’accueil.\n\nImportant : ne pas ouvrir index.html dans l’aperçu ChatGPT ou Fichiers iOS, les scripts y sont souvent désactivés. Les boutons demandent un vrai navigateur.\n\nContenu embarqué : 253 intitulés de quêtes FR, 152 sanctuaires XYZ, 120 racines XYZ, 34 points Lynel XYZ, 58 puits, 15 tours et 12 larmes de dragon, 95 fiches bestiaire de la version précédente, farming, armes, armures, amalgame, progression locale, guide. Les autres collectibles sont suivis comme repères numérotés, pas tous localisés. Des liens de cartes externes complètent la base.\n\nLe catalogue Hyrule Compendium API (en anglais avec quelques traductions) charge en ligne et est mis en cache lorsque possible. Une connexion Internet est nécessaire pour les nouvelles entrées.\n\nLe navigateur garde la progression localement sur le même domaine et le même appareil. Exportez la sauvegarde JSON avant un changement de domaine, de navigateur, une réinstallation ou un effacement du stockage Safari.\n\nSource des noms de quête : https://www.puissance-zelda.com/24-Tears-of-the-Kingdom/solution/854-Liste-de-toutes-les-quetes\nCoordonnées : https://www.gamertw.com/fr/zelda/totk/shrine https://www.gamertw.com/fr/zelda/totk/lightroot https://www.gamertw.com/fr/zelda/totk/lynel\nCartes externes : https://zelda8.com/en/maps/totk https://questfern.com/totk/guides/interactive-map/\nAPI : https://hyrule-compendium.com/\n\nLa couverture complète de tous les butins et toutes les probabilités, des centaines d’armes, des 228 recettes et de toutes les localisations de Korogus n’est pas fournie en intégralité hors ligne dans cette version.\n')
zip_path=Path('/mnt/data/Hyrule_Codex_V5_iPhone.zip')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for file in out.iterdir():
  if file.is_file():z.write(file,arcname=file.name)
Path('/mnt/data/Hyrule_Codex_V5.html').write_text(html)
print('V5 built',len(html),'bytes',zip_path.stat().st_size,'ZIP', 'quests',len(quests),'sha',len(sha),'roots',len(roots),'lynels',len(lynels),'wells',len(wells),'towers',len(towers),'tears',len(tears),'atlas',len(sha)+len(roots)+len(lynels)+len(wells)+len(towers)+len(tears)+58)
