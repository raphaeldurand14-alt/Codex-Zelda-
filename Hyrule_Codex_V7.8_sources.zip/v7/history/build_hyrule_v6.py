from pathlib import Path
import sys,json,zipfile,shutil,re,collections
sys.path.insert(0,'/mnt/data')
from hyrule_v6_bosses import build
root=Path('/mnt/data');prev=root/'hyrule_codex_v5';out=root/'hyrule_codex_v6'
out.mkdir(exist_ok=True)
for name in ['icon-192.png','icon-512.png','apple-touch-icon.png']:shutil.copy2(prev/name,out/name)
items=build();assert len(items)==249
html=(prev/'index.html').read_text()
html=html.replace('Hyrule Codex V5','Hyrule Codex V6').replace('✦ V5 enrichie','✦ V6 vérifiée').replace('· Version 5 ·','· Version 6 ·').replace('Sauvegarde locale · V5','Sauvegarde locale · V6')
# Add a new tab and its render function without changing the saved progress storage key.
assert 'const fn={home:renderHome,' in html
html=html.replace('const fn={home:renderHome,','const fn={home:renderHome,bosses:renderV6Bosses,')
html=html.replace('<section id="screen-home"></section>','<section id="screen-home"></section><section class="hidden" id="screen-bosses"></section>')
# Make older atlas source credit accurate; links are per record.
html=html.replace('Coordonnées recoupées à partir des listes publiées par <a href="${SOURCE_URLS.boss}" rel="noopener" target="_blank">Thonky</a>', 'Coordonnées issues de plusieurs répertoires publiés (lien de provenance sur chaque fiche)')
html=html.replace('Les géoglyphes sont une sélection (11 premières larmes) ; les boss marqués réapparaissent après une Lune de sang.', 'Pour les coordonnées précises, consulte toujours le lien « Source » sur la fiche. Les boss marqués réapparaissent après une Lune de sang.')
html=html.replace('V5 : 253 quêtes nommées,','V6 : 253 quêtes nommées,')
html=html.replace('V5 enrichie : 95 fiches françaises','V6 : 95 fiches françaises')
# Correct outdated description linked to game data release.
html=html.replace('88 points géolocalisés','atlas de positions indexées')
style='''
/* V6 verified boss hunter */
.v6-banner{display:flex;align-items:center;gap:24px;padding:17px 23px;border:1px solid #bea06c;border-radius:17px;background:linear-gradient(120deg,#35463a,#15353a);margin:17px 0}.v6-banner>span{font-size:50px}.v6-banner strong{display:block;font-size:40px;color:#f8d58c;line-height:1.15}.v6-banner small{font-size:11px;display:block;letter-spacing:.4px;color:#d3dbd4}.v6-families{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:7px;margin:14px 0}.v6-family{border:1px solid #4b6864;background:#182e34;color:#eee9d5;padding:10px 5px;display:flex;flex-direction:column;align-items:center;gap:5px;border-radius:12px;cursor:pointer}.v6-family span{font-size:25px}.v6-family b{font-size:11px;line-height:1.2}.v6-family small{font-size:10px;color:#cad6cb}.v6-family.on{background:#a3895b;color:#18282d}.v6-family.on small{color:#263e33}.v6-control{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:12px 0}.v6-control .search{flex:1;min-width:180px}.v6-control select{max-width:160px}.v6-farmcard{margin:21px 0;padding:17px;border:1px solid #708b74;background:#1a3736;border-radius:18px;display:flex;gap:15px}.v6-farmcard h3{font-size:17px;color:#f9dfab;margin:0 0 11px}.v6-farmcard p{font-size:13px;line-height:1.6;margin:10px 0}.v6-farmcard a{font-size:12px;color:#e8c888}.v6-farmcard .small{margin:12px 0}.v6-drops{display:flex;gap:6px;flex-wrap:wrap}.v6-drops span{font-size:11px;background:#2b4b43;border:1px solid #4d6c5e;border-radius:9px;padding:6px 8px}.v6-head{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin:22px 0 10px}.v6-head small{color:#b4cabf}.v6-bossgrid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}.v6-bossrow{display:flex;min-width:0;align-items:stretch;background:#142c32;border:1px solid #47605a;border-radius:11px;overflow:hidden}.v6-bossrow>button:first-child{padding:11px 13px;min-width:0;flex:1;background:transparent;color:#eee8d5;text-align:left;cursor:pointer}.v6-name{font-size:13px;font-weight:750;display:block;line-height:1.4}.v6-sub{display:block;font-size:11px;color:#b0c4c0;margin-top:6px}.v6-sub b{color:#e5c98d}.v6-check{flex:0 0 44px;border-left:1px solid #44615b;background:#1e3a39;color:#ebd494;font-size:23px;cursor:pointer}.v6-cleared{opacity:.62}.v6-entry{display:flex;align-items:center;gap:17px;width:100%;padding:14px 19px;background:linear-gradient(100deg,#455c42,#203c41);color:#f1e5cb;border:1px solid #d8b878;border-radius:15px;text-align:left;cursor:pointer;margin:0 0 20px}.v6-entry>span{font-size:34px}.v6-entry b{white-space:nowrap;font-size:15px}.v6-entry small{flex:1;font-size:11px;line-height:1.4}.v6-entry em{color:#f7d894;white-space:nowrap;font-size:12px}
@media(max-width:800px){.v6-families{grid-template-columns:repeat(4,1fr)}.v6-bossgrid{grid-template-columns:1fr}.v6-entry{flex-wrap:wrap}.v6-entry small{flex-basis:70%}.v6-banner>span{font-size:40px}}
@media(max-width:430px){.v6-family{padding:9px 4px}.v6-family b{font-size:10px}.v6-entry{gap:8px}.v6-entry small{flex-basis:100%}.v6-entry em{margin-left:auto}}
'''
html=html.replace('</style>',style+'</style>')
assert html.count('\ninit();\n')==1
js='const V6_BOSSES='+json.dumps(items,ensure_ascii=False,separators=(',',':'))+';\n'+(root/'hyrule_v6_extras.js').read_text()
html=html.replace('\ninit();\n','\n'+js+'\ninit();\n')
(out/'index.html').write_text(html)
manifest=json.loads((prev/'manifest.webmanifest').read_text());manifest['name']='Hyrule Codex V6 — Encyclopédie Zelda';manifest['description']='253 quêtes, atlas sourcé, 283 emplacements de boss, bestiaire et farming Zelda Tears of the Kingdom.'
(out/'manifest.webmanifest').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
sw=(prev/'sw.js').read_text();sw=sw.replace('hyrule-codex-v5-20261111-b','hyrule-codex-v6-20261111-a')
(out/'sw.js').write_text(sw)
(out/'README.txt').write_text('HYRULE CODEX V6 — 11 novembre 2026\n\n- 249 nouvelles positions de boss reprises de tableaux vérifiables de GamerTW : 87 Lithorok, 69 Hinox, 40 Gigatracien, 35 Golemax, 14 Griock, 4 Moldarquor.\n- 34 positions de Lynels déjà intégrées (source GamerTW), soit 283 positions de boss.\n- Les 88 anciens repères de V3 (vérification individuelle insuffisante) ont été retirés du référentiel pour éviter des positions approximatives.\n- Toutes les positions du nouvel Atlas ont un lien direct vers leur source en ligne.\n- Onglet Chasse aux boss : filtre par espèce, zone, saisie XYZ, liste de butins, astuces, suivi vaincu/non vaincu.\n- Les 152 sanctuaires, 120 racines, 58 puits, 15 tours et 12 larmes de la V5 sont conservés avec leurs liens sources.\n- Le jeu et sa base de données appartiennent à leurs ayants droit. Cette application est un projet amateur indépendant.\n\nImportant : une liste de butins possibles ne garantit pas la probabilité de butin. Pour les tables complètes : https://zeldacentral.com/games/tears-of-the-kingdom/game-data/drop-tables/\n\nInstaller sur iPhone : déployer le contenu du ZIP sur un hébergement HTTPS (par exemple un site Netlify déjà créé), ouvrir dans Safari, Partager → Sur l’écran d’accueil. Les aperçus de fichiers de ChatGPT/Fichiers ne prennent pas toujours en charge JavaScript.\n\nLes données ne sont pas exhaustives : 900 Korogus et les recettes ne sont PAS tous localisés ou décrits hors ligne ; la carte gratuite https://zelda8.com/en/maps/totk fournit les localisations à consulter.\n\nPréserve la progression en exportant un JSON avant de changer de domaine ou de navigateur.\n')
with zipfile.ZipFile(root/'Hyrule_Codex_V6_iPhone.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(out.iterdir()):
  if p.is_file():z.write(p,p.name)
(root/'Hyrule_Codex_V6.html').write_text(html)
print('OK V6',len(html),'bytes; boss positions',len(items)+34,'; zipped', (root/'Hyrule_Codex_V6_iPhone.zip').stat().st_size)
