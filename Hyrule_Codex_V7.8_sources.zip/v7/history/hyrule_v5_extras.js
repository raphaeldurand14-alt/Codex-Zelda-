/* HYRULE CODEX V5 — indexes of the game, collected progress, global search.
   Data in V5_SHRINES, V5_ROOTS, V5_LYNELS, V5_QUESTS injected at build time.
*/
const V5_SOURCE={
 shrines:'https://www.gamertw.com/fr/zelda/totk/shrine',
 towers:'https://www.gamertw.com/fr/zelda/totk/tower',
 tears:'https://www.gamertw.com/fr/zelda/totk/dragon-tear',
 roots:'https://www.gamertw.com/fr/zelda/totk/lightroot',
 lynels:'https://www.gamertw.com/fr/zelda/totk/lynel',
 quests:'https://www.puissance-zelda.com/24-Tears-of-the-Kingdom/solution/854-Liste-de-toutes-les-quetes',
 map:'https://zelda8.com/en/maps/totk',
 fullmap:'https://questfern.com/totk/guides/interactive-map/',
 koroks:'https://www.gamertw.com/fr/zelda/totk/korok',
 caves:'https://www.gamertw.com/fr/zelda/totk/cave',
 wells:'https://www.gamertw.com/fr/zelda/totk/well',
 recipes:'https://www.puissance-zelda.com/24-Tears-of-the-Kingdom/solution/854-Liste-de-toutes-les-quetes',
 compendium:'https://hyrule-compendium.com/'
};
state.questDone=state.questDone&&typeof state.questDone==='object'?state.questDone:{};
state.collectDone=state.collectDone&&typeof state.collectDone==='object'?state.collectDone:{};
state.collectNotes=state.collectNotes&&typeof state.collectNotes==='object'?state.collectNotes:{};
const V5_GROUPS=[
 {id:'shrine',name:'Sanctuaires',icon:'⛩️',total:152,source:V5_SOURCE.shrines,legacy:'Sanctuaires',hint:'120 à la surface, 32 dans le ciel. Coordonnées XYZ, détails et cases à cocher.'},
 {id:'root',name:'Racines des Profondeurs',icon:'🌱',total:120,source:V5_SOURCE.roots,legacy:'Racines des Profondeurs',hint:'Chaque racine correspond à un sanctuaire de la surface, approximativement aux mêmes X / Y.'},
 {id:'lynel',name:'Repaires de Lynels',icon:'🦁',total:34,source:V5_SOURCE.lynels,legacy:null,hint:'34 rencontres répertoriées, réparties sur la surface et dans les Profondeurs ; les variantes changent selon la progression.'},
 {id:'korok',name:'Énigmes Korogu',icon:'🌿',total:900,source:V5_SOURCE.koroks,legacy:null,hint:'900 énigmes pour 1 000 graines : 100 énigmes de retrouvailles donnent 2 graines. Numéros personnels, non géolocalisés.'},
 {id:'cave',name:'Grottes',icon:'🕳️',total:147,source:V5_SOURCE.caves,legacy:'Grottes',hint:'147 grottes et leurs cristaux d’Élusis. Une grotte peut avoir plusieurs entrées.'},
 {id:'well',name:'Puits',icon:'🪣',total:58,source:V5_SOURCE.wells,legacy:'Puits',hint:'58 puits pour la mission « Pour l’amour des puits ».'},
 {id:'tower',name:'Tours de reconnaissance',icon:'🗼',total:15,source:V5_SOURCE.towers,legacy:'Tours de reconnaissance',hint:'15 tours pour révéler les régions et lancer Link dans les airs.'},
 {id:'tear',name:'Larmes du dragon',icon:'💧',total:12,source:V5_SOURCE.tears,legacy:'Larmes de dragon',hint:'12 larmes du dragon et leurs souvenirs, dans l’ordre de découverte souhaité.'},
 {id:'sage',name:'Vœux des Sages',icon:'✨',total:20,source:V5_SOURCE.fullmap,legacy:'Vœux des Sages',hint:'20 vœux, utilisés pour améliorer les serments des Sages.'},
 {id:'addison',name:'Panneaux de Boulieh',icon:'🪧',total:81,source:V5_SOURCE.fullmap,legacy:'Panneaux de Boulieh',hint:'81 panneaux de Boulieh à soutenir avec des constructions.'},
 {id:'chasm',name:'Gouffres',icon:'⬇️',total:36,source:V5_SOURCE.map,legacy:'Gouffres',hint:'36 gouffres vers les Profondeurs.'},
 {id:'dispenser',name:'Distributeurs soneaus',icon:'⚙️',total:30,source:V5_SOURCE.map,legacy:'Distributeurs soneaus',hint:'30 distributeurs de modules soneaus.'},
 {id:'tablet',name:'Stèles antiques',icon:'📜',total:12,source:V5_SOURCE.fullmap,legacy:'Textes antiques',hint:'12 tablettes célestes à photographier pour la mission correspondante.'},
 {id:'recipe',name:'Recettes du jeu',icon:'🍲',total:228,source:'https://www.puissance-zelda.com/24-Tears-of-the-Kingdom/solution/',legacy:null,hint:'228 recettes à découvrir. Suivi numéroté personnel, pas une liste de toutes les préparations.'}
];
// On retire les points Lynel approximatifs de la première version : les 34
// repaires répertoriés ici remplacent cette sélection sans la doubler.
for(let i=ATLAS.length-1;i>=0;i--)if(ATLAS[i].type==='Lynel')ATLAS.splice(i,1);
const V5_NAMED=[...V5_SHRINES,...V5_ROOTS,...V5_LYNELS,...V5_WELLS,...V5_TOWERS,...V5_TEARS];
for(const x of V5_NAMED){
 const coords=x.xyz;
 ATLAS.push({id:x.id,type:x.type,layer:x.layer,name:x.name,x:coords[0],y:coords[1],z:coords[2],place:x.type==='Sanctuaire'?'Sanctuaire '+(x.layer==='Ciel'?'céleste':'de la surface'):x.type==='Racine'?'Racine à activer dans les Profondeurs':'Repère de Lynel ; variantes parfois évolutives',source:x.type==='Sanctuaire'?V5_SOURCE.shrines:x.type==='Racine'?V5_SOURCE.roots:x.type==='Puits'?V5_SOURCE.wells:x.type==='Tour'?V5_SOURCE.towers:x.type==='Larme du dragon'?V5_SOURCE.tears:V5_SOURCE.lynels,tip:x.type==='Lynel'?'Le rang de la créature peut varier avec la progression. La Lune de sang renouvelle ces rencontres.':x.type==='Sanctuaire'?'Utilise les coordonnées exactes en jeu et compare avec les icônes de carte.':'Une racine se situe sous un sanctuaire à la surface.'});
}
const V5_I18N={
 'silver lynel':'Lynel d’argent','white-maned lynel':'Lynel blanc','blue-maned lynel':'Lynel bleu','lynel':'Lynel',
 'silver lynel saber horn':'Corne affilée de Lynel d’argent','silver lynel mace horn':'Corne briseuse de Lynel d’argent',
 'lynel guts':'Viscères de Lynel','lynel hoof':'Sabot de Lynel','diamond':'Diamant',
 'sundelion':'Fleur radieuse','bomb flower':'Fleur bombe','brightbloom seed':'Graine Lumos',
 'large brightbloom seed':'Grosse graine Lumos','zonai charge':'Orbe d’énergie soneau',
 'large zonai charge':'Grande orbe d’énergie soneau','zonaite':'Sonium','large zonaite':'Sonium supérieur',
 'gibdo bone':'Os de Gibdo','hylian shield':'Bouclier hylien','master sword':'Épée de légende',
 'silver bokoblin horn':'Corne de Bokoblin d’argent','royal guard’s claymore':'Espadon de garde royal',
 'fire fruit':'Fruit de feu','ice fruit':'Fruit de glace','shock fruit':'Fruit électrique',
 'light dragon’s scale':'Écaille du Dragon blanc','moblin guts':'Viscères de Moblin',
 'red chuchu jelly':'Gelée Chuchu rouge','white chuchu jelly':'Gelée Chuchu blanche',
 'yellow chuchu jelly':'Gelée Chuchu jaune','topaz':'Topaze','sapphire':'Saphir',
 'ruby':'Rubis','opalescent':'Opale','opal':'Opale','amber':'Ambre',
 'frox':'Gigatracien','gleeok':'Griock','molduga':'Moldarquor','stone talus':'Lithorok',
 'flux construct':'Golemax','hinox':'Hinox','horriblin':'Horriblin','lizalfos':'Lézalfos'
};
function frName(n){return V5_I18N[norm(n)]||n}
function searchableRemoteName(x){return norm([x.name,frName(x.name),...(x.drops||[]).flatMap(d=>[d,frName(d)]),...(x.common_locations||[])].join(' '))}
const oldCatFiltered=catFiltered;
catFiltered=function(){const q=norm(catSearch.trim());return catalogueData().filter(x=>(catFilter==='all'||x.category===catFilter)&&(!q||(catMode==='drops'?norm((x.drops||[]).flatMap(d=>[d,frName(d)]).join(' ')).includes(q):searchableRemoteName(x).includes(q))));}
// Additional French aliases are shown without translating descriptions inaccurately.
const oldCatalogueCard=catalogueCard;
catalogueCard=function(x){const h=oldCatalogueCard(x),alias=frName(x.name);return alias===x.name?h:h.replace('<strong>'+escapeHTML(x.name)+'</strong>','<strong>'+escapeHTML(alias)+'</strong><small>'+escapeHTML(x.name)+'</small>')};
const oldCatalogueDetail=showCatalogueDetail;
showCatalogueDetail=function(id){oldCatalogueDetail(id);const x=catalogueData().find(q=>String(q.id??q.name)===String(id));if(!x)return;const h=el('detail-dimmer')?.querySelector('h2');if(h&&frName(x.name)!==x.name)h.innerHTML=escapeHTML(frName(x.name))+' <small class="muted" style="font-size:13px;display:block">'+escapeHTML(x.name)+'</small>';}
let v5QuestGroup='all',v5QuestQuery='',v5QuestPending=false,v5QuestLimit=80;
function questTotals(){return ['main','adventures','shrine','missions'].map(group=>{let a=V5_QUESTS.filter(x=>x.group===group);return {group,total:a.length,done:a.filter(x=>state.questDone[x.id]).length}})}
function syncQuestCounter(){state.checkCounts=state.checkCounts||{};const map={main:'Quêtes principales',adventures:'Aventures secondaires',shrine:'Quêtes de sanctuaire',missions:'Quêtes annexes'};for(const t of questTotals())state.checkCounts[map[t.group]]=t.done;}
function questMatches(){const q=norm(v5QuestQuery);return V5_QUESTS.filter(x=>(v5QuestGroup==='all'||x.group===v5QuestGroup)&&(!v5QuestPending||!state.questDone[x.id])&&norm(x.name+' '+x.category).includes(q))}
function renderQuests(){const totals=questTotals(),sum=totals.reduce((s,x)=>s+x.done,0),matches=questMatches();
const nav=totals.map(x=>`<button class="v5-pill ${v5QuestGroup===x.group?'active':''}" data-qgrp="${x.group}">${{main:'📜 Principales',adventures:'🧭 Secondaires',shrine:'⛩️ Sanctuaires',missions:'📝 Missions'}[x.group]} <small>${x.done}/${x.total}</small></button>`).join('');
el('screen-quests').innerHTML=section('Les 253 quêtes','Liste nominative française · spoilers autorisés · coches individuelles enregistrées sur ton iPhone.')+
`<div class="v5-feature"><div><div class="eyebrow">JOURNAL D’AVENTURE</div><strong class="v5-number">${sum}<small> / 253</small></strong><div class="small">Quêtes terminées</div></div><div class="v5-ring" style="--p:${Math.round(sum/253*100)}%"><span>${Math.round(sum/253*100)} %</span></div></div>
<div class="v5-pills"><button class="v5-pill ${v5QuestGroup==='all'?'active':''}" data-qgrp="all">Toutes ${sum}/253</button>${nav}</div>
<div class="v5-toolbar"><label class="search">⌕ <input id="v5-quest-search" value="${escapeHTML(v5QuestQuery)}" placeholder="Ex. armure zora, Ganondorf…"></label><label class="v5-check"><input type="checkbox" id="v5-quest-todo" ${v5QuestPending?'checked':''}> À terminer</label></div>
<div class="v5-progress"><i style="width:${sum/253*100}%"></i></div><div class="v5-list" id="v5-quest-list">${matches.slice(0,v5QuestLimit).map(x=>`<label class="v5-row ${state.questDone[x.id]?'v5-done':''}"><input type="checkbox" data-v5-quest="${x.id}" ${state.questDone[x.id]?'checked':''}><span class="v5-row-text"><strong>${escapeHTML(x.name)}</strong><small>${escapeHTML(x.category)} · n° ${x.no}</small></span><span class="v5-checkmark">${state.questDone[x.id]?'✓':'◯'}</span></label>`).join('')||'<div class="emptybox">Aucune quête correspondante.</div>'}</div>
${matches.length>v5QuestLimit?`<button id="v5-quest-more" class="btn ghost" style="margin-top:15px">Afficher plus (${matches.length-v5QuestLimit} restantes)</button>`:''}
<div class="sourcebox">Liste des noms : <a target="_blank" rel="noopener" href="${V5_SOURCE.quests}">Puissance-Zelda, journal d’aventure français ↗</a>. Les quêtes sont présentées par catégorie, pas en ordre chronologique. La progression n’est pas synchronisée avec ta Switch.</div>`;
for(const b of el('screen-quests').querySelectorAll('[data-qgrp]'))b.onclick=()=>{v5QuestGroup=b.dataset.qgrp;v5QuestLimit=80;renderQuests()};
for(const b of el('screen-quests').querySelectorAll('[data-v5-quest]'))b.onchange=()=>{state.questDone[b.dataset.v5Quest]=b.checked;syncQuestCounter();save();renderQuests();renderStats()};
el('v5-quest-search').oninput=e=>{v5QuestQuery=e.target.value;v5QuestLimit=80;renderQuests();const inp=el('v5-quest-search');inp.focus();inp.setSelectionRange(inp.value.length,inp.value.length)};
el('v5-quest-todo').onchange=e=>{v5QuestPending=e.target.checked;v5QuestLimit=80;renderQuests()};
if(el('v5-quest-more'))el('v5-quest-more').onclick=()=>{v5QuestLimit+=80;renderQuests()};
}
let v5CollectGroup='shrine',v5CollectQuery='',v5CollectPending=false,v5CollectPage=0;
function collectRecords(group){
 if(group==='shrine')return V5_SHRINES;
 if(group==='root')return V5_ROOTS;
 if(group==='lynel')return V5_LYNELS;
 if(group==='well')return V5_WELLS;
 if(group==='tower')return V5_TOWERS;
 if(group==='tear')return V5_TEARS;
 const grp=V5_GROUPS.find(g=>g.id===group);if(!grp)return [];
 return Array.from({length:grp.total},(_,i)=>({id:group+'_'+String(i+1).padStart(4,'0'),type:grp.name,layer:'',name:grp.name+' — repère personnel n° '+(i+1),no:i+1,unnamed:true}));
}
function isCollectDone(x){return ['shrine','root','lynel','well','tower','tear'].some(k=>x.id.startsWith(k+'_'))?Boolean(state.atlasDone?.[x.id]):Boolean(state.collectDone[x.id])}
function markCollect(id,done){if(['shrine','root','lynel','well','tower','tear'].some(k=>id.startsWith(k+'_')))state.atlasDone[id]=done;else state.collectDone[id]=done;const grp=V5_GROUPS.find(x=>id.startsWith(x.id+'_'));if(grp?.legacy){state.checkCounts=state.checkCounts||{};state.checkCounts[grp.legacy]=collectRecords(grp.id).filter(isCollectDone).length;}save();}
function collectFilter(){return collectRecords(v5CollectGroup).filter(x=>(!v5CollectPending||!isCollectDone(x))&&norm(x.name+' '+(state.collectNotes[x.id]||'')+' '+(x.xyz||[]).join(' ')).includes(norm(v5CollectQuery)))}
function renderCollections(){const g=V5_GROUPS.find(x=>x.id===v5CollectGroup)||V5_GROUPS[0];const all=collectRecords(g.id),done=all.filter(isCollectDone).length,matching=collectFilter(),per=54;const pages=Math.max(1,Math.ceil(matching.length/per));v5CollectPage=Math.min(v5CollectPage,pages-1);const page=matching.slice(v5CollectPage*per,(v5CollectPage+1)*per);
el('screen-collections').innerHTML=section('Collection & 100 %','Toutes les grandes catégories du jeu, avec suivi individuel ou repères personnels. Gratuit et accessible hors ligne.')+
`<div class="v5-feature"><div><div class="eyebrow">${escapeHTML(g.name.toUpperCase())}</div><strong class="v5-number">${done}<small> / ${g.total}</small></strong><div class="small">${escapeHTML(g.hint)}</div></div><div class="v5-ring" style="--p:${Math.round(done/g.total*100)}%"><span>${Math.round(done/g.total*100)} %</span></div></div>
<div class="v5-group-grid">${V5_GROUPS.map(gr=>{const count=collectRecords(gr.id).filter(isCollectDone).length;return `<button class="v5-group ${g.id===gr.id?'active':''}" data-v5-cgrp="${gr.id}"><span>${gr.icon}</span><b>${escapeHTML(gr.name)}</b><small>${count}/${gr.total}</small></button>`}).join('')}</div>
<div class="v5-toolbar"><label class="search">⌕ <input id="v5-collect-search" value="${escapeHTML(v5CollectQuery)}" placeholder="Chercher un nom, une coordonnée, une note…"></label><label class="v5-check"><input id="v5-collect-todo" type="checkbox" ${v5CollectPending?'checked':''}> À trouver</label></div>
<div class="v5-linkbar"><a href="${g.source}" class="btn mini ghost" target="_blank" rel="noopener">🗺️ Voir les emplacements sur la carte ↗</a><span class="small">${matching.length} résultat(s) · ${done} accomplis</span></div>
${g.id==='korok'?'<div class="note">Les numéros 1–900 sont des <b>repères personnels</b> et ne désignent pas les coordonnées officielles des énigmes. Utilise « Ma note » pour y associer un lieu ; les 100 énigmes de retrouvailles donnent deux graines.</div>':(!['shrine','root','lynel','well','tower','tear'].includes(g.id)?'<div class="note">Pour cette catégorie, les numéros sont personnels : les lieux exacts ne sont pas présents hors ligne dans cette version. Consulte la carte liée pour identifier chaque point.</div>':'')}
<div class="v5-list">${page.map(x=>{const completed=isCollectDone(x),xyz=x.xyz?x.xyz.map(v=>v<0?'-'+String(-v).padStart(4,'0'):String(v).padStart(4,'0')).join(' / '):'',note=state.collectNotes[x.id];return `<div class="v5-row ${completed?'v5-done':''}"><label class="v5-tick"><input type="checkbox" data-v5-cdone="${x.id}" ${completed?'checked':''}><span>${completed?'✓':'◯'}</span></label><div class="v5-row-text"><strong>${escapeHTML(note||x.name)}</strong><small>${x.layer?escapeHTML(x.layer)+' · ':''}${xyz?'⌖ '+xyz+' · ':''}${note?'Index : '+escapeHTML(x.name):'À localiser / identifier'}</small></div>${!x.unnamed?`<button class="v5-smallbtn" data-v5-copen="${x.id}" aria-label="Voir la fiche">⌖</button>`:`<button class="v5-smallbtn" data-v5-cnote="${x.id}" aria-label="Ajouter une note">✎</button>`}</div>`}).join('')||'<div class="emptybox">Aucun résultat correspondant.</div>'}</div>
${pages>1?`<div class="v5-pager"><button class="btn mini ghost" id="v5-prev" ${v5CollectPage===0?'disabled':''}>← Préc.</button><span>Page ${v5CollectPage+1} / ${pages}</span><button class="btn mini ghost" id="v5-next" ${v5CollectPage+1>=pages?'disabled':''}>Suiv. →</button></div>`:''}
<div class="sourcebox">📚 Index de coordonnées : <a href="${g.source}" rel="noopener" target="_blank">référence des emplacements ↗</a>. Les totaux sont des objectifs de collection et ne correspondent pas tous au pourcentage de la carte du jeu.</div>`;
for(const b of el('screen-collections').querySelectorAll('[data-v5-cgrp]'))b.onclick=()=>{v5CollectGroup=b.dataset.v5Cgrp;v5CollectPage=0;v5CollectQuery='';v5CollectPending=false;renderCollections()};
for(const b of el('screen-collections').querySelectorAll('[data-v5-cdone]'))b.onchange=()=>{markCollect(b.dataset.v5Cdone,b.checked);renderCollections()};
for(const b of el('screen-collections').querySelectorAll('[data-v5-copen]'))b.onclick=()=>openAtlas(b.dataset.v5Copen);
for(const b of el('screen-collections').querySelectorAll('[data-v5-cnote]'))b.onclick=()=>{const id=b.dataset.v5Cnote;const cur=state.collectNotes[id]||'';const val=prompt('Repère personnel : indique la zone ou une note (facultatif)',cur);if(val===null)return;if(val.trim())state.collectNotes[id]=val.trim().slice(0,120);else delete state.collectNotes[id];save();renderCollections()};
el('v5-collect-search').oninput=e=>{v5CollectQuery=e.target.value;v5CollectPage=0;renderCollections();const inp=el('v5-collect-search');inp.focus();inp.setSelectionRange(inp.value.length,inp.value.length)};
el('v5-collect-todo').onchange=e=>{v5CollectPending=e.target.checked;v5CollectPage=0;renderCollections()};
if(el('v5-prev'))el('v5-prev').onclick=()=>{v5CollectPage--;renderCollections()};
if(el('v5-next'))el('v5-next').onclick=()=>{v5CollectPage++;renderCollections()};
}
let v5SearchText='',v5SearchLimit=60;
function unifiedResults(){const q=norm(v5SearchText.trim());if(q.length<2)return [];
const records=[];function push(kind,tab,name,detail,id,icon){if(norm(name+' '+detail).includes(q))records.push({kind,tab,name,detail,id,icon});}
for(const x of DB.monsters)push('mon','bestiary',x.name,[x.area,...(x.loot||[])].join(' · '),x.id,x.icon);
for(const x of DB.materials)push('mat','farming',x.name,x.use,x.name,x.icon);
for(const x of DB.weapons)push('weapon','weapons',x.name,x.area,x.id,'⚔️');
for(const x of DB.armors)push('armor','armor',x.name,x.area,x.id,'🛡️');
for(const x of V5_QUESTS)push('quest','quests',x.name,x.category,x.id,'📜');
for(const x of ATLAS)push('atlas','atlas',x.name,[x.type,x.layer,x.place,x.x,x.y,x.z].join(' · '),x.id,pinIcon(x.type));
for(const x of catalogueData())push('remote','catalogue',frName(x.name),[x.name,x.description?.slice(0,90),...(x.drops||[]).flatMap(d=>[d,frName(d)])].join(' · '),String(x.id??x.name),catIcons[x.category]||'📦');
return records.sort((a,b)=>Number(norm(b.name)===q)-Number(norm(a.name)===q)||Number(norm(b.name).startsWith(q))-Number(norm(a.name).startsWith(q))||a.name.localeCompare(b.name,'fr'));}
function renderSearchAll(){const data=unifiedResults();el('screen-searchall').innerHTML=section('Recherche universelle','Boss, butins, armes, armures, sanctuaires, racines, 253 quêtes et compendium en ligne : une seule recherche.')+
`<div class="v5-feature"><div class="eyebrow">⌕ CHERCHER DANS TOUT HYRULE</div><p style="font-size:15px;margin:6px 0">Essaie « Lynel », « armure », « fleur bombe », « Taji », « Zelda », « diamant » ou « -0879 ».</p><div class="small">${DB.monsters.length+DB.materials.length+V5_QUESTS.length+ATLAS.length} fiches et repères de base, plus les entrées du compendium téléchargées.</div></div>
<label class="search v5-bigsearch">⌕ <input id="v5-global-search" autofocus placeholder="Que recherches-tu ?" value="${escapeHTML(v5SearchText)}" aria-label="Recherche globale"></label>
<div class="statuspill">${data.length} résultat(s)${catalogueData().length?' · + '+catalogueData().length+' entrées externes mises en cache':' · Catalogue externe non chargé (connexion requise)'}</div>
<div class="v5-list" id="v5-results">${data.slice(0,v5SearchLimit).map(x=>`<button class="v5-searchrow" data-v5-skind="${x.kind}" data-v5-sid="${escapeHTML(x.id)}"><span class="v5-searchico">${x.icon}</span><span><b>${escapeHTML(x.name)}</b><small>${escapeHTML(x.detail.slice(0,140))}</small></span><em>›</em></button>`).join('')||(v5SearchText.length<2?'<div class="emptybox">Tape au moins 2 lettres pour lancer la recherche.</div>':'<div class="emptybox">Aucun résultat : essaie un mot-clé plus court ou le nom anglais.</div>')}</div>
${data.length>v5SearchLimit?'<button class="btn ghost" id="v5-search-more">Afficher plus</button>':''}
<div class="v5-linkbar"><button class="btn mini" id="v5-go-catalogue">🌐 Charger le recueil étendu</button><a class="btn mini ghost" href="${V5_SOURCE.map}" target="_blank" rel="noopener">🗺️ Carte intégrale</a></div>`;
el('v5-global-search').oninput=e=>{v5SearchText=e.target.value;v5SearchLimit=60;renderSearchAll();const inp=el('v5-global-search');inp.focus();inp.setSelectionRange(inp.value.length,inp.value.length)};
for(const b of el('screen-searchall').querySelectorAll('[data-v5-skind]'))b.onclick=()=>openUnified(b.dataset.v5Skind,b.dataset.v5Sid);
if(el('v5-search-more'))el('v5-search-more').onclick=()=>{v5SearchLimit+=60;renderSearchAll()};
el('v5-go-catalogue').onclick=()=>{goto('catalogue');loadCompendium()};}
function openUnified(kind,id){
 if(kind==='mon')return openDetail('monster',id);
 if(kind==='weapon')return openDetail('weapon',id);
 if(kind==='armor')return openDetail('armor',id);
 if(kind==='remote')return showCatalogueDetail(id);
 if(kind==='atlas')return openAtlas(id);
 if(kind==='mat'){state.farmQuery=id;goto('farming');state.farmQuery=id;renderFarming();return;}
 if(kind==='quest'){const q=V5_QUESTS.find(x=>x.id===id);v5QuestGroup=q?.group||'all';v5QuestQuery=q?.name||'';goto('quests');renderQuests();}
}
function renderFullMap(){
 const maps=[['🗺️ Carte interactive intégrale','152 sanctuaires, 900 Korogus, 120 racines et autres marqueurs sur trois étages.',V5_SOURCE.map],['🌍 Carte alternative + suivi','Collections, boss, quêtes et autres objets, avec une carte interactive externe.',V5_SOURCE.fullmap],['⛩️ 152 sanctuaires','Emplacements en français et coordonnées XYZ.',V5_SOURCE.shrines],['🌱 120 racines','Noms et coordonnées des Profondeurs.',V5_SOURCE.roots],['🦁 34 Lynels','Positions à farmer, sur la surface et dans les Profondeurs.',V5_SOURCE.lynels],['🌿 900 énigmes Korogu','Carte des énigmes pour atteindre les 1 000 graines.',V5_SOURCE.koroks],['🕳️ 147 grottes','Localisations et cristaux d’Élusis.',V5_SOURCE.caves],['🪣 58 puits','Emplacements de tous les puits d’Hyrule.',V5_SOURCE.wells]];
 el('screen-fullmap').innerHTML=section('Atlas intégral : trois couches','Liens directs vers les cartes complètes et nos listes hors ligne. Les cartes externes nécessitent Internet.')+
 `<div class="v5-feature"><div><div class="eyebrow">MAPPE-MONDE D’HYRULE</div><strong class="v5-number">3 <small>couches</small></strong><p>☁️ Ciel · 🌲 Surface · 🌑 Profondeurs</p></div><div style="font-size:65px;filter:drop-shadow(0 0 20px #ffd88633)">🌍</div></div><div class="v5-maptiles">${maps.map(([title,desc,url])=>`<a class="v5-maplink" href="${url}" rel="noopener noreferrer" target="_blank"><strong>${title}</strong><small>${desc}</small><span>Ouvrir ↗</span></a>`).join('')}</div><div class="note">La carte des lieux et la base de monstres intégrées à l’application sont utilisables sans Internet après chargement. Les sources ci-dessus sont des liens vers des sites indépendants : je ne peux pas les intégrer hors ligne sans leurs données et leurs autorisations. Les sites externes peuvent avoir leurs propres sauvegardes de progression.</div>`;
}
// V4's navigation and renderer use static maps; functions are patched at build time.
