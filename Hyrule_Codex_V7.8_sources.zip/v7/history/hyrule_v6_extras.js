/* V6 VERIFIED BOSS ATLAS — factual XYZ references with on-screen provenance.
   All newly added positions were checked against the indexed listings (sources
   linked on each card). This is not an in-game live tracker. */
for(let i=ATLAS.length-1;i>=0;i--)if(/^a\d+$/.test(ATLAS[i].id)) ATLAS.splice(i,1);
for(const b of V6_BOSSES) ATLAS.push(b);
navs.splice(2,0,['bosses','🎯','Boss + butins']);
const V6_LOOTS=[
 {family:'Lynel',icon:'🦁',drops:['Corne affilée (selon la variante)','Corne briseuse (selon la variante)','Sabot de Lynel','Viscères de Lynel (taux variable)','Flèches et autres ressources'],tip:'Parades, esquives parfaites et tirs à la tête. Certains Lynels des Profondeurs sont blindés ; brise leur armure avant le combat.'},
 {family:'Lithorok',icon:'🪨',drops:['Ambre, silex et minerais','Rubis, saphir ou topaze (selon la variante)','Diamant (rare, selon la variante)','Cœur de Lithorok à amalgamer'],tip:'Monte sur son dos et frappe son gisement. Les Lithoroks rares sont particulièrement intéressants pour farmer les minerais précieux.'},
 {family:'Hinox',icon:'👹',drops:['Corne de Hinox (selon la variante)','Ongle de Hinox','Dent de Hinox','Viscères de Hinox (taux variable)','Armes portées en collier'],tip:'Une flèche dans l’œil l’étourdit. Les Stalhinox ont une mécanique différente avec leur œil détachable.'},
 {family:'Gigatracien',icon:'🐸',drops:['Croc de Gigatracien (selon la variante)','Ongle de Gigatracien','Viscères de Gigatracien (taux variable)','Sonium et sonium supérieur'],tip:'Une fleur bombe dans sa bouche ouverte peut l’étourdir. Attaque ensuite les gisements sur son dos.'},
 {family:'Golemax',icon:'🤖',drops:['Cœur de Golemax I, II ou III (à amalgamer)','Orbes d’énergie soneau','Grandes orbes d’énergie (selon la variante)','Charges cristallisées'],tip:'Utilise Emprise sur le cube brillant pour le désassembler ; son cœur ne se range pas dans l’inventaire, mais peut être amalgamé.'},
 {family:'Griock',icon:'🐉',drops:['Cornes élémentaires (feu, glace, foudre)','Ailes de Griock','Viscères de Griock (taux variable)','Charges cristallisées'],tip:'Abats ses trois têtes avec des flèches. Les yeux de chauve-souris sur les flèches facilitent les tirs.'},
 {family:'Moldarquor',icon:'🦂',drops:['Mâchoire de Moldarquor','Nageoires de Moldarquor','Viscères de Moldarquor'],tip:'Dans le désert Gerudo, attire-le en faisant du bruit puis déclenche une explosion lorsqu’il attaque.'}
];
const V6_BOSS_TYPES=V6_LOOTS.map(x=>x.family);
const V6_BOSS_PLACES=ATLAS.filter(p=>V6_BOSS_TYPES.includes(p.type));
let v6Type='Tous',v6Layer='Toutes',v6Query='',v6Todo=false,v6Limit=55,v6Details='Lynel';
function v6Spots(){let q=norm(v6Query);return V6_BOSS_PLACES.filter(p=>(v6Type==='Tous'||p.type===v6Type)&&(v6Layer==='Toutes'||p.layer===v6Layer)&&(!v6Todo||!state.atlasDone?.[p.id])&&(!q||norm(p.name+' '+p.variant+' '+p.place+' '+formattedCoord(p)).includes(q)));}
function v6ChooseFamily(f){v6Type=f;v6Details=f;v6Limit=55;goto('bosses');}
function v6BossRow(p){return `<div class="v6-bossrow ${state.atlasDone?.[p.id]?'v6-cleared':''}"><button title="Afficher la fiche de position" data-v6-open="${escapeHTML(p.id)}"><span class="v6-name">${pinIcon(p.type)} ${escapeHTML(p.variant||p.name)}</span><span class="v6-sub">${escapeHTML(p.layer)} · <b>${formattedCoord(p)}</b></span></button><button title="Cocher comme vaincu" class="v6-check" data-v6-check="${escapeHTML(p.id)}" aria-label="Marquer vaincu">${state.atlasDone?.[p.id]?'✓':'○'}</button></div>`}
function renderV6Bosses(){const list=v6Spots(),count=V6_BOSS_PLACES.filter(x=>state.atlasDone?.[x.id]).length;
let hot=V6_LOOTS.find(x=>x.family===v6Details)||V6_LOOTS[0];
let overview=V6_LOOTS.map(x=>{let a=V6_BOSS_PLACES.filter(p=>p.type===x.family),done=a.filter(p=>state.atlasDone?.[p.id]).length;return `<button data-v6-select="${x.family}" class="v6-family ${v6Type===x.family?'on':''}"><span>${x.icon}</span><b>${x.family}</b><small>${done}/${a.length}</small></button>`}).join('');
el('screen-bosses').innerHTML=section('Chasse aux boss','Emplacements XYZ issus de listes publiées · butins utiles · suivi personnel de farming')+
`<div class="v6-banner"><span>🎯</span><div><small>LOCALISATIONS RÉPERTORIÉES</small><strong>${V6_BOSS_PLACES.length}</strong><small>dont 34 Lynels · ${count} rencontres cochées</small></div></div>
<div class="v6-families">${overview}</div><div class="v6-control"><label class="search">⌕ <input id="v6-search" value="${escapeHTML(v6Query)}" placeholder="Variante, coordonnées, région…"></label><select id="v6-layer"><option value="Toutes">🌍 3 couches</option>${['Surface','Ciel','Profondeurs'].map(a=>`<option ${v6Layer===a?'selected':''}>${a}</option>`).join('')}</select></div>
<div class="v6-control"><button class="btn mini ghost" id="v6-all">Toutes les espèces</button><label class="v5-check"><input type="checkbox" id="v6-todo" ${v6Todo?'checked':''}> Non cochés uniquement</label></div>
<div class="v6-farmcard"><span style="font-size:25px">${hot.icon}</span><div><h3>${hot.family} · butins et tactique</h3><div class="v6-drops">${hot.drops.map(t=>`<span>💎 ${escapeHTML(t)}</span>`).join('')}</div><p>${escapeHTML(hot.tip)}</p><div class="small">Les taux ne sont pas systématiquement de 100 %. Consulte la table détaillée avant de prévoir une quantité.</div><a href="https://zeldacentral.com/games/tears-of-the-kingdom/game-data/drop-tables/" target="_blank" rel="noopener">↗ Tableau complet des probabilités de butin</a></div></div>
<div class="v6-head"><strong>📍 ${list.length} positions correspondant aux filtres</strong><small>Appuie pour les coordonnées et la source</small></div>
<div class="v6-bossgrid">${list.slice(0,v6Limit).map(v6BossRow).join('')||'<div class="emptybox">Aucune position correspondante.</div>'}</div>
${list.length>v6Limit?'<button class="btn ghost" id="v6-more">Afficher encore 60 positions</button>':''}
<div class="sourcebox"><b>Traçabilité :</b> chaque position ajoutée est liée à son tableau d’origine. Les anciennes positions approximatives ont été retirées. Sources : <a href="https://www.gamertw.com/fr/zelda/totk/lynel" target="_blank" rel="noopener">Lynels</a>, <a href="https://www.gamertw.com/fr/zelda/totk/hinox" target="_blank" rel="noopener">Hinox</a>, <a href="https://www.gamertw.com/fr/zelda/totk/frox" target="_blank" rel="noopener">Gigatraciens</a>, <a href="https://www.gamertw.com/fr/zelda/totk/flux-construct" target="_blank" rel="noopener">Golemax</a>, <a href="https://www.gamertw.com/fr/zelda/totk/gleeok" target="_blank" rel="noopener">Griocks</a>, <a href="https://www.gamertw.com/fr/zelda/totk/stonetalus" target="_blank" rel="noopener">Lithoroks</a>, <a href="https://www.gamertw.com/fr/zelda/totk/molduga" target="_blank" rel="noopener">Moldarquors</a>.</div>`;
for(const b of el('screen-bosses').querySelectorAll('[data-v6-select]'))b.onclick=()=>{v6Type=b.dataset.v6Select;v6Details=v6Type;v6Limit=55;renderV6Bosses()};
el('v6-search').oninput=e=>{v6Query=e.target.value;v6Limit=55;renderV6Bosses();const inp=el('v6-search');inp.focus();inp.setSelectionRange(inp.value.length,inp.value.length)};
el('v6-layer').onchange=e=>{v6Layer=e.target.value;v6Limit=55;renderV6Bosses()};
el('v6-todo').onchange=e=>{v6Todo=e.target.checked;v6Limit=55;renderV6Bosses()};
el('v6-all').onclick=()=>{v6Type='Tous';v6Query='';v6Limit=55;renderV6Bosses()};
for(const b of el('screen-bosses').querySelectorAll('[data-v6-open]'))b.onclick=()=>openAtlas(b.dataset.v6Open);
for(const b of el('screen-bosses').querySelectorAll('[data-v6-check]'))b.onclick=()=>{state.atlasDone=state.atlasDone||{};const id=b.dataset.v6Check;state.atlasDone[id]=!state.atlasDone[id];save();renderV6Bosses()};
if(el('v6-more'))el('v6-more').onclick=()=>{v6Limit+=60;renderV6Bosses()};
}
const v6OldHome=renderHome;
renderHome=function(){v6OldHome();const card=`<button class="v6-entry" id="v6-enter"><span>🎯</span><b>Chasse aux boss</b><small>${V6_BOSS_PLACES.length} positions documentées : Lynels, Hinox, Griocks, Moldarquors, Gigatraciens, Golemax et Lithoroks. Coordonnées et butins.</small><em>Ouvrir →</em></button>`;el('screen-home').insertAdjacentHTML('afterbegin',card);el('v6-enter').onclick=()=>goto('bosses');};
// Global search remains connected to ATLAS; boss locations are indexed automatically.
// Source labels in the atlas accurately reflect mixed verified sources, not a single provider.
