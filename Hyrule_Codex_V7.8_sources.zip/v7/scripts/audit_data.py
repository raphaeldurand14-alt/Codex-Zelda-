#!/usr/bin/env python3
"""Audit automatique des données de data/ (sans accès réseau).

Produit data/v7/audit.json (embarqué dans l'app) et docs/AUDIT_V7.md.
L'audit détecte des incohérences INTERNES ; il ne prouve pas qu'une donnée est vraie dans le jeu.
"""
from pathlib import Path
import json, math, collections, unicodedata, datetime

ROOT = Path(__file__).resolve().parents[1]
D = ROOT / 'data'
load = lambda n: json.loads((D / n).read_text(encoding='utf-8'))

# Bornes de la carte de TotK (coordonnées affichées en jeu). Valeurs volontairement larges :
# un point hors de ces bornes est certainement une erreur de saisie.
X_LIM, Y_LIM = 6000, 5000


def norm(s):
    return ''.join(c for c in unicodedata.normalize('NFD', str(s)) if unicodedata.category(c) != 'Mn').lower().strip()


def atlas_records():
    recs = []
    for f, key in [('shrines.json', 'shrine'), ('lightroots.json', 'root'), ('lynels.json', 'lynel'),
                   ('wells.json', 'well'), ('towers.json', 'tower'), ('dragon_tears.json', 'tear')]:
        for r in load(f):
            x, y, z = r['xyz']
            recs.append({**r, 'x': x, 'y': y, 'z': z, '_file': f})
    for r in load('boss_locations_v6.json'):
        recs.append({**r, '_file': 'boss_locations_v6.json'})
    return recs


def main():
    issues = []

    def issue(sev, cat, rid, msg, **kw):
        issues.append({'severity': sev, 'category': cat, 'id': rid, 'message': msg, **kw})

    atlas = atlas_records()
    stats = {'atlas_records': len(atlas)}

    # 1. Identifiants
    c = collections.Counter(r['id'] for r in atlas)
    for k, n in c.items():
        if n > 1:
            issue('erreur', 'identifiant', k, f'identifiant présent {n} fois')

    # 2. Bornes et cohérence couche/altitude
    for r in atlas:
        x, y, z, layer = r['x'], r['y'], r['z'], r['layer']
        if not all(isinstance(v, int) for v in (x, y, z)):
            issue('erreur', 'coordonnées', r['id'], 'X/Y/Z non entiers')
            continue
        if abs(x) > X_LIM or abs(y) > Y_LIM:
            issue('erreur', 'coordonnées', r['id'], f'hors carte ({x}, {y})')
        if layer == 'Profondeurs' and z >= 0:
            issue('erreur', 'couche', r['id'], f'Profondeurs mais Z={z} ≥ 0')
        if layer in ('Surface', 'Ciel') and z < -100:
            issue('erreur', 'couche', r['id'], f'{layer} mais Z={z} très négatif')
        if layer == 'Ciel' and z < 400:
            issue('avertissement', 'couche', r['id'], f'Ciel mais Z={z} bas : île basse ou couche erronée')
        if layer == 'Surface' and z > 1400:
            issue('avertissement', 'couche', r['id'], f'Surface mais Z={z} très haut : vérifier la couche')
        if layer not in ('Surface', 'Ciel', 'Profondeurs'):
            issue('erreur', 'couche', r['id'], f'couche inconnue « {layer} »')

    # 3. Doublons de coordonnées
    by_xyz = collections.defaultdict(list)
    for r in atlas:
        by_xyz[(r['x'], r['y'], r['z'])].append(r)
    for k, rs in by_xyz.items():
        if len(rs) > 1:
            issue('avertissement', 'doublon', ','.join(r['id'] for r in rs),
                  f'mêmes XYZ {k} pour ' + ' / '.join(f"{r['type']} « {r['name']} »" for r in rs))
    same_type = collections.defaultdict(list)
    for r in atlas:
        same_type[(r['type'], r['layer'])].append(r)
    near = 0
    for (t, layer), rs in same_type.items():
        for i in range(len(rs)):
            for j in range(i + 1, len(rs)):
                a, b = rs[i], rs[j]
                d = math.dist((a['x'], a['y'], a['z']), (b['x'], b['y'], b['z']))
                if 0 < d < 15:
                    near += 1
                    issue('avertissement', 'doublon probable', f"{a['id']},{b['id']}",
                          f'{t} ({layer}) à {d:.1f} unités l’un de l’autre')

    # 4. Sanctuaire ↔ racine : nom inversé et X/Y quasi identiques (propriété connue du jeu)
    shrines, roots = load('shrines.json'), load('lightroots.json')
    sname = lambda r: r['name'].replace('Sanctuaire ', '').strip()
    rname = lambda r: r['name'].replace('Racine ', '').strip()
    rev = {norm(sname(s))[::-1]: s for s in shrines}
    paired, unpaired_roots, far_pairs = 0, [], []
    root_of = {}
    for r in roots:
        s = rev.get(norm(rname(r)))
        if not s:
            unpaired_roots.append(r['id'])
            issue('avertissement', 'appariement', r['id'], f'racine « {r["name"]} » sans sanctuaire au nom inversé')
            continue
        root_of[s['id']] = r
        paired += 1
        d = math.dist(s['xyz'][:2], r['xyz'][:2])
        if d > 40:
            far_pairs.append((r['id'], s['id'], round(d)))
            issue('erreur', 'appariement', f"{r['id']},{s['id']}",
                  f'racine et sanctuaire appariés mais écart X/Y de {d:.0f} unités (attendu ≈ 0)')
    unpaired_shrines = [s for s in shrines if s['id'] not in root_of]
    stats['shrine_root_pairs'] = paired
    stats['shrines_without_root'] = len(unpaired_shrines)
    stats['shrines_without_root_by_layer'] = dict(collections.Counter(s['layer'] for s in unpaired_shrines))
    for s in unpaired_shrines:
        if s['layer'] == 'Surface':
            issue('info', 'appariement', s['id'], f'sanctuaire de surface « {s["name"]} » sans racine appariée')

    # 5. Cohérence espèce / couche avec le bestiaire
    boss = load('boss_locations_v6.json')
    stats['boss_by_type_layer'] = {f'{t} · {l}': n for (t, l), n in
                                   sorted(collections.Counter((b['type'], b['layer']) for b in boss).items())}
    stats['boss_variants'] = dict(collections.Counter(b.get('variant', '?') for b in boss))
    for b in boss:
        if b['type'] == 'Gigatracien' and b['layer'] != 'Profondeurs':
            issue('erreur', 'contradiction', b['id'], 'le bestiaire V6 dit « Profondeurs uniquement »')
        if b['type'] == 'Moldarquor' and not (b['x'] < -2000 and b['y'] < -1000):
            issue('avertissement', 'contradiction', b['id'], 'Moldarquor hors de la zone Gerudo (sud-ouest)')
    generic = sum(1 for b in boss if b['place'].startswith('Rencontre de'))
    stats['boss_generic_place'] = generic
    if generic:
        issue('info', 'contenu', 'boss_locations_v6', f'{generic}/{len(boss)} positions de boss sans nom de lieu (libellé générique)')
    lyn = load('lynels.json')
    if all(x['name'] == 'Lynel' for x in lyn):
        issue('info', 'contenu', 'lynels', f'{len(lyn)} Lynels sans variante (rouge/bleu/blanc/argent) ni lieu')

    # 6. Bestiaire / matériaux
    db = load('db_export.json')
    mons = {m['id']: m for m in db['monsters']}
    stats['monsters'] = len(mons)
    stats['monsters_hp_missing'] = sum(1 for m in mons.values() if m.get('hp') is None)
    for n, k in collections.Counter(norm(m['name']) for m in mons.values()).items():
        if k > 1:
            issue('erreur', 'doublon', n, f'nom de monstre répété {k} fois')
    mat_names = {norm(m['name']) for m in db['materials']}
    for m in db['materials']:
        for sid in m['sources']:
            if sid not in mons:
                issue('erreur', 'référence', m['name'], f'source « {sid} » absente du bestiaire')
        if not m['sources']:
            issue('info', 'référence', m['name'], 'matériau sans aucun monstre source')
    for m in mons.values():
        if m.get('hp') is None:
            issue('info', 'statistique', m['id'], 'PV non renseignés')
        vague = [l for l in m['loot'] if any(w in norm(l) for w in ('materiaux', 'gemmes', 'selon', 'equipement', 'recompense', 'fin de', 'progression'))]
        if vague:
            issue('info', 'butin', m['id'], 'butin formulé de façon vague : ' + ' ; '.join(vague))
    fus = load('fusion_bonuses.json')
    for n, k in collections.Counter(norm(f[0]) for f in fus).items():
        if k > 1:
            issue('erreur', 'doublon', n, f'bonus d’amalgame répété {k} fois')

    # 7. Quêtes
    q = load('quests.json')
    for n, k in collections.Counter(norm(x['name']) for x in q).items():
        if k > 1:
            issue('avertissement', 'doublon', n, f'intitulé de quête répété {k} fois')
    stats['quests_by_group'] = dict(collections.Counter(x['group'] for x in q))

    # 8. Provenance : chaque enregistrement doit avoir une source au moins au niveau du jeu de données
    for f in ['shrines.json', 'lightroots.json', 'lynels.json', 'wells.json', 'towers.json', 'dragon_tears.json']:
        if any('source' not in r for r in load(f)):
            issue('info', 'provenance', f, 'pas de source par enregistrement (source au niveau du jeu de données seulement)')

    sev = collections.Counter(i['severity'] for i in issues)
    report = {'generated_at': datetime.date.today().isoformat(), 'stats': stats,
              'summary': dict(sev), 'by_category': dict(collections.Counter(i['category'] for i in issues)),
              'issues': issues}
    (D / 'v7').mkdir(exist_ok=True)
    (D / 'v7' / 'audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
    return report


if __name__ == '__main__':
    r = main()
    print(json.dumps({k: r[k] for k in ('stats', 'summary', 'by_category')}, ensure_ascii=False, indent=1))
