#!/usr/bin/env python3
"""Assemble data/sources/consolepulse_koroks.json depuis data/sources/koroks/ (regions.json + un .txt par région importée).
Format d'une ligne : ID|graines|x,y,z[;x,y,z arrivée]|téléporteur|type (EN)|F (surface) ou S (ciel)."""
from pathlib import Path
import json
D = Path(__file__).resolve().parents[1] / 'data' / 'sources'
M = json.loads((D / 'koroks' / 'regions.json').read_text(encoding='utf-8'))
K = []
for r in M['regions']:
    f = D / 'koroks' / f"{r['slug']}.txt"
    r['imported'] = f.exists()
    if not f.exists():
        continue
    for i, l in enumerate(x for x in f.read_text(encoding='utf-8').splitlines() if x.strip()):
        cid, s, c, w, t, lay = l.split('|')
        pts = [[int(v) for v in p.split(',')] for p in c.split(';')]
        if t not in M['types']:
            raise SystemExit(f'Type d’énigme sans traduction : {t}')
        K.append({'id': cid, 'cid': f"korok_{r['offset'] + i + 1:04d}", 'region': r['name'], 'layer': 'Ciel' if lay == 'S' else 'Surface',
                  'seeds': int(s), 'xyz': pts[0], 'goal': pts[1] if len(pts) > 1 else None, 'warp': w, 'type': t})
M['note'] = (f"Totaux par région pour les 16 régions ; positions individuelles importées pour {sum(r['imported'] for r in M['regions'])} régions sur 16. "
             "Solutions résumées en français par Hyrule Codex à partir du type d’énigme. Identifiants régionaux de la source, pas ceux du jeu.")
M['koroks'] = K
(D / 'consolepulse_koroks.json').write_text(json.dumps(M, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
print('Korogus importés :', len(K), '·', [r['name'] for r in M['regions'] if r['imported']])
