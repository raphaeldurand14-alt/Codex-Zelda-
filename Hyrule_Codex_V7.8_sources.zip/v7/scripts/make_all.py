#!/usr/bin/env python3
"""Pipeline complet V7 : corrections → audit → registre de vérification → exports dérivés → build → tests.
Lancer : python3 scripts/make_all.py   (ajouter --no-e2e si Playwright n'est pas installé)"""
from pathlib import Path
import json, subprocess, sys, collections
R = Path(__file__).resolve().parents[1]; D = R / 'data'
run = lambda *a: subprocess.run([sys.executable, *a], cwd=R, check=True)
run('scripts/apply_corrections_v7.py')
run('scripts/build_koroks.py')
run('scripts/build_encyclopedia.py')
run('scripts/audit_data.py')
run('scripts/build_verification.py')
# exports dérivés (lecture seule) : atlas actif et compteurs
ld = lambda n: json.loads((D / n).read_text(encoding='utf-8'))
atlas = []
for f in ['shrines.json', 'lightroots.json', 'lynels.json', 'wells.json', 'towers.json', 'dragon_tears.json']:
    for x in ld(f):
        atlas.append({'id': x['id'], 'name': x['name'], 'type': x['type'], 'layer': x['layer'], 'x': x['xyz'][0], 'y': x['xyz'][1], 'z': x['xyz'][2]})
atlas += ld('boss_locations_v6.json')
(D / 'atlas_active_640.json').write_text(json.dumps(atlas, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
db = ld('db_export.json')
stats = {'bestiary': len(db['monsters']), 'weapons': len(db['weapons']), 'armor_sets': len(db['armors']), 'materials': len(db['materials']),
         'fusion_bonuses': len(ld('fusion_bonuses.json')), 'farming_routes': len(ld('farming_routes.json')), 'recipe_tips': len(ld('recipe_tips.json')),
         'quests': len(ld('quests.json')), 'atlas_active': len(atlas),
         'atlas_types': dict(collections.Counter(x['type'] for x in atlas)), 'layers': dict(collections.Counter(x['layer'] for x in atlas)),
         'verification_status': dict(collections.Counter(v['s'] for v in ld('v7/verification.json').values())),
         'note': 'Nombres d’enregistrements, PAS un taux de complétude du jeu.'}
(D / 'stats_current.json').write_text(json.dumps(stats, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
run('scripts/build.py')
subprocess.run(['node', '-e', "const h=require('fs').readFileSync('site/index.html','utf8');new Function(h.match(/<script>([\\s\\S]*)<\\/script>/)[1]);console.log('JS compile OK')"], cwd=R, check=True)
run('tests/verify_project.py')
if '--no-e2e' not in sys.argv:
    run('tests/e2e_iphone.py')
