#!/usr/bin/env python3
"""Construit le registre de provenance/vérification V7 à partir de data/ et data/sources/.

Sorties (embarquées dans l'app via window.CODEX_V7) :
  data/v7/verification.json  statut par enregistrement   « jeu:id » -> {s, f, src, n}
  data/v7/coverage.json      couverture par catégorie (présent / attendu / vérifié)
  data/v7/sources.json       registre des sources citées
Règle : un statut « vérifié » exige une source EXTERNE concordante distincte de la source d'import.
"""
from pathlib import Path
import json, math, collections

ROOT = Path(__file__).resolve().parents[1]
D = ROOT / 'data'
rd = lambda n: json.loads((D / n).read_text(encoding='utf-8'))
WEB = rd('sources/web_checks_2026-11-11.json')
SAM = rd('sources/samurai_gamers_lightroots_2023-06-09.json')
S = WEB['sources']
V = {}


def put(key, status, fields=None, src=None, note=None):
    e = {'s': status}
    if fields: e['f'] = fields
    if src: e['src'] = src
    if note: e['n'] = note
    V[key] = e


# --- Bestiaire -------------------------------------------------------------
db = rd('db_export.json')
mons = {m['id']: m for m in db['monsters']}
hp_checks = {x['id']: x for x in WEB['monster_hp']}
RBE = json.loads((D / 'sources' / 'rankedboost_enemies_2026-11-11.json').read_text(encoding='utf-8'))
rb_by_id = {e['v6_id']: e for e in RBE['enemies'] if e['v6_id']}
name_checks = {x['id']: x for x in WEB['monster_names_fr']}
CORR = rd('v7/corrections.json')
for mid, m in mons.items():
    h, n = hp_checks.get(mid), name_checks.get(mid)
    notes, src, fields = [], [], []
    status = 'non_source'
    if h:
        src += [S[s] for s in h['src']]
        if m.get('hp') == h['hp']:
            fields.append('PV')
            status = 'verifie_multi' if len(h['src']) > 1 else 'verifie_source'
        else:
            status = 'conflit'
            notes.append(f"PV V6 = {m.get('hp')} ; source = {h['hp']}")
        if h.get('note'): notes.append(h['note'])
    rb = rb_by_id.get(mid)
    if rb and not h:
        src.append(RBE['source_url'])
        filled = any(c['key'] == f'bestiary:{mid}' and c['field'] == 'hp' for c in CORR)
        if filled:
            if status == 'non_source': status = 'importe'
            notes.append(f"PV importés en V7 depuis la fiche {rb['name']} (source unique, non recoupée).")
        elif m.get('hp') == rb['hp']:
            fields.append('PV'); status = 'verifie_source'
            notes.append(f"PV V6 concordants avec la fiche {rb['name']}.")
    if n and n['src']:
        fields.append('nom FR'); src += [S[s] for s in n['src']]
        if status == 'non_source': status = 'verifie_source'
    elif n:
        notes.append('Nom FR aligné sur l’atlas V6, non confirmé par une seconde source.')
    if fields:
        notes.append('Recoupé : ' + ', '.join(fields) + '. Butins, faiblesses et zones non recoupés.')
    elif status == 'non_source':
        notes.append('Aucune source par fiche en V6 : PV, butins et zones à vérifier.')
    put(f'bestiary:{mid}', status, fields, sorted(set(src)), ' '.join(notes))

# --- Amalgame --------------------------------------------------------------
fus = rd('fusion_bonuses.json')
fchk = {x['name']: x for x in WEB['fuse_power']}
for f in fus:
    c = fchk.get(f[0])
    if not c:
        put(f'fusion:{f[0]}', 'non_source', note='Valeur V6 non recoupée.')
    elif c['power'] == f[1]:
        put(f'fusion:{f[0]}', 'verifie_multi' if len(c['src']) > 1 else 'verifie_source', ['bonus'],
            [S[s] for s in c['src']], c.get('note'))
    else:
        put(f'fusion:{f[0]}', 'conflit', ['bonus'], [S[s] for s in c['src']], f"V6 = {f[1]} ; source = {c['power']}")

# --- Racines : recoupement avec Samurai Gamers + litiges -----------------
roots = rd('lightroots.json')
pts = SAM['points']
disp = {x['root']: x for x in WEB['lightroot_disputes']}
root_ok = {}
for r in roots:
    x, y, z = r['xyz']
    if r['id'] in disp:
        d = disp[r['id']]
        put(f"lightroots:{r['id']}", d['status'], ['XYZ'], [S['samurai_roots']] + [S[k] for k in d['others'] if k != 'gamertw_en_roots'], d['verdict'])
        root_ok[r['id']] = d['status'] != 'conflit'
        continue
    best = min(pts, key=lambda p: math.dist((x, y), (p[1], p[2])))
    dxy = math.dist((x, y), (best[1], best[2]))
    dz = None if best[3] is None else abs(best[3] - z)
    if dxy <= 6 and (dz is None or dz <= 6):
        put(f"lightroots:{r['id']}", 'verifie_source', ['XYZ'] if dz is not None else ['XY'], [S['samurai_roots']],
            f"Concorde avec « {best[0]} » ({best[1]}, {best[2]}, {best[3]})." + ('' if dz is not None else ' Z illisible dans la source.'))
        root_ok[r['id']] = True
    elif dxy <= 30:
        put(f"lightroots:{r['id']}", 'verifie_partiel', ['XY approx.'], [S['samurai_roots']],
            f"Écart de {dxy:.0f} u en X/Y (et {dz if dz is not None else '?'} u en Z) avec « {best[0]} » : relevés différents d’un même point probable.")
        root_ok[r['id']] = True
    elif dxy <= 300:
        put(f"lightroots:{r['id']}", 'conflit', ['XYZ'], [S['samurai_roots']],
            f"Écart de {dxy:.0f} u avec « {best[0]} » ({best[1]}, {best[2]}, {best[3]}) : l’une des deux sources se trompe, à confirmer en jeu.")
        root_ok[r['id']] = False
    else:
        put(f"lightroots:{r['id']}", 'importe', note='Absent ou très différent dans la source de recoupement (Samurai Gamers ne liste que 119 racines).')
        root_ok[r['id']] = False
corr = {c['key']: c for c in rd('v7/corrections.json')}
if 'lightroots:root_119' in corr:
    V['lightroots:root_119']['n'] = (V['lightroots:root_119'].get('n', '') + ' Nom corrigé en V7 (à confirmer).').strip()

# --- Sanctuaires : X/Y recoupés via la racine appariée -------------------
import unicodedata
def nn(s): return ''.join(c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn').lower().strip()
shrines = rd('shrines.json')
by_rev = {nn(r['name'].replace('Racine ', ''))[::-1]: r for r in roots}
for s in shrines:
    k = f"shrines:{s['id']}"
    r = by_rev.get(nn(s['name'].replace('Sanctuaire ', '')))
    if k.replace('shrines:', '') == 'shrine_119':
        r = next(x for x in roots if x['id'] == 'root_119')
    if f'shrines:{s["id"]}' in corr:
        put(k, 'corrige_a_confirmer', ['X'], corr[k]['sources'], corr[k]['why'])
    elif s['layer'] == 'Ciel':
        put(k, 'importe', note='Sanctuaire céleste : pas de racine pour recouper. Source d’import : GamerTW.')
    elif r and root_ok.get(r['id']) and math.dist(s['xyz'][:2], r['xyz'][:2]) <= 6:
        note = f"X/Y recoupés via la racine appariée {r['name']}. Z non recoupé."
        if s['xyz'][2] < -100: note += f" Z={s['xyz'][2]} inhabituel en surface : à confirmer."
        put(k, 'verifie_partiel', ['XY'], [S['samurai_roots']], note)
    else:
        put(k, 'importe', note='Non recoupé en V7.')

# --- Atlas : boss, Lynels, puits, tours, larmes ---------------------------
for b in rd('boss_locations_v6.json'):
    note = 'Position importée de GamerTW (répertoire par espèce). Effectif de la variante recoupé au niveau global.'
    st = 'importe'
    if b['layer'] == 'Surface' and b['z'] < -100:
        st, note = 'conflit', f"Couche « Surface » mais Z={b['z']} : vérifier s’il s’agit des Profondeurs."
    put(f"atlas:{b['id']}", st, note=note)
ENC0 = rd('v7/encyclo.json')
for lid, t in ENC0['lynels']['by_id'].items():
    if t['coliseum']:
        put(f'atlas:{lid}', 'verifie_partiel', ['XY approx.'], [ENC0['lynels']['source_url']], 'Colisée flottant : position concordante à ±160 u, 5 combats successifs (Lynel → Lynel d’argent cuirassé).')
    elif t['dist'] <= 15:
        put(f'atlas:{lid}', 'verifie_source', ['XYZ', 'variante'], [ENC0['lynels']['source_url']], f"Position concordante (écart {t['dist']} u) ; variante listée : {t['variant_fr']} (peut évoluer avec la progression).")
    else:
        put(f'atlas:{lid}', 'verifie_partiel', ['XYZ approx.', 'variante'], [ENC0['lynels']['source_url']], f"Écart de {t['dist']} u (zone de patrouille) ; variante listée : {t['variant_fr']} (peut évoluer avec la progression).")
for f, label in [('wells.json', 'Puits'), ('towers.json', 'Tour'), ('dragon_tears.json', 'Larme')]:
    for r in rd(f):
        put(f"atlas:{r['id']}", 'importe', note=f'{label} : position importée de GamerTW, non recoupée en V7.')

# --- Couverture --------------------------------------------------------------
bosses = rd('boss_locations_v6.json')
vt = collections.Counter(b['variant'] for b in bosses)
cnt = {c['type']: c for c in WEB['boss_counts']}
present = collections.Counter(b['type'] for b in bosses)
present['Lynel'] = len(rd('lynels.json'))


def verified(prefix):
    return sum(1 for k, v in V.items() if k.startswith(prefix) and v['s'] in ('verifie_multi', 'verifie_source', 'verifie_partiel'))


cov = []
def add(cat, pres, exp, exp_status, exp_src, ver, ver_what, note=''):
    cov.append({'cat': cat, 'present': pres, 'expected': exp, 'expected_status': exp_status,
                'expected_src': exp_src, 'verified': ver, 'verified_what': ver_what, 'note': note})

add('Racines (Profondeurs)', len(roots), 120, 'source', [S['samurai_roots']], verified('lightroots:'), 'XYZ recoupés')
add('Sanctuaires', len(shrines), 152, 'source', [S['consolepulse_roots']], verified('shrines:'), 'X/Y via racine', '32 sanctuaires célestes non recoupés.')
for t in ['Lynel', 'Hinox', 'Lithorok', 'Gigatracien', 'Golemax', 'Griock', 'Moldarquor']:
    c = cnt[t]
    split_ok = all(vt.get(k) == v for k, v in c.get('split', {}).items()) if c.get('split') else None
    add(f'Positions : {t}', present[t], c['total'], 'conflit' if c.get('conflict') else 'source',
        [S[s] for s in c['src']], verified('atlas:lynel_') if t == 'Lynel' else 0, 'positions + variantes (Thonky)' if t == 'Lynel' else 'positions individuelles non recoupées',
        (c.get('conflict', '') + (' Répartition par variante identique à la source.' if split_ok else '')).strip())
add('Puits', len(rd('wells.json')), 58, 'non_verifie', [], 0, '—', 'Total V6 non recoupé en V7.')
add('Tours', len(rd('towers.json')), 15, 'source', ['https://consolepulse.com/nintendo/zelda/guides/zelda-totk-complete-map-surface-sky-depths-guide'], 0, '—')
add('Larmes du dragon', len(rd('dragon_tears.json')), 12, 'non_verifie', [], 0, '—')
add('Bestiaire (fiches)', len(mons), None, 'inconnu', [], verified('bestiary:'), 'PV et/ou nom FR', 'Nombre total d’ennemis du jeu non établi : pas de taux de complétude.')
add('Bonus d’amalgame', len(fus), None, 'inconnu', [], verified('fusion:'), 'valeur du bonus', f"{len(WEB['fuse_power_missing_in_v6'])} matériaux sourcés absents de la liste V6 (noms FR non vérifiés).")
add('Armes', len(db['weapons']), None, 'inconnu', [], 0, '—', 'Sélection V6 sans source par fiche.')
add('Armures (ensembles)', len(db['armors']), None, 'inconnu', [], 0, '—', 'Pas de coûts d’amélioration en V6.')
add('Quêtes (intitulés)', len(rd('quests.json')), None, 'inconnu', ['https://www.puissance-zelda.com/24-Tears-of-the-Kingdom/solution/854-Liste-de-toutes-les-quetes'], 0, '—', 'Intitulés seulement, pas de solutions.')
ENC = ENC0
add('Korogus (positions)', len(ENC['koroks']['items']), 900, 'source', [ENC['koroks']['source_url']], 0, 'source unique', f"{sum(1 for r in ENC['koroks']['regions'] if r['imported'])} régions importées sur 16 ; totaux par région connus pour les 16 (900 rencontres, 1 000 graines).")
add('Vœux des Sages', len(ENC['sages']['items']), 20, 'source', [ENC['sages']['source_url']], sum(1 for w in ENC['sages']['items'] if w['checks']), 'recoupés avec ≥ 1 autre site (≤ 30 u)', 'Coffres célestes ; 3 gardés par un Roi Griock.')
add('Panneaux de Boulieh (Addison)', len(ENC['addison']['items']), 81, 'source', [ENC['addison']['source_url']], 0, 'source unique', 'Surface uniquement.')
add('Grottes', len(ENC['caves']['items']), 147, 'source', [ENC['caves']['source_url']], len(ENC['caves']['crosscheck']['points']), 'recoupées ponctuellement (EarlyGame)', f"{sum(len(c['entrances']) for c in ENC['caves']['items'])} entrées / 197 annoncées ; 1 conflit de nom (Oasis Source).")
add('Recettes (livre 1–228)', len(ENC['recipes']['items']), 228, 'source', [ENC['recipes']['source_url']], 0, 'source unique, non recoupé', 'Formule valide par entrée ; noms anglais.')
add('Armures (pièces)', len(ENC['armor']['pieces']), 135, 'source', [ENC['armor']['source_url']], 0, 'source unique, non recoupé', '103 améliorables, coûts des 4 paliers inclus ; noms anglais.')
add('Armes, arcs, boucliers', len(ENC['weapons']['items']), 174, 'source', [ENC['weapons']['source_url']], 0, 'source unique, non recoupé', 'Numéros 329–503 du Compendium tous présents sauf 440 (flèche, sans statistiques).')
add('Ennemis communs (fiches sourcées)', len(ENC['enemies']['items']), None, 'inconnu', [ENC['enemies']['source_url']], 0, 'source unique', 'PV et butins possibles ; pas de taux de butin.')

reg = {k: v for k, v in S.items()}
(D / 'v7' / 'verification.json').write_text(json.dumps(V, ensure_ascii=False, separators=(',', ':')) + '\n', encoding='utf-8')
(D / 'v7' / 'coverage.json').write_text(json.dumps(cov, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
(D / 'v7' / 'sources.json').write_text(json.dumps({'collected_at': WEB['collected_at'], 'method': WEB['method'], 'registry': reg,
    'same_origin_as_v6': WEB.get('same_origin_as_v6', [])}, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
c = collections.Counter(v['s'] for v in V.values())
print('enregistrements :', len(V), dict(c))
for row in cov:
    print(f"{row['cat']:28} {row['present']:>4} / {row['expected']!s:>4}  vérifiés {row['verified']}")
