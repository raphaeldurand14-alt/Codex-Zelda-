#!/usr/bin/env python3
"""Construit site/index.html (autonome, hors ligne) à partir de src/ et data/.

Depuis V7, data/*.json est la SOURCE UNIQUE des données :
  - src/app.js contient des marqueurs  /*@data:<nom>*/null  remplacés ici par data/<nom>.json ;
  - src/v7.js (couche V7) est inséré juste avant l'appel final init() ;
  - data/v7/*.json (provenance, vérifications, audit) est injecté dans window.CODEX_V7.

Options :
  --legacy-only   reconstruit sans la couche V7 (test de non-régression octet pour octet vs V6).
"""
from pathlib import Path
import json, re, sys, hashlib

ROOT = Path(__file__).resolve().parents[1]
SRC, DATA, SITE = ROOT / 'src', ROOT / 'data', ROOT / 'site'
VERSION = (ROOT / 'VERSION').read_text(encoding='utf-8').strip()


def compact(obj):
    return json.dumps(obj, ensure_ascii=False, separators=(',', ':'))


def inject_legacy(js: str) -> str:
    def rep(m):
        p = DATA / f'{m.group(1)}.json'
        if not p.exists():
            raise SystemExit(f'ERREUR : {p} introuvable (marqueur dans src/app.js)')
        return compact(json.loads(p.read_text(encoding='utf-8')))
    out, n = re.subn(r'/\*@data:([a-z0-9_]+)\*/null', rep, js)
    if n != 14:
        raise SystemExit(f'ERREUR : 14 marqueurs de données attendus, {n} trouvés')
    return out


def v7_bundle() -> str:
    bundle = {'version': VERSION}
    for p in sorted((DATA / 'v7').glob('*.json')):
        bundle[p.stem] = json.loads(p.read_text(encoding='utf-8'))
    return 'window.CODEX_V7=' + compact(bundle).replace('</', '<\\/') + ';\n'


def build(legacy_only=False, out=None):
    template = (SRC / 'index.template.html').read_text(encoding='utf-8')
    assert template.count('<!-- __INLINE_CSS__ -->') == 1
    assert template.count('<!-- __INLINE_JS__ -->') == 1
    css = (SRC / 'styles.css').read_text(encoding='utf-8')
    js = inject_legacy((SRC / 'app.js').read_text(encoding='utf-8'))
    if not legacy_only:
        css += '\n' + (SRC / 'v7.css').read_text(encoding='utf-8')
        assert js.rstrip().endswith('init();'), 'app.js doit se terminer par init();'
        js = js.rstrip()[:-len('init();')] + v7_bundle() + (SRC / 'v7.js').read_text(encoding='utf-8') + '\ninit();\n'
    html = template.replace('<!-- __INLINE_CSS__ -->', '<style>' + css + '</style>')
    html = html.replace('<!-- __INLINE_JS__ -->', '<script>' + js + '</script>')
    target = out or (SITE / 'index.html')
    Path(target).write_text(html, encoding='utf-8')
    return target, html


if __name__ == '__main__':
    legacy = '--legacy-only' in sys.argv
    out = None
    if '--out' in sys.argv:
        out = Path(sys.argv[sys.argv.index('--out') + 1])
    target, html = build(legacy_only=legacy, out=out)
    if not legacy and out is None:
        digest = hashlib.sha256(html.encode('utf-8')).hexdigest()[:10]
        sw = SITE / 'sw.js'
        s = re.sub(r"const CACHE='[^']*'", f"const CACHE='hyrule-codex-{VERSION}-{digest}'",
                   sw.read_text(encoding='utf-8'), count=1)
        sw.write_text(s, encoding='utf-8')
        print(f'Cache PWA : hyrule-codex-{VERSION}-{digest}')
    print(f'Construit : {target} ({len(html):,} caractères){" [legacy V6]" if legacy else ""}')
