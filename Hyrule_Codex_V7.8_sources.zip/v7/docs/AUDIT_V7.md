# Audit des données V6 → V7

Produit par `scripts/audit_data.py` (contrôles internes, sans réseau) et `scripts/build_verification.py` (recoupements externes). Rapport machine : `data/v7/audit.json`.

## Erreurs trouvées et corrigées (journal : `data/v7/corrections.json`)

1. **Sanctuaire Vami Toqa (shrine_95)** : X = -3094, soit à 6 187 unités de sa propre racine (3093, -3209). Une source indépendante place cette racine en 3095, -3209. Corrigé en X = 3094 — *à confirmer en jeu*.
2. **Racine 119** : nom corrompu « Uqnol Omeriautcnas » (le mot « sanctuaire » inversé y était collé). Corrigé en « Uqnol Om » selon la règle nom inversé du sanctuaire — *à confirmer*.
3. **Noms de variantes divergents** entre bestiaire et atlas : « Gigatracien bleu-blanc » → **Gigatracien opalin** (nom frF Zelda Wiki), « Lithorok magmatique » → **Magrok**, « Lithorok de glace » → **Cryorok**, « Gigatracien d’obsidienne » → **Gigatracien anthracite** (nom de l’atlas, une seule source).
4. **Lithorok fortifié** absent du bestiaire alors que l’atlas en compte 24 : fiche ajoutée (nom et PV 380 sourcés, butin non importé).
5. **Bug de sauvegarde V6** : l’import rejetait les coches `boss_*`, `well_*`, `tower_*`, `tear_*`. Corrigé dans `src/app.js`, test e2e à l’appui.
6. **Affirmations excessives** : le commentaire « VERIFIED BOSS ATLAS » et le texte « positions documentées » ont été remplacés ; l’assistant ne prétend plus être une conversation connectée.

## Anomalies signalées, non corrigées (manque de preuve)

- shrine_15 « Iün Oloq » : couche Surface avec Z = -105 (X/Y confirmés par la racine).
- boss_hinox_037 (Stalhinox) : couche Surface avec Z = -124 → statut **conflit**.
- root_41 : 218 unités d’écart avec Samurai Gamers → **conflit**.
- root_115 : Y = -2142 (V6, Gamepur) contre -2412 (Samurai Gamers, Game8) → **conflit**.
- 18 matériaux sans monstre source, 23 fiches aux butins vagues, 58 fiches sans PV, 249 positions de boss sans nom de lieu, 34 Lynels sans variante.

## Coquilles constatées chez des sources tierces

Samurai Gamers indique Anonisik en X = 3568 et Kohsustu en Y = -3559 ; d’autres sources indépendantes confirment les valeurs V6 (2568 ; -3358). Les recoupements ne sont donc jamais traités comme une vérité absolue.
