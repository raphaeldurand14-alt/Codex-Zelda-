# Feuille de route pour rendre Hyrule Codex réellement complet

Il n'existe **aucune estimation honnête de « 100 % »** tant qu'un référentiel d'exhaustivité par catégorie n'a pas été établi. La progression doit être mesurée *vérifié / total attendu*, source à l'appui.

## Priorité 0 — correction de confiance

1. Définir un schéma JSON commun, IDs stables, `source_url`, `verification_status` et variantes.
2. Auditer les 640 coordonnées, les 95 fiches bestiaire, les 87 matériaux et corriger incohérences/erreurs.
3. Séparer vrais emplacements, positions approximatives, lieu du boss et région. Ajouter un bouton *signaler une erreur* local exportable.
4. Tests automatisés d'intégrité ; générer un tableau d'écarts.

## Priorité 1 — farming utile

5. Relation inverse **matériau → familles/variantes qui le donnent → quantité/taux documentés → positions exactes**.
6. Différencier les loot tables selon la variante et le niveau, éviter tout taux inventé.
7. Calculer un itinéraire par région/couche et la réapparition après Lune de sang ; n'utiliser que les points validés.
8. Relier chaque fiche boss et arme à ses matériaux d'amalgame, débloquer une recherche avancée.

## Priorité 2 — équipements et complétion

9. Toutes les armes, arcs, boucliers et variantes avec statistiques correctes, durabilité, effets, méthode d'obtention et sources.
10. Toutes les pièces d'armure avec matériaux et coût par palier d'amélioration, set bonus et prérequis.
11. Toutes les quêtes **avec étapes et récompenses**, pas seulement intitulés.
12. Recettes alimentaires/élixirs et effets avec durées et restrictions sourcées.
13. 900 puzzles Korogu géolocalisés séparément des 1 000 graines, 147 grottes, puits, sanctuaires, racines, etc.
14. Atlas : carte interactive géolocalisée des 3 couches, filtres, lien itinéraires, panneau source et signalement.

## Priorité 3 — expérience et qualité

15. Interface réactive au tactile iPhone, filtres, état sauvegardé, export JSON/migration.
16. Accès hors ligne à toutes les fiches intégrées, mention explicite de ce qui requiert Internet.
17. Tests automatisés e2e dans navigateur iPhone simulé, tests manuels appareil réel et audit accessibilité.
18. Documentation mise à jour + versions de données, changelog + provenance claire.

## Critères pour dire « terminé »

- Chaque catégorie a un total d'objets **attendus d'après une source solide** ; aucune cellule affichée comme « complète » sans correspondance à ce référentiel.
- Un taux de vérification mesurable est établi et reproductible.
- Aucun inventaire de données rempli par placeholders ou spéculation.
- La PWA peut être construite, déployée et utilisée sur Safari iPhone.
- Les parcours matériau → loot → ennemi → position → farming fonctionnent réellement.
