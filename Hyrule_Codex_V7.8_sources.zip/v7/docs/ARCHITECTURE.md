# Architecture et maintenance

## PWA statique sans serveur

La livraison `site/` comprend `index.html` (HTML/CSS/JS intégrés), `manifest.webmanifest`, `sw.js`, trois icônes et `README.txt`. Elle n’a besoin ni de Node ni de Python en production ; un hébergement HTTPS suffit. En local, ouvrir via `http://localhost` pour un comportement proche d'un site.

## Structure du code

Pour faciliter Claude Code, le monolithe a été découpé **sans changer le comportement** en :

- `src/index.template.html` : squelette HTML, marqueurs `<!-- __INLINE_CSS__ -->` et `<!-- __INLINE_JS__ -->`.
- `src/styles.css` : CSS original.
- `src/app.js` : code original dans le même ordre, constantes `DB`, `ATLAS`, `V5_*`, `V6_*`, composants et événements.
- `scripts/build.py` : réassemble exactement ces trois fichiers en `site/index.html`.

Après édition du JavaScript/CSS, exécuter `python3 scripts/build.py`. Ne pas éditer en parallèle `site/index.html`, car le build l'écrasera.

## V7 : données branchées

- `src/app.js` contient 14 marqueurs `/*@data:nom*/null` remplacés au build par `data/nom.json`. **Modifier un JSON de `data/` modifie désormais l’app** (après `python3 scripts/build.py`).
- `src/v7.js` + `src/v7.css` : couche V7 insérée juste avant `init()` ; elle enveloppe `monCard`, `openDetail`, `openAtlas`, `renderV6Bosses`, `renderFusion`, `renderGoals`, `renderHome` et `render`.
- `data/v7/*.json` est injecté dans `window.CODEX_V7` (vérification, couverture, corrections, audit, sources).
- `data/sources/` : relevés externes datés qui alimentent `scripts/build_verification.py`.
- `sw.js` : nom de cache calculé à partir du contenu à chaque build.
- État : `state.schema = 7`, `state.v7Reports` ; clé `hyrule_codex_v1` inchangée. Export `version: 7`, rétrocompatible avec l’import V5/V6.

## Données et provenance (historique V6)

Les constantes JSON embarquées dans `src/app.js` sont actuellement **la source technique** utilisée par l'interface. `data/*.json` sont des instantanés d'export pour audit/ingestion dans des outils externes. **Modifier un JSON de data/ ne change pas l'app**. Pour rendre la base unique, refactoriser l’app autour des JSON et prévoir un bundling hors ligne : ne pas simplement `fetch('data/..')` dans une appli censée marcher hors connexion sans revoir le service worker.

`ATLAS` est initialisé avec 88 repères V3 puis enrichi et filtré au chargement ; le JSON `data/atlas_active_640.json` contient l'état final simulé : V5_NAMED + V6_BOSSES (les 88 anciens repères n'y figurent pas).

## Persistance navigateur

- Clé `localStorage` : `hyrule_codex_v1` pour `state` (inventaire/cochages/objectifs/quêtes/collections...).
- Clé `localStorage` : `hyrule_codex_remote_totk_v3` pour cache du catalogue distant.
- L'application fournit export/import de progression JSON. Tester qu'une migration ne perde aucun champ hérité.
- Sauvegarde locale liée au **domaine et au navigateur** : changer d'URL Netlify sans export peut perdre l'accès à la sauvegarde de l'ancienne origine.

## PWA et mode hors ligne

`site/sw.js` conserve en cache les fichiers statiques et renvoie `index.html` lors de navigation hors ligne. **Incrémenter `CACHE` lors d’une livraison** pour forcer la mise à jour des anciens clients. Les requêtes vers `api.hyrule-compendium.com` sont **hors origine et non prises en charge offline** par ce service worker.

## Assistant

La partie « Assistant » fournit des suggestions/prompts pour ChatGPT ; il n'y a **pas de chat avec modèle connecté dans la PWA**, ni serveur/API backend.
