# État vérifié — V7.8 (11 novembre 2026)

« Recoupé » signifie : la valeur concorde avec au moins une source externe **distincte** de la source d’import (GamerTW). Ce n’est jamais une confirmation en jeu : aucune donnée n’a été testée sur Switch par l’auteur de V7. Détail par enregistrement : `data/v7/verification.json`, onglet **Fiabilité** de l’app.

## Ajouts V7.1 (importés d’une source unique, citée, non recoupée)

| Bloc | Contenu | Source |
|---|---|---|
| Armures | 135 pièces (103 améliorables), lieu + XYZ, DEF base/max, matériaux et rubis des 4 paliers, 36 ensembles et bonus | ConsolePulse (mise à jour 13/09/2026) |
| Arsenal | 174 armes, arcs et boucliers (Compendium 329–503 sauf 440) : puissance/défense, durabilité, effet | Samurai Gamers (02/06/2023) |
| Recettes | 228 entrées du livre (146 marmite, 51 grillées, 1 bouillie, 16 congelées, 13 élixirs, 1 tonique), seuils d’effets | ConsolePulse (26/09/2026) |
| Grottes | 147 grottes (4 célestes), 197 entrées, position de la Grenouille Bubbul, récompenses de Koltin ; 7 grottes recoupées avec EarlyGame (écart ≤ 19 u), 1 conflit de nom | ConsolePulse (13/09/2026) |
| Lynels | Variante et lieu des 34 Lynels ; 29 positions concordent à ≤ 48 u, les 5 du Colisée flottant sont regroupées | Thonky (04/02/2025) |
| Vœux des Sages | 20 coffres célestes, coordonnées et condition d’accès ; 8 recoupés avec un autre site (≤ 30 u) | ConsolePulse (26/09/2026) |
| Panneaux de Boulieh | 81 panneaux d’Addison, coordonnées par bande géographique ; non recoupés | ConsolePulse (16/09/2026) |
| Korogus | Totaux des 16 régions (900 rencontres, 100 amis, 1 000 graines) et coûts de Hestu ; positions, téléporteur, type d’énigme pour **10 régions sur 16** (Lookout Landing 62, Hyrule Field 77, Lindor's Brow 66, Rospro Pass 65, Pikida Stonegrove 33, Thyphlo Ruins 23, Upland Zorana 76, Mount Lanayru 50, Sahasra Slope 79, Great Sky Island 17 = 548 positions ; nombre de lignes et de graines égal au total régional pour chacune) | ConsolePulse (26/10/2026) |
| Ennemis communs | 69 fiches : PV, attaques, butins possibles (sans taux), régions d’exemple ; 58 reliées au bestiaire | RankedBoost |

Effet sur le bestiaire : PV renseignés pour 83 fiches sur 96 (contre 37 en V6) ; 12 valeurs V6 confirmées par RankedBoost ; 1 valeur V6 corrigée (Lézalfos bleu 110 → 120, à confirmer). Les noms d’objets de ces blocs restent en **anglais officiel** : aucun nom français n’a été inventé. Les traductions d’effets sont descriptives et signalées.

## Statuts (774 enregistrements suivis)

| Statut | Nombre |
|---|---:|
| Recoupé ≥ 2 sources | 24 |
| Recoupé 1 source | 149 |
| Partiellement recoupé | 151 |
| Corrigé, à confirmer | 1 (+ 6 corrections journalisées sur des fiches recoupées) |
| Sources en conflit | 4 |
| Importé, non recoupé | 421 |
| Sans source | 24 |

## Par catégorie

| Catégorie | Présent | Total attendu (sourcé) | Recoupé | Commentaire |
|---|---:|---:|---:|---|
| Racines | 120 | 120 | 116 | XYZ comparés à Samurai Gamers ; 2 conflits (root_41, root_115), 2 absents de la source |
| Sanctuaires | 152 | 152 | 110 | X/Y via la racine appariée ; Z non recoupé ; 32 célestes non recoupés |
| Positions de boss | 249 (+ 34 Lynels recoupés avec variante) | effectifs concordants | 0 individuellement | répartition par variante identique à la source (Gigatraciens, Golemax, Griocks) ; Hinox 68 ou 69 selon la source ; total Lithorok peu solide |
| Puits / tours / larmes | 58 / 15 / 12 | 15 tours sourcées | 0 | positions importées |
| Bestiaire | 96 | non établi | 37 | PV des boss/sous-boss recoupés ; 46 PV importés de RankedBoost ; butins sans taux |
| Amalgame | 38 | non établi | 27 | 0 conflit ; 7 matériaux sourcés absents (noms FR non vérifiés) |
| Armes / armures V6 | 30 / 22 | non établi | 0 | fiches V6 sans source ; voir les blocs V7.1 complets |
| Quêtes | 253 intitulés | non établi | 0 | pas de solutions |
| Recettes | 228 | 228 (sourcé) | 0 | importées, non recoupées |

## Ce qui reste non prouvé

Probabilités de butin par variante, positions individuelles des 249 boss hors Lynels, noms français des objets des blocs V7.1, solutions de quêtes et 352 positions de Korogus (6 régions restantes). Les blocs V7.1 reposent chacun sur une seule source.
